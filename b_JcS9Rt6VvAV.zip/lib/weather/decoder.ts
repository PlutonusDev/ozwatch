// METAR and TAF decoder for Australian aviation weather
// Parses raw weather strings into structured data

import { MetarData, TafData, TafPeriod, CloudLayer, WeatherPhenomenon } from "@/lib/types/aviation"

// Weather phenomenon descriptions
const WEATHER_DESCRIPTORS: Record<string, string> = {
  MI: "Shallow",
  BC: "Patches",
  PR: "Partial",
  DR: "Low drifting",
  BL: "Blowing",
  SH: "Showers",
  TS: "Thunderstorm",
  FZ: "Freezing",
}

const WEATHER_PHENOMENA: Record<string, string> = {
  DZ: "Drizzle",
  RA: "Rain",
  SN: "Snow",
  SG: "Snow grains",
  IC: "Ice crystals",
  PL: "Ice pellets",
  GR: "Hail",
  GS: "Small hail",
  UP: "Unknown precipitation",
  BR: "Mist",
  FG: "Fog",
  FU: "Smoke",
  VA: "Volcanic ash",
  DU: "Dust",
  SA: "Sand",
  HZ: "Haze",
  PO: "Dust devils",
  SQ: "Squalls",
  FC: "Funnel cloud",
  SS: "Sandstorm",
  DS: "Dust storm",
}

const CLOUD_COVER: Record<string, { description: string; oktas: string }> = {
  SKC: { description: "Sky clear", oktas: "0/8" },
  CLR: { description: "Clear", oktas: "0/8" },
  NSC: { description: "No significant cloud", oktas: "-" },
  NCD: { description: "No cloud detected", oktas: "-" },
  FEW: { description: "Few", oktas: "1-2/8" },
  SCT: { description: "Scattered", oktas: "3-4/8" },
  BKN: { description: "Broken", oktas: "5-7/8" },
  OVC: { description: "Overcast", oktas: "8/8" },
}

/**
 * Parse a METAR string into structured data
 */
export function parseMetar(raw: string): MetarData {
  const parts = raw.trim().split(/\s+/)
  let index = 0

  // Skip METAR/SPECI identifier if present
  if (parts[index] === "METAR" || parts[index] === "SPECI") {
    index++
  }

  // Station identifier
  const station = parts[index++]

  // Time (DDHHMM Z)
  const timeMatch = parts[index].match(/^(\d{2})(\d{2})(\d{2})Z$/)
  let time = new Date()
  if (timeMatch) {
    const day = parseInt(timeMatch[1])
    const hour = parseInt(timeMatch[2])
    const minute = parseInt(timeMatch[3])
    time = new Date()
    time.setUTCDate(day)
    time.setUTCHours(hour, minute, 0, 0)
    index++
  }

  // Auto indicator
  if (parts[index] === "AUTO") {
    index++
  }

  // Wind
  const wind = parseWind(parts[index])
  if (wind) index++

  // Variable wind direction
  let variableWind: { from: number; to: number } | undefined
  const varWindMatch = parts[index]?.match(/^(\d{3})V(\d{3})$/)
  if (varWindMatch) {
    variableWind = {
      from: parseInt(varWindMatch[1]),
      to: parseInt(varWindMatch[2]),
    }
    index++
  }
  if (wind && variableWind) {
    wind.variable = variableWind
  }

  // Visibility
  const visibility = parseVisibility(parts[index])
  if (visibility) index++

  // Weather phenomena
  const weather: WeatherPhenomenon[] = []
  while (parts[index] && isWeatherPhenomenon(parts[index])) {
    const wx = parseWeatherPhenomenon(parts[index])
    if (wx) weather.push(wx)
    index++
  }

  // Clouds
  const clouds: CloudLayer[] = []
  while (parts[index] && isCloudLayer(parts[index])) {
    const cloud = parseCloudLayer(parts[index])
    if (cloud) clouds.push(cloud)
    index++
  }

  // Temperature and dewpoint
  let temperature = 0
  let dewpoint = 0
  const tempMatch = parts[index]?.match(/^(M?\d{2})\/(M?\d{2})$/)
  if (tempMatch) {
    temperature = parseTemperature(tempMatch[1])
    dewpoint = parseTemperature(tempMatch[2])
    index++
  }

  // Pressure (QNH)
  let pressure = { value: 1013, unit: "HPA" as const }
  const qnhMatch = parts[index]?.match(/^Q(\d{4})$/)
  const altMatch = parts[index]?.match(/^A(\d{4})$/)
  if (qnhMatch) {
    pressure = { value: parseInt(qnhMatch[1]), unit: "HPA" }
    index++
  } else if (altMatch) {
    pressure = { value: parseInt(altMatch[1]) / 100, unit: "INH" }
    index++
  }

  // Trend and remarks
  let trend: string | undefined
  let remarks: string | undefined
  const remaining = parts.slice(index).join(" ")
  if (remaining.includes("NOSIG")) {
    trend = "No significant change"
  } else if (remaining.includes("BECMG")) {
    trend = remaining
  } else if (remaining.includes("TEMPO")) {
    trend = remaining
  }
  if (remaining.includes("RMK")) {
    remarks = remaining.split("RMK")[1]?.trim()
  }

  // Determine flight category
  const flightCategory = determineFlightCategory(visibility, clouds)

  return {
    raw,
    station,
    time,
    wind: wind || { direction: 0, speed: 0, unit: "KT" },
    visibility: visibility || { value: 9999, unit: "M" },
    weather: weather.length > 0 ? weather : undefined,
    clouds,
    temperature,
    dewpoint,
    pressure,
    trend,
    remarks,
    flightCategory,
  }
}

/**
 * Parse a TAF string into structured data
 */
export function parseTaf(raw: string): TafData {
  const lines = raw.trim().split(/\s+/)
  let index = 0

  // Skip TAF identifier
  if (lines[index] === "TAF") index++
  if (lines[index] === "AMD" || lines[index] === "COR") index++

  // Station
  const station = lines[index++]

  // Issue time
  const issueMatch = lines[index].match(/^(\d{2})(\d{2})(\d{2})Z$/)
  let issued = new Date()
  if (issueMatch) {
    issued.setUTCDate(parseInt(issueMatch[1]))
    issued.setUTCHours(parseInt(issueMatch[2]), parseInt(issueMatch[3]), 0, 0)
    index++
  }

  // Validity period
  const validMatch = lines[index].match(/^(\d{2})(\d{2})\/(\d{2})(\d{2})$/)
  let validFrom = new Date()
  let validTo = new Date()
  if (validMatch) {
    validFrom.setUTCDate(parseInt(validMatch[1]))
    validFrom.setUTCHours(parseInt(validMatch[2]), 0, 0, 0)
    validTo.setUTCDate(parseInt(validMatch[3]))
    validTo.setUTCHours(parseInt(validMatch[4]), 0, 0, 0)
    index++
  }

  // Parse forecast periods
  const forecast: TafPeriod[] = []
  let currentPeriod: TafPeriod = {
    type: "MAIN",
    from: validFrom,
    to: validTo,
  }

  while (index < lines.length) {
    const part = lines[index]

    // Check for new period markers
    if (part.startsWith("BECMG")) {
      if (Object.keys(currentPeriod).length > 2) {
        forecast.push(currentPeriod)
      }
      currentPeriod = { type: "BECMG", from: new Date() }
      index++
      continue
    }

    if (part.startsWith("TEMPO")) {
      if (Object.keys(currentPeriod).length > 2) {
        forecast.push(currentPeriod)
      }
      currentPeriod = { type: "TEMPO", from: new Date() }
      index++
      continue
    }

    if (part.startsWith("FM")) {
      if (Object.keys(currentPeriod).length > 2) {
        forecast.push(currentPeriod)
      }
      const fmMatch = part.match(/^FM(\d{2})(\d{2})(\d{2})$/)
      if (fmMatch) {
        const fmTime = new Date(validFrom)
        fmTime.setUTCDate(parseInt(fmMatch[1]))
        fmTime.setUTCHours(parseInt(fmMatch[2]), parseInt(fmMatch[3]), 0, 0)
        currentPeriod = { type: "FM", from: fmTime }
      }
      index++
      continue
    }

    if (part.startsWith("PROB")) {
      if (Object.keys(currentPeriod).length > 2) {
        forecast.push(currentPeriod)
      }
      const probMatch = part.match(/^PROB(\d{2})$/)
      currentPeriod = {
        type: "PROB",
        probability: probMatch ? parseInt(probMatch[1]) : 30,
        from: new Date(),
      }
      index++
      continue
    }

    // Time period (for BECMG/TEMPO)
    const periodMatch = part.match(/^(\d{2})(\d{2})\/(\d{2})(\d{2})$/)
    if (periodMatch) {
      currentPeriod.from = new Date(validFrom)
      currentPeriod.from.setUTCDate(parseInt(periodMatch[1]))
      currentPeriod.from.setUTCHours(parseInt(periodMatch[2]), 0, 0, 0)
      currentPeriod.to = new Date(validFrom)
      currentPeriod.to.setUTCDate(parseInt(periodMatch[3]))
      currentPeriod.to.setUTCHours(parseInt(periodMatch[4]), 0, 0, 0)
      index++
      continue
    }

    // Wind
    const wind = parseWind(part)
    if (wind) {
      currentPeriod.wind = wind
      index++
      continue
    }

    // Visibility
    const vis = parseVisibility(part)
    if (vis) {
      currentPeriod.visibility = vis
      index++
      continue
    }

    // Weather
    if (isWeatherPhenomenon(part)) {
      const wx = parseWeatherPhenomenon(part)
      if (wx) {
        currentPeriod.weather = currentPeriod.weather || []
        currentPeriod.weather.push(wx)
      }
      index++
      continue
    }

    // Clouds
    if (isCloudLayer(part)) {
      const cloud = parseCloudLayer(part)
      if (cloud) {
        currentPeriod.clouds = currentPeriod.clouds || []
        currentPeriod.clouds.push(cloud)
      }
      index++
      continue
    }

    index++
  }

  // Add final period
  if (Object.keys(currentPeriod).length > 2) {
    forecast.push(currentPeriod)
  }

  return {
    raw,
    station,
    issued,
    validFrom,
    validTo,
    forecast,
  }
}

// Helper functions
function parseWind(str: string): MetarData["wind"] | null {
  const match = str.match(/^(\d{3}|VRB)(\d{2,3})(G(\d{2,3}))?(KT|MPS)$/)
  if (!match) return null

  return {
    direction: match[1] === "VRB" ? "VRB" : parseInt(match[1]),
    speed: parseInt(match[2]),
    gust: match[4] ? parseInt(match[4]) : undefined,
    unit: match[5] as "KT" | "MPS",
  }
}

function parseVisibility(str: string): MetarData["visibility"] | null {
  // Metric visibility (meters)
  if (/^\d{4}$/.test(str)) {
    return { value: parseInt(str), unit: "M" }
  }
  // CAVOK
  if (str === "CAVOK") {
    return { value: 9999, unit: "M" }
  }
  // Statute miles
  const smMatch = str.match(/^(\d+)(\/(\d+))?SM$/)
  if (smMatch) {
    let value = parseInt(smMatch[1])
    if (smMatch[3]) {
      value = value / parseInt(smMatch[3])
    }
    return { value, unit: "SM" }
  }
  return null
}

function isWeatherPhenomenon(str: string): boolean {
  // Check for intensity prefix and weather codes
  const pattern = /^(-|\+|VC)?(MI|BC|PR|DR|BL|SH|TS|FZ)?(DZ|RA|SN|SG|IC|PL|GR|GS|UP|BR|FG|FU|VA|DU|SA|HZ|PO|SQ|FC|SS|DS)+$/
  return pattern.test(str)
}

function parseWeatherPhenomenon(str: string): WeatherPhenomenon | null {
  const result: WeatherPhenomenon = { phenomena: [] }

  // Intensity
  if (str.startsWith("-")) {
    result.intensity = "LIGHT"
    str = str.slice(1)
  } else if (str.startsWith("+")) {
    result.intensity = "HEAVY"
    str = str.slice(1)
  } else if (str.startsWith("VC")) {
    str = str.slice(2)
  } else {
    result.intensity = "MODERATE"
  }

  // Descriptor
  for (const desc of Object.keys(WEATHER_DESCRIPTORS)) {
    if (str.startsWith(desc)) {
      result.descriptor = desc
      str = str.slice(2)
      break
    }
  }

  // Phenomena
  while (str.length >= 2) {
    const code = str.slice(0, 2)
    if (WEATHER_PHENOMENA[code]) {
      result.phenomena.push(code)
    }
    str = str.slice(2)
  }

  return result.phenomena.length > 0 ? result : null
}

function isCloudLayer(str: string): boolean {
  return /^(SKC|CLR|NSC|NCD|FEW|SCT|BKN|OVC)(\d{3})?(CB|TCU)?$/.test(str)
}

function parseCloudLayer(str: string): CloudLayer | null {
  const match = str.match(/^(SKC|CLR|NSC|NCD|FEW|SCT|BKN|OVC)(\d{3})?(CB|TCU)?$/)
  if (!match) return null

  return {
    cover: match[1] as CloudLayer["cover"],
    base: match[2] ? parseInt(match[2]) * 100 : undefined,
    type: match[3] as "CB" | "TCU" | undefined,
  }
}

function parseTemperature(str: string): number {
  const isMinus = str.startsWith("M")
  const value = parseInt(str.replace("M", ""))
  return isMinus ? -value : value
}

function determineFlightCategory(
  visibility: MetarData["visibility"] | null,
  clouds: CloudLayer[]
): MetarData["flightCategory"] {
  const visMeters = visibility?.unit === "M" ? visibility.value : (visibility?.value || 10) * 1609
  
  // Find lowest ceiling (BKN or OVC)
  let ceiling = Infinity
  for (const cloud of clouds) {
    if ((cloud.cover === "BKN" || cloud.cover === "OVC") && cloud.base !== undefined) {
      ceiling = Math.min(ceiling, cloud.base)
    }
  }

  // LIFR: Ceiling < 500ft or Visibility < 1SM (1609m)
  if (ceiling < 500 || visMeters < 1609) {
    return "LIFR"
  }

  // IFR: Ceiling 500-999ft or Visibility 1-3SM
  if (ceiling < 1000 || visMeters < 4828) {
    return "IFR"
  }

  // MVFR: Ceiling 1000-3000ft or Visibility 3-5SM
  if (ceiling <= 3000 || visMeters <= 8047) {
    return "MVFR"
  }

  return "VFR"
}

/**
 * Get human-readable description of weather phenomena
 */
export function describeWeather(wx: WeatherPhenomenon): string {
  const parts: string[] = []

  if (wx.intensity === "LIGHT") parts.push("Light")
  if (wx.intensity === "HEAVY") parts.push("Heavy")

  if (wx.descriptor) {
    parts.push(WEATHER_DESCRIPTORS[wx.descriptor] || wx.descriptor)
  }

  for (const p of wx.phenomena) {
    parts.push(WEATHER_PHENOMENA[p] || p)
  }

  return parts.join(" ")
}

/**
 * Get human-readable description of cloud layer
 */
export function describeCloud(cloud: CloudLayer): string {
  const cover = CLOUD_COVER[cloud.cover]
  if (!cover) return cloud.cover

  let desc = cover.description
  if (cloud.base !== undefined) {
    desc += ` at ${cloud.base.toLocaleString()} ft`
  }
  if (cloud.type === "CB") {
    desc += " (Cumulonimbus)"
  } else if (cloud.type === "TCU") {
    desc += " (Towering Cumulus)"
  }

  return desc
}

/**
 * Get color code for flight category
 */
export function getFlightCategoryColor(category: MetarData["flightCategory"]): string {
  switch (category) {
    case "VFR":
      return "#22c55e" // Green
    case "MVFR":
      return "#3b82f6" // Blue
    case "IFR":
      return "#ef4444" // Red
    case "LIFR":
      return "#ec4899" // Pink/Magenta
    default:
      return "#6b7280" // Gray
  }
}
