// Core aviation types for the flight planning application

export interface Coordinates {
  latitude: number
  longitude: number
}

export interface Runway {
  identifier: string // e.g., "09/27"
  length: number // feet
  width: number // feet
  surface: "ASPHALT" | "CONCRETE" | "GRASS" | "GRAVEL" | "SEALED"
  heading: number // magnetic heading of the lower number
  elevation: number // threshold elevation
  lighting?: string // e.g., "PCL", "PAPI"
  ils?: {
    frequency: number
    course: number
    category: "CAT I" | "CAT II" | "CAT III"
  }
}

export interface Frequency {
  name: string // e.g., "TOWER", "GROUND", "ATIS", "CTAF"
  frequency: number // MHz
  notes?: string
}

export interface AerodromeData {
  icao: string
  name: string
  city?: string
  state?: string
  latitude: number
  longitude: number
  elevation: number
  magneticVariation?: number
  runways: Runway[]
  frequencies: Frequency[]
  services?: {
    fuel?: string[]
    customs?: boolean
    handling?: boolean
    maintenance?: boolean
  }
  airspaceClass?: string
  ctaLowerLimit?: number
  operatingHours?: string
}

export interface WaypointData {
  identifier: string
  name?: string
  type: "VOR" | "VORDME" | "DME" | "NDB" | "FIX" | "AIRPORT" | "GPS"
  latitude: number
  longitude: number
  frequency?: number
  channel?: string
  range?: number
}

export interface AirwaySegment {
  from: string // Waypoint identifier
  to: string
  minAlt: number // Minimum altitude feet
  maxAlt?: number
  direction?: "ONEWAY" | "BIDIRECTIONAL"
  magneticTrack?: number
  distance?: number // NM
}

export interface AirwayData {
  identifier: string
  type: "LOW" | "HIGH"
  segments: AirwaySegment[]
}

export interface AirspaceGeometry {
  type: "Polygon"
  coordinates: number[][][] // GeoJSON format
}

export interface AirspaceData {
  name: string
  type: "CTR" | "CTA" | "TMA" | "FIR" | "DANGER" | "RESTRICTED" | "PROHIBITED" | "MOA" | "TRAINING" | "ALERT"
  class?: string
  geometry: AirspaceGeometry
  lowerLimit: number
  lowerLimitRef: "AGL" | "AMSL" | "FL"
  upperLimit: number
  upperLimitRef: "AGL" | "AMSL" | "FL"
  activeHours?: string
  activeDays?: string
  frequency?: number
}

// SID/STAR/Approach types
export interface ProcedureWaypoint {
  identifier: string
  latitude: number
  longitude: number
  altitude?: number // Required altitude
  altitudeConstraint?: "AT" | "AT_OR_ABOVE" | "AT_OR_BELOW" | "BETWEEN"
  altitudeMin?: number
  altitudeMax?: number
  speed?: number // Speed constraint
  speedConstraint?: "AT" | "AT_OR_BELOW"
  turnDirection?: "LEFT" | "RIGHT"
  flyOver: boolean // Fly-over vs fly-by
}

export interface InstrumentProcedure {
  name: string
  runway?: string // Associated runway
  transition?: string // Transition name if applicable
  waypoints: ProcedureWaypoint[]
  minimumAltitude?: number
  notes?: string
}

export interface SID extends InstrumentProcedure {
  type: "SID"
  initialClimb?: number
}

export interface STAR extends InstrumentProcedure {
  type: "STAR"
}

export interface Approach extends InstrumentProcedure {
  type: "ILS" | "VOR" | "NDB" | "RNAV" | "RNP" | "VISUAL"
  minimums: {
    da?: number // Decision Altitude (ILS)
    mda?: number // Minimum Descent Altitude
    visibility?: number // meters or RVR
    rvr?: number
    ceiling?: number
  }
  missedApproach?: string // Missed approach instructions
}

// Route Planning Types
export interface RouteLeg {
  from: WaypointData
  to: WaypointData
  distance: number // NM
  magneticTrack: number
  trueTrack: number
  minimumAltitude: number // LSALT for this leg
  airway?: string // If flying an airway
  eet: number // Estimated elapsed time in minutes for this leg
  fuelBurn: number // Fuel burn for this leg in gallons
}

export interface PlannedRoute {
  departure: AerodromeData
  destination: AerodromeData
  alternates: AerodromeData[]
  legs: RouteLeg[]
  totalDistance: number
  totalEet: number
  totalFuel: number
  cruiseAltitude: number
  sid?: SID
  star?: STAR
  approach?: Approach
}

// Flight Plan Types
export interface FlightPlanWaypoint {
  identifier: string
  type: string
  latitude: number
  longitude: number
  legDistance: number
  cumulativeDistance: number
  magneticTrack: number
  trueTrack: number
  lsalt: number
  altitude: number
  eet: number // Minutes from departure
  eta?: Date
  ata?: Date // Actual time of arrival (for tracking)
  fuelRemaining: number
  remarks?: string
}

export interface FuelPlanData {
  // Trip fuel
  taxi: number
  tripFuel: number
  contingency: number // 10% of trip fuel
  alternate: number
  holding: number // Fixed reserve (30/45 min VFR, 45 min IFR)
  additional: number
  totalRequired: number
  
  // Actual fuel
  blockFuel: number // Total fuel on board
  extraFuel: number // Block - required
  
  // Times
  endurance: number // Minutes
}

export interface WeightStation {
  name: string
  arm: number // inches from datum
  weight: number // current weight
  maxWeight?: number
  moment: number // weight * arm
}

export interface CGEnvelopePoint {
  weight: number
  fwdCG: number
  aftCG: number
}

export interface WeightBalanceData {
  stations: WeightStation[]
  basicEmptyWeight: number
  basicEmptyMoment: number
  totalWeight: number
  totalMoment: number
  cg: number // Center of gravity
  cgEnvelope: CGEnvelopePoint[]
  isWithinLimits: boolean
  takeoffWeight: number
  landingWeight: number
  zeroFuelWeight?: number
  maxTakeoffWeight: number
  maxLandingWeight: number
  maxZeroFuelWeight?: number
}

// Weather Types
export interface MetarData {
  raw: string
  station: string
  time: Date
  wind: {
    direction: number | "VRB"
    speed: number
    gust?: number
    unit: "KT" | "MPS"
    variable?: { from: number; to: number }
  }
  visibility: {
    value: number
    unit: "M" | "SM"
    direction?: string
  }
  weather?: WeatherPhenomenon[]
  clouds: CloudLayer[]
  temperature: number
  dewpoint: number
  pressure: {
    value: number
    unit: "HPA" | "INH"
  }
  trend?: string
  remarks?: string
  flightCategory: "VFR" | "MVFR" | "IFR" | "LIFR"
}

export interface WeatherPhenomenon {
  intensity?: "LIGHT" | "MODERATE" | "HEAVY"
  descriptor?: string // e.g., "TS", "SH", "FZ"
  phenomena: string[] // e.g., ["RA"], ["BR", "HZ"]
}

export interface CloudLayer {
  cover: "FEW" | "SCT" | "BKN" | "OVC" | "SKC" | "CLR" | "NSC" | "NCD"
  base?: number // feet AGL
  type?: "CB" | "TCU" // Cumulonimbus or Towering Cumulus
}

export interface TafData {
  raw: string
  station: string
  issued: Date
  validFrom: Date
  validTo: Date
  forecast: TafPeriod[]
}

export interface TafPeriod {
  type: "MAIN" | "BECMG" | "TEMPO" | "PROB" | "FM"
  probability?: number // For PROB
  from: Date
  to?: Date
  wind?: MetarData["wind"]
  visibility?: MetarData["visibility"]
  weather?: WeatherPhenomenon[]
  clouds?: CloudLayer[]
}

export interface Sigmet {
  id: string
  type: "SIGMET" | "AIRMET"
  phenomenon: string // e.g., "TS", "TURB", "ICE"
  area: AirspaceGeometry
  validFrom: Date
  validTo: Date
  altitude?: { from: number; to: number }
  movement?: { direction: number; speed: number }
  intensity?: string
  raw: string
}

export interface WeatherBriefing {
  requestTime: Date
  route: string
  metars: MetarData[]
  tafs: TafData[]
  sigmets: Sigmet[]
  airmets: Sigmet[]
  notams?: NotamData[]
  area?: {
    weatherRadar?: string // URL to radar image
    satelliteImage?: string
    surfaceChart?: string
  }
}

export interface NotamData {
  id: string
  type: string
  location: string
  text: string
  validFrom: Date
  validTo?: Date
  isPermanent: boolean
  coordinates?: Coordinates
  radius?: number
}

// NAIPS Integration Types
export interface NAIPSCredentials {
  username: string
  password: string
}

export interface NAIPSFlightPlan {
  messageType: "FPL" | "CHG" | "CNL" | "DLA"
  aircraftId: string // Callsign
  flightRules: "V" | "I" | "Y" | "Z"
  flightType: "G" | "N" | "S" | "M" | "X"
  number: number // Number of aircraft
  aircraftType: string
  wakeTurbulence: "L" | "M" | "H" | "J"
  equipment: string
  surveillance: string
  departure: string
  departureTime: string // HHMM UTC
  cruiseSpeed: string // e.g., "N0120" or "M085"
  cruiseAltitude: string // e.g., "A055" or "F350"
  route: string
  destination: string
  eet: string // HHMM
  alternates: string[]
  otherInfo: string // Field 18
  supplementary: {
    endurance: string // HHMM
    persons: number
    emergencyEquipment?: string
    survival?: string
    dinghies?: string
    aircraft?: string // Colour and markings
    remarks?: string
    pilotName: string
  }
}

// LSALT Calculation Types
export interface LSALTCalculation {
  leg: { from: string; to: string }
  maxTerrainElevation: number
  obstacles: number // Highest obstacle if any
  bufferDistance: number // NM either side of track
  roundUp: number // Round up to nearest (100 for VFR, 1000 for IFR)
  clearance: number // 1000ft for VFR, 1000/2000ft for IFR
  calculatedLSALT: number
  published?: number // Published LSALT if available
  finalLSALT: number // Higher of calculated vs published
}

// Aircraft Performance Types
export interface PerformanceCalculation {
  // Takeoff performance
  takeoffDistance: {
    ground: number // feet
    fiftyFt: number // to clear 50ft obstacle
  }
  
  // Landing performance  
  landingDistance: {
    ground: number
    fiftyFt: number
  }
  
  // Climb performance
  climbGradient: number // percent
  timeToAltitude: number // minutes
  fuelToAltitude: number // gallons
  distanceToAltitude: number // NM
  
  // Cruise performance at planned altitude
  tas: number // True airspeed
  fuelFlow: number // gph
  
  // Descent
  descentTime: number
  descentDistance: number
  topOfDescent: number // Distance from destination to begin descent
}
