// Authentication utilities for admin-provisioned accounts
// Uses bcrypt for password hashing and secure session management

import { cookies } from "next/headers"
import { prisma } from "@/lib/prisma"
import { SignJWT, jwtVerify } from "jose"

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "fallback-secret-change-in-production"
)
const SESSION_COOKIE_NAME = "flightplan_session"
const SESSION_DURATION = 7 * 24 * 60 * 60 * 1000 // 7 days

export interface SessionUser {
  id: string
  email: string
  name: string
  role: "ADMIN" | "PILOT"
}

/**
 * Hash a password using Web Crypto API (Edge-compatible)
 */
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(password)
  
  // Generate a random salt
  const salt = crypto.getRandomValues(new Uint8Array(16))
  
  // Import the password as a key
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    data,
    "PBKDF2",
    false,
    ["deriveBits"]
  )
  
  // Derive the hash
  const hash = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt,
      iterations: 100000,
      hash: "SHA-256",
    },
    keyMaterial,
    256
  )
  
  // Combine salt and hash for storage
  const combined = new Uint8Array(salt.length + new Uint8Array(hash).length)
  combined.set(salt)
  combined.set(new Uint8Array(hash), salt.length)
  
  return Buffer.from(combined).toString("base64")
}

/**
 * Verify a password against a stored hash
 */
export async function verifyPassword(
  password: string,
  storedHash: string
): Promise<boolean> {
  const encoder = new TextEncoder()
  const data = encoder.encode(password)
  
  // Decode the stored hash
  const combined = Buffer.from(storedHash, "base64")
  const salt = combined.slice(0, 16)
  const originalHash = combined.slice(16)
  
  // Import the password as a key
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    data,
    "PBKDF2",
    false,
    ["deriveBits"]
  )
  
  // Derive the hash with the same salt
  const hash = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt,
      iterations: 100000,
      hash: "SHA-256",
    },
    keyMaterial,
    256
  )
  
  // Compare hashes
  const hashArray = new Uint8Array(hash)
  if (hashArray.length !== originalHash.length) return false
  
  let match = true
  for (let i = 0; i < hashArray.length; i++) {
    if (hashArray[i] !== originalHash[i]) match = false
  }
  
  return match
}

/**
 * Create a JWT session token
 */
export async function createSessionToken(user: SessionUser): Promise<string> {
  return new SignJWT({
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
  })
    .setProtectedHeader({ alg: "HS256" })
    .setExpirationTime("7d")
    .setIssuedAt()
    .sign(JWT_SECRET)
}

/**
 * Verify a JWT session token
 */
export async function verifySessionToken(token: string): Promise<SessionUser | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET)
    return {
      id: payload.id as string,
      email: payload.email as string,
      name: payload.name as string,
      role: payload.role as "ADMIN" | "PILOT",
    }
  } catch {
    return null
  }
}

/**
 * Get the current session from cookies
 */
export async function getSession(): Promise<SessionUser | null> {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value
  
  if (!token) return null
  
  return verifySessionToken(token)
}

/**
 * Set session cookie
 */
export async function setSessionCookie(token: string): Promise<void> {
  const cookieStore = await cookies()
  cookieStore.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: SESSION_DURATION / 1000,
    path: "/",
  })
}

/**
 * Clear session cookie (logout)
 */
export async function clearSessionCookie(): Promise<void> {
  const cookieStore = await cookies()
  cookieStore.delete(SESSION_COOKIE_NAME)
}

/**
 * Login with email and password
 */
export async function login(
  email: string,
  password: string
): Promise<{ success: boolean; user?: SessionUser; error?: string }> {
  try {
    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    })

    if (!user || !user.isActive) {
      return { success: false, error: "Invalid email or password" }
    }

    const isValid = await verifyPassword(password, user.hashedPassword)
    if (!isValid) {
      return { success: false, error: "Invalid email or password" }
    }

    const sessionUser: SessionUser = {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
    }

    const token = await createSessionToken(sessionUser)
    await setSessionCookie(token)

    return { success: true, user: sessionUser }
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, error: "An error occurred during login" }
  }
}

/**
 * Logout - clear session
 */
export async function logout(): Promise<void> {
  await clearSessionCookie()
}

/**
 * Create a new user (admin only)
 */
export async function createUser(
  adminUser: SessionUser,
  userData: {
    email: string
    name: string
    password: string
    role?: "ADMIN" | "PILOT"
    pilotLicense?: string
    medicalExpiry?: Date
  }
): Promise<{ success: boolean; userId?: string; error?: string }> {
  if (adminUser.role !== "ADMIN") {
    return { success: false, error: "Only administrators can create users" }
  }

  try {
    // Check if user already exists
    const existing = await prisma.user.findUnique({
      where: { email: userData.email.toLowerCase() },
    })

    if (existing) {
      return { success: false, error: "User with this email already exists" }
    }

    const hashedPassword = await hashPassword(userData.password)

    const user = await prisma.user.create({
      data: {
        email: userData.email.toLowerCase(),
        name: userData.name,
        hashedPassword,
        role: userData.role || "PILOT",
        pilotLicense: userData.pilotLicense,
        medicalExpiry: userData.medicalExpiry,
      },
    })

    return { success: true, userId: user.id }
  } catch (error) {
    console.error("Create user error:", error)
    return { success: false, error: "Failed to create user" }
  }
}

/**
 * Update user password
 */
export async function updatePassword(
  userId: string,
  currentPassword: string,
  newPassword: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return { success: false, error: "User not found" }
    }

    const isValid = await verifyPassword(currentPassword, user.hashedPassword)
    if (!isValid) {
      return { success: false, error: "Current password is incorrect" }
    }

    const hashedPassword = await hashPassword(newPassword)
    
    await prisma.user.update({
      where: { id: userId },
      data: { hashedPassword },
    })

    return { success: true }
  } catch (error) {
    console.error("Update password error:", error)
    return { success: false, error: "Failed to update password" }
  }
}

/**
 * Require authentication middleware helper
 * Use in API routes and server actions
 */
export async function requireAuth(): Promise<SessionUser> {
  const session = await getSession()
  if (!session) {
    throw new Error("Unauthorized")
  }
  return session
}

/**
 * Require admin role
 */
export async function requireAdmin(): Promise<SessionUser> {
  const session = await requireAuth()
  if (session.role !== "ADMIN") {
    throw new Error("Forbidden - Admin access required")
  }
  return session
}
