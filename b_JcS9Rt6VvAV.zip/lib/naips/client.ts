// NAIPS (National Aeronautical Information Processing System) Integration
// This module provides the architecture for connecting to NAIPS SOAP web services
// Credentials must be obtained from Airservices Australia

import { NAIPSFlightPlan, WeatherBriefing, MetarData, TafData, NotamData } from "@/lib/types/aviation"
import { parseMetar, parseTaf } from "@/lib/weather/decoder"

// NAIPS SOAP endpoints (production)
const NAIPS_ENDPOINTS = {
  briefing: "https://www.airservicesaustralia.com/naips/briefing",
  flightPlan: "https://www.airservicesaustralia.com/naips/flightplan",
  notam: "https://www.airservicesaustralia.com/naips/notam",
}

interface NAIPSConfig {
  username: string
  password: string
  timeout?: number
}

interface NAIPSResponse<T> {
  success: boolean
  data?: T
  error?: string
  rawResponse?: string
}

/**
 * NAIPS Client for interacting with Airservices Australia services
 * Note: This requires valid NAIPS credentials obtained from Airservices Australia
 */
export class NAIPSClient {
  private username: string
  private password: string
  private timeout: number
  private isConfigured: boolean

  constructor(config?: NAIPSConfig) {
    this.username = config?.username || process.env.NAIPS_USERNAME || ""
    this.password = config?.password || process.env.NAIPS_PASSWORD || ""
    this.timeout = config?.timeout || 30000
    this.isConfigured = !!(this.username && this.password)
  }

  /**
   * Check if NAIPS credentials are configured
   */
  isAvailable(): boolean {
    return this.isConfigured
  }

  /**
   * Get weather briefing for a route
   * Includes METAR, TAF, SIGMET, AIRMET for route points
   */
  async getWeatherBriefing(
    departure: string,
    destination: string,
    alternates: string[] = [],
    route?: string
  ): Promise<NAIPSResponse<WeatherBriefing>> {
    if (!this.isConfigured) {
      return {
        success: false,
        error: "NAIPS credentials not configured. Please add NAIPS_USERNAME and NAIPS_PASSWORD environment variables.",
      }
    }

    try {
      // Build SOAP request for weather briefing
      const soapRequest = this.buildBriefingRequest(departure, destination, alternates, route)

      const response = await fetch(NAIPS_ENDPOINTS.briefing, {
        method: "POST",
        headers: {
          "Content-Type": "text/xml; charset=utf-8",
          SOAPAction: "getBriefing",
        },
        body: soapRequest,
        signal: AbortSignal.timeout(this.timeout),
      })

      if (!response.ok) {
        throw new Error(`NAIPS request failed: ${response.status} ${response.statusText}`)
      }

      const xmlResponse = await response.text()
      const briefing = this.parseBriefingResponse(xmlResponse)

      return {
        success: true,
        data: briefing,
        rawResponse: xmlResponse,
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred",
      }
    }
  }

  /**
   * Submit a flight plan to NAIPS
   */
  async submitFlightPlan(plan: NAIPSFlightPlan): Promise<NAIPSResponse<{ reference: string }>> {
    if (!this.isConfigured) {
      return {
        success: false,
        error: "NAIPS credentials not configured",
      }
    }

    try {
      const soapRequest = this.buildFlightPlanRequest(plan)

      const response = await fetch(NAIPS_ENDPOINTS.flightPlan, {
        method: "POST",
        headers: {
          "Content-Type": "text/xml; charset=utf-8",
          SOAPAction: "submitFlightPlan",
        },
        body: soapRequest,
        signal: AbortSignal.timeout(this.timeout),
      })

      if (!response.ok) {
        throw new Error(`Flight plan submission failed: ${response.status}`)
      }

      const xmlResponse = await response.text()
      const reference = this.parseFlightPlanResponse(xmlResponse)

      return {
        success: true,
        data: { reference },
        rawResponse: xmlResponse,
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred",
      }
    }
  }

  /**
   * Cancel a submitted flight plan
   */
  async cancelFlightPlan(reference: string): Promise<NAIPSResponse<void>> {
    if (!this.isConfigured) {
      return { success: false, error: "NAIPS credentials not configured" }
    }

    try {
      const soapRequest = this.buildCancelRequest(reference)

      const response = await fetch(NAIPS_ENDPOINTS.flightPlan, {
        method: "POST",
        headers: {
          "Content-Type": "text/xml; charset=utf-8",
          SOAPAction: "cancelFlightPlan",
        },
        body: soapRequest,
        signal: AbortSignal.timeout(this.timeout),
      })

      if (!response.ok) {
        throw new Error(`Flight plan cancellation failed: ${response.status}`)
      }

      return { success: true }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred",
      }
    }
  }

  /**
   * Get NOTAMs for locations
   */
  async getNotams(locations: string[]): Promise<NAIPSResponse<NotamData[]>> {
    if (!this.isConfigured) {
      return { success: false, error: "NAIPS credentials not configured" }
    }

    try {
      const soapRequest = this.buildNotamRequest(locations)

      const response = await fetch(NAIPS_ENDPOINTS.notam, {
        method: "POST",
        headers: {
          "Content-Type": "text/xml; charset=utf-8",
          SOAPAction: "getNotams",
        },
        body: soapRequest,
        signal: AbortSignal.timeout(this.timeout),
      })

      if (!response.ok) {
        throw new Error(`NOTAM request failed: ${response.status}`)
      }

      const xmlResponse = await response.text()
      const notams = this.parseNotamResponse(xmlResponse)

      return {
        success: true,
        data: notams,
        rawResponse: xmlResponse,
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred",
      }
    }
  }

  // Private helper methods for building SOAP requests

  private buildBriefingRequest(
    departure: string,
    destination: string,
    alternates: string[],
    route?: string
  ): string {
    return `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:naips="http://www.airservicesaustralia.com/naips">
  <soap:Header>
    <naips:Authentication>
      <naips:Username>${this.escapeXml(this.username)}</naips:Username>
      <naips:Password>${this.escapeXml(this.password)}</naips:Password>
    </naips:Authentication>
  </soap:Header>
  <soap:Body>
    <naips:GetBriefingRequest>
      <naips:Departure>${departure}</naips:Departure>
      <naips:Destination>${destination}</naips:Destination>
      ${alternates.map((alt) => `<naips:Alternate>${alt}</naips:Alternate>`).join("\n      ")}
      ${route ? `<naips:Route>${this.escapeXml(route)}</naips:Route>` : ""}
      <naips:IncludeMETAR>true</naips:IncludeMETAR>
      <naips:IncludeTAF>true</naips:IncludeTAF>
      <naips:IncludeSIGMET>true</naips:IncludeSIGMET>
      <naips:IncludeAIRMET>true</naips:IncludeAIRMET>
      <naips:IncludeNOTAM>true</naips:IncludeNOTAM>
    </naips:GetBriefingRequest>
  </soap:Body>
</soap:Envelope>`
  }

  private buildFlightPlanRequest(plan: NAIPSFlightPlan): string {
    const icaoMessage = this.formatICAOFlightPlan(plan)
    
    return `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:naips="http://www.airservicesaustralia.com/naips">
  <soap:Header>
    <naips:Authentication>
      <naips:Username>${this.escapeXml(this.username)}</naips:Username>
      <naips:Password>${this.escapeXml(this.password)}</naips:Password>
    </naips:Authentication>
  </soap:Header>
  <soap:Body>
    <naips:SubmitFlightPlanRequest>
      <naips:FlightPlan>${this.escapeXml(icaoMessage)}</naips:FlightPlan>
    </naips:SubmitFlightPlanRequest>
  </soap:Body>
</soap:Envelope>`
  }

  private buildCancelRequest(reference: string): string {
    return `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:naips="http://www.airservicesaustralia.com/naips">
  <soap:Header>
    <naips:Authentication>
      <naips:Username>${this.escapeXml(this.username)}</naips:Username>
      <naips:Password>${this.escapeXml(this.password)}</naips:Password>
    </naips:Authentication>
  </soap:Header>
  <soap:Body>
    <naips:CancelFlightPlanRequest>
      <naips:Reference>${reference}</naips:Reference>
    </naips:CancelFlightPlanRequest>
  </soap:Body>
</soap:Envelope>`
  }

  private buildNotamRequest(locations: string[]): string {
    return `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:naips="http://www.airservicesaustralia.com/naips">
  <soap:Header>
    <naips:Authentication>
      <naips:Username>${this.escapeXml(this.username)}</naips:Username>
      <naips:Password>${this.escapeXml(this.password)}</naips:Password>
    </naips:Authentication>
  </soap:Header>
  <soap:Body>
    <naips:GetNotamsRequest>
      ${locations.map((loc) => `<naips:Location>${loc}</naips:Location>`).join("\n      ")}
    </naips:GetNotamsRequest>
  </soap:Body>
</soap:Envelope>`
  }

  /**
   * Format flight plan as ICAO FPL message
   */
  private formatICAOFlightPlan(plan: NAIPSFlightPlan): string {
    const field18Parts: string[] = []

    // PBN capabilities if present
    if (plan.supplementary.remarks?.includes("PBN/")) {
      // Already included
    }

    // Build Field 18 (Other Information)
    const field18 = plan.otherInfo || "0"

    // Build Field 19 (Supplementary Information)
    const field19 = [
      `E/${plan.supplementary.endurance}`,
      `P/${plan.supplementary.persons}`,
      plan.supplementary.emergencyEquipment ? `R/${plan.supplementary.emergencyEquipment}` : null,
      plan.supplementary.survival ? `S/${plan.supplementary.survival}` : null,
      plan.supplementary.dinghies ? `D/${plan.supplementary.dinghies}` : null,
      plan.supplementary.aircraft ? `A/${plan.supplementary.aircraft}` : null,
      `C/${plan.supplementary.pilotName}`,
    ]
      .filter(Boolean)
      .join(" ")

    return `(FPL-${plan.aircraftId}-${plan.flightRules}${plan.flightType}
-${plan.number}${plan.aircraftType}/${plan.wakeTurbulence}-${plan.equipment}/${plan.surveillance}
-${plan.departure}${plan.departureTime}
-${plan.cruiseSpeed}${plan.cruiseAltitude} ${plan.route}
-${plan.destination}${plan.eet} ${plan.alternates.join(" ")}
-${field18}
-${field19})`
  }

  // Response parsing methods

  private parseBriefingResponse(xml: string): WeatherBriefing {
    // In a real implementation, this would parse the SOAP XML response
    // For now, return a structured placeholder
    const briefing: WeatherBriefing = {
      requestTime: new Date(),
      route: "",
      metars: [],
      tafs: [],
      sigmets: [],
      airmets: [],
      notams: [],
    }

    // Parse METAR elements from XML
    const metarMatches = xml.matchAll(/<metar>(.*?)<\/metar>/gi)
    for (const match of metarMatches) {
      try {
        briefing.metars.push(parseMetar(match[1]))
      } catch {
        // Skip invalid METARs
      }
    }

    // Parse TAF elements
    const tafMatches = xml.matchAll(/<taf>(.*?)<\/taf>/gi)
    for (const match of tafMatches) {
      try {
        briefing.tafs.push(parseTaf(match[1]))
      } catch {
        // Skip invalid TAFs
      }
    }

    return briefing
  }

  private parseFlightPlanResponse(xml: string): string {
    // Extract reference number from response
    const match = xml.match(/<Reference>(.*?)<\/Reference>/i)
    return match ? match[1] : ""
  }

  private parseNotamResponse(xml: string): NotamData[] {
    const notams: NotamData[] = []
    
    // Parse NOTAM elements from XML response
    const notamMatches = xml.matchAll(/<Notam>(.*?)<\/Notam>/gis)
    for (const match of notamMatches) {
      const notamXml = match[1]
      
      const id = this.extractXmlValue(notamXml, "Id") || ""
      const type = this.extractXmlValue(notamXml, "Type") || "NOTAMN"
      const location = this.extractXmlValue(notamXml, "Location") || ""
      const text = this.extractXmlValue(notamXml, "Text") || ""
      const validFrom = this.extractXmlValue(notamXml, "ValidFrom")
      const validTo = this.extractXmlValue(notamXml, "ValidTo")

      notams.push({
        id,
        type,
        location,
        text,
        validFrom: validFrom ? new Date(validFrom) : new Date(),
        validTo: validTo ? new Date(validTo) : undefined,
        isPermanent: !validTo,
      })
    }

    return notams
  }

  private extractXmlValue(xml: string, tag: string): string | null {
    const match = xml.match(new RegExp(`<${tag}>(.*?)<\/${tag}>`, "i"))
    return match ? match[1] : null
  }

  private escapeXml(str: string): string {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;")
  }
}

// Create a singleton instance
let naipsClient: NAIPSClient | null = null

export function getNAIPSClient(): NAIPSClient {
  if (!naipsClient) {
    naipsClient = new NAIPSClient()
  }
  return naipsClient
}

/**
 * Fallback weather data from BOM when NAIPS is not available
 * Uses publicly available aviation weather data
 */
export async function getFallbackWeather(
  stations: string[]
): Promise<{ metars: MetarData[]; tafs: TafData[] }> {
  const metars: MetarData[] = []
  const tafs: TafData[] = []

  // BOM provides aviation weather at specific endpoints
  // These are publicly accessible without authentication
  try {
    for (const station of stations) {
      // Try to fetch from ADDS (Aviation Digital Data Service) as fallback
      const metarUrl = `https://aviationweather.gov/api/data/metar?ids=${station}&format=raw`
      const tafUrl = `https://aviationweather.gov/api/data/taf?ids=${station}&format=raw`

      const [metarRes, tafRes] = await Promise.allSettled([
        fetch(metarUrl),
        fetch(tafUrl),
      ])

      if (metarRes.status === "fulfilled" && metarRes.value.ok) {
        const raw = await metarRes.value.text()
        if (raw.trim()) {
          metars.push(parseMetar(raw.trim()))
        }
      }

      if (tafRes.status === "fulfilled" && tafRes.value.ok) {
        const raw = await tafRes.value.text()
        if (raw.trim()) {
          tafs.push(parseTaf(raw.trim()))
        }
      }
    }
  } catch (error) {
    console.error("Error fetching fallback weather:", error)
  }

  return { metars, tafs }
}
