// Aviation utility functions for calculations and conversions

import { Coordinates, CGEnvelopePoint, LSALTCalculation } from "@/lib/types/aviation"

// Constants
export const EARTH_RADIUS_NM = 3440.065 // Nautical miles
export const FEET_PER_METER = 3.28084
export const NM_PER_KM = 0.539957
export const GALLONS_PER_LITRE = 0.264172
export const LBS_PER_KG = 2.20462
export const AVGAS_LBS_PER_GAL = 6.0
export const JET_A_LBS_PER_GAL = 6.7

/**
 * Calculate great circle distance between two points
 * @returns Distance in nautical miles
 */
export function calculateDistance(from: Coordinates, to: Coordinates): number {
  const lat1 = toRadians(from.latitude)
  const lat2 = toRadians(to.latitude)
  const dLat = toRadians(to.latitude - from.latitude)
  const dLon = toRadians(to.longitude - from.longitude)

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) * Math.sin(dLon / 2)

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return EARTH_RADIUS_NM * c
}

/**
 * Calculate true track/bearing from one point to another
 * @returns True track in degrees (0-360)
 */
export function calculateTrueTrack(from: Coordinates, to: Coordinates): number {
  const lat1 = toRadians(from.latitude)
  const lat2 = toRadians(to.latitude)
  const dLon = toRadians(to.longitude - from.longitude)

  const y = Math.sin(dLon) * Math.cos(lat2)
  const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon)

  let track = toDegrees(Math.atan2(y, x))
  return (track + 360) % 360
}

/**
 * Calculate magnetic track from true track
 * @param trueTrack True track in degrees
 * @param magneticVariation Magnetic variation (positive = East, negative = West)
 * @returns Magnetic track in degrees
 */
export function trueToMagnetic(trueTrack: number, magneticVariation: number): number {
  let magnetic = trueTrack - magneticVariation
  return (magnetic + 360) % 360
}

/**
 * Calculate wind correction angle and ground speed
 */
export function calculateWindCorrection(
  trueTrack: number,
  tas: number,
  windDirection: number,
  windSpeed: number
): { wca: number; groundSpeed: number; heading: number } {
  // Convert to radians
  const trackRad = toRadians(trueTrack)
  const windDirRad = toRadians(windDirection)

  // Wind angle relative to track (wind is reported as FROM direction)
  const windAngle = windDirRad - trackRad + Math.PI

  // Cross wind component
  const crossWind = windSpeed * Math.sin(windAngle)

  // Head/tail wind component
  const headWind = windSpeed * Math.cos(windAngle)

  // Wind correction angle
  const wcaRad = Math.asin(crossWind / tas)
  const wca = toDegrees(wcaRad)

  // Ground speed
  const groundSpeed = tas * Math.cos(wcaRad) + headWind

  // True heading
  let heading = trueTrack + wca
  heading = (heading + 360) % 360

  return { wca, groundSpeed, heading }
}

/**
 * Calculate estimated time enroute for a leg
 * @param distance Distance in NM
 * @param groundSpeed Ground speed in knots
 * @returns Time in minutes
 */
export function calculateEET(distance: number, groundSpeed: number): number {
  if (groundSpeed <= 0) return 0
  return (distance / groundSpeed) * 60
}

/**
 * Calculate fuel burn for a leg
 * @param time Time in minutes
 * @param fuelFlow Fuel flow in gallons per hour
 * @returns Fuel in gallons
 */
export function calculateFuelBurn(time: number, fuelFlow: number): number {
  return (time / 60) * fuelFlow
}

/**
 * Calculate Lowest Safe Altitude (LSALT) for a route leg
 * Australian rules:
 * - VFR: 1000ft above highest obstacle within 5nm of track
 * - IFR route: 1000ft above highest obstacle within 10nm, rounded up to next 1000ft
 * - IFR area: 2000ft above highest obstacle
 */
export function calculateLSALT(
  maxTerrainElevation: number,
  flightRules: "VFR" | "IFR",
  isAreaNavigation: boolean = false
): LSALTCalculation {
  const bufferDistance = flightRules === "VFR" ? 5 : 10
  let clearance = 1000

  if (flightRules === "IFR" && isAreaNavigation) {
    clearance = 2000
  }

  // VFR rounds to nearest 100ft, IFR rounds to nearest 1000ft
  const roundUp = flightRules === "VFR" ? 100 : 1000

  // Calculate raw LSALT
  const rawLSALT = maxTerrainElevation + clearance

  // Round up
  const calculatedLSALT = Math.ceil(rawLSALT / roundUp) * roundUp

  return {
    leg: { from: "", to: "" },
    maxTerrainElevation,
    obstacles: 0,
    bufferDistance,
    roundUp,
    clearance,
    calculatedLSALT,
    finalLSALT: calculatedLSALT,
  }
}

/**
 * Validate CG is within envelope
 */
export function validateCGEnvelope(
  weight: number,
  cg: number,
  envelope: CGEnvelopePoint[]
): boolean {
  if (envelope.length < 2) return false

  // Sort envelope by weight
  const sorted = [...envelope].sort((a, b) => a.weight - b.weight)

  // Find the envelope limits at this weight
  let fwdLimit: number | null = null
  let aftLimit: number | null = null

  for (let i = 0; i < sorted.length - 1; i++) {
    const current = sorted[i]
    const next = sorted[i + 1]

    if (weight >= current.weight && weight <= next.weight) {
      // Interpolate limits
      const ratio = (weight - current.weight) / (next.weight - current.weight)
      fwdLimit = current.fwdCG + ratio * (next.fwdCG - current.fwdCG)
      aftLimit = current.aftCG + ratio * (next.aftCG - current.aftCG)
      break
    }
  }

  if (fwdLimit === null || aftLimit === null) return false

  return cg >= fwdLimit && cg <= aftLimit
}

/**
 * Calculate fuel reserves based on Australian requirements
 * VFR Day: 30 minutes at normal cruise
 * VFR Night: 45 minutes at normal cruise  
 * IFR: 45 minutes at normal cruise
 */
export function calculateFuelReserves(
  flightRules: "VFR" | "IFR" | "NVFR",
  fuelFlow: number, // gph
  tripFuel: number
): {
  contingency: number
  fixedReserve: number
  totalMinimum: number
} {
  // Contingency: 10% of trip fuel
  const contingency = tripFuel * 0.1

  // Fixed reserve based on flight rules
  let fixedReserveMinutes = 30
  if (flightRules === "IFR" || flightRules === "NVFR") {
    fixedReserveMinutes = 45
  }

  const fixedReserve = (fixedReserveMinutes / 60) * fuelFlow

  return {
    contingency,
    fixedReserve,
    totalMinimum: tripFuel + contingency + fixedReserve,
  }
}

/**
 * Determine VFR cruising altitude based on magnetic track
 * Australian hemispherical rule:
 * - 000-179 magnetic: Odd thousands + 500 (1500, 3500, 5500...)
 * - 180-359 magnetic: Even thousands + 500 (2500, 4500, 6500...)
 * Above 10,000ft:
 * - 000-179 magnetic: FL115, FL135, FL155...
 * - 180-359 magnetic: FL125, FL145, FL165...
 */
export function getVFRCruisingAltitude(
  magneticTrack: number,
  minAltitude: number
): number[] {
  const isOdd = magneticTrack >= 0 && magneticTrack < 180
  const altitudes: number[] = []

  // Below FL100 (10,000ft)
  const startAlt = isOdd ? 1500 : 2500
  for (let alt = startAlt; alt <= 9500; alt += 2000) {
    if (alt >= minAltitude) {
      altitudes.push(alt)
    }
  }

  // Above FL100
  const startFL = isOdd ? 11500 : 12500
  for (let alt = startFL; alt <= 24500; alt += 2000) {
    if (alt >= minAltitude) {
      altitudes.push(alt)
    }
  }

  return altitudes.slice(0, 5) // Return first 5 options
}

/**
 * Determine IFR cruising altitude based on magnetic track
 * Australian hemispherical rule:
 * - 000-179 magnetic: Odd thousands (1000, 3000, 5000...)
 * - 180-359 magnetic: Even thousands (2000, 4000, 6000...)
 * In RVSM airspace (FL290-FL410):
 * - 000-179: FL290, FL310, FL330...
 * - 180-359: FL300, FL320, FL340...
 */
export function getIFRCruisingAltitude(
  magneticTrack: number,
  minAltitude: number
): number[] {
  const isOdd = magneticTrack >= 0 && magneticTrack < 180
  const altitudes: number[] = []

  // Standard levels
  const start = isOdd ? 1000 : 2000
  for (let alt = start; alt <= 40000; alt += 2000) {
    if (alt >= minAltitude) {
      altitudes.push(alt)
    }
  }

  return altitudes.slice(0, 6) // Return first 6 options
}

/**
 * Format time in HHMM format
 */
export function formatTime(date: Date): string {
  return date.toISOString().slice(11, 16).replace(":", "")
}

/**
 * Format altitude for flight plan (e.g., A055, F350)
 */
export function formatAltitude(altitude: number): string {
  if (altitude >= 10000) {
    // Flight level
    return `F${Math.round(altitude / 100).toString().padStart(3, "0")}`
  }
  // Altitude in hundreds of feet
  return `A${Math.round(altitude / 100).toString().padStart(3, "0")}`
}

/**
 * Format speed for flight plan (e.g., N0120, M085)
 */
export function formatSpeed(speed: number, isMach: boolean = false): string {
  if (isMach) {
    return `M${Math.round(speed * 100).toString().padStart(3, "0")}`
  }
  return `N${Math.round(speed).toString().padStart(4, "0")}`
}

/**
 * Parse ICAO equipment codes
 */
export function parseEquipmentCodes(codes: string): {
  communication: string[]
  navigation: string[]
  approach: string[]
  surveillance: string[]
} {
  const result = {
    communication: [] as string[],
    navigation: [] as string[],
    approach: [] as string[],
    surveillance: [] as string[],
  }

  // Standard equipment codes
  const equipmentMap: Record<string, { category: keyof typeof result; description: string }> = {
    S: { category: "navigation", description: "Standard (VOR, ILS, VHF)" },
    A: { category: "navigation", description: "GBAS landing system" },
    B: { category: "navigation", description: "LPV" },
    C: { category: "navigation", description: "LORAN C" },
    D: { category: "navigation", description: "DME" },
    F: { category: "navigation", description: "ADF" },
    G: { category: "navigation", description: "GNSS" },
    H: { category: "communication", description: "HF RTF" },
    I: { category: "navigation", description: "INS" },
    J: { category: "communication", description: "Data link" },
    K: { category: "navigation", description: "MLS" },
    L: { category: "approach", description: "ILS" },
    M: { category: "communication", description: "SATCOM" },
    O: { category: "navigation", description: "VOR" },
    R: { category: "navigation", description: "PBN approved" },
    T: { category: "navigation", description: "TACAN" },
    U: { category: "communication", description: "UHF RTF" },
    V: { category: "communication", description: "VHF RTF" },
    W: { category: "navigation", description: "RVSM approved" },
    X: { category: "navigation", description: "MNPS approved" },
    Y: { category: "communication", description: "VHF 8.33kHz" },
    Z: { category: "navigation", description: "Other (see remarks)" },
  }

  for (const code of codes.split("")) {
    const equipment = equipmentMap[code.toUpperCase()]
    if (equipment) {
      result[equipment.category].push(`${code}: ${equipment.description}`)
    }
  }

  return result
}

// Utility functions
function toRadians(degrees: number): number {
  return degrees * (Math.PI / 180)
}

function toDegrees(radians: number): number {
  return radians * (180 / Math.PI)
}

/**
 * Get a point along a great circle route
 */
export function getIntermediatePoint(
  from: Coordinates,
  to: Coordinates,
  fraction: number
): Coordinates {
  const lat1 = toRadians(from.latitude)
  const lon1 = toRadians(from.longitude)
  const lat2 = toRadians(to.latitude)
  const lon2 = toRadians(to.longitude)

  const d = 2 * Math.asin(
    Math.sqrt(
      Math.pow(Math.sin((lat1 - lat2) / 2), 2) +
      Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin((lon1 - lon2) / 2), 2)
    )
  )

  const A = Math.sin((1 - fraction) * d) / Math.sin(d)
  const B = Math.sin(fraction * d) / Math.sin(d)

  const x = A * Math.cos(lat1) * Math.cos(lon1) + B * Math.cos(lat2) * Math.cos(lon2)
  const y = A * Math.cos(lat1) * Math.sin(lon1) + B * Math.cos(lat2) * Math.sin(lon2)
  const z = A * Math.sin(lat1) + B * Math.sin(lat2)

  return {
    latitude: toDegrees(Math.atan2(z, Math.sqrt(x * x + y * y))),
    longitude: toDegrees(Math.atan2(y, x)),
  }
}

/**
 * Generate points along a great circle route for display
 */
export function generateRoutePoints(
  from: Coordinates,
  to: Coordinates,
  numPoints: number = 20
): Coordinates[] {
  const points: Coordinates[] = [from]

  for (let i = 1; i < numPoints; i++) {
    const fraction = i / numPoints
    points.push(getIntermediatePoint(from, to, fraction))
  }

  points.push(to)
  return points
}

/**
 * Check if a point is within a polygon (for airspace checks)
 */
export function isPointInPolygon(
  point: Coordinates,
  polygon: number[][]
): boolean {
  const x = point.longitude
  const y = point.latitude
  let inside = false

  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i][0]
    const yi = polygon[i][1]
    const xj = polygon[j][0]
    const yj = polygon[j][1]

    if (((yi > y) !== (yj > y)) && (x < ((xj - xi) * (y - yi)) / (yj - yi) + xi)) {
      inside = !inside
    }
  }

  return inside
}
