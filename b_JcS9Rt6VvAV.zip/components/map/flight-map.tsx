"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import mapboxgl from "mapbox-gl"
import "mapbox-gl/dist/mapbox-gl.css"
import { cn } from "@/lib/utils"

// Australian bounds
const AUSTRALIA_BOUNDS: [[number, number], [number, number]] = [
  [110, -45], // Southwest
  [160, -10], // Northeast
]

const AUSTRALIA_CENTER: [number, number] = [133.7751, -25.2744]

export interface MapWaypoint {
  id: string
  identifier: string
  type: "AIRPORT" | "VOR" | "NDB" | "FIX" | "GPS"
  latitude: number
  longitude: number
  name?: string
  frequency?: number
}

export interface MapAirspace {
  id: string
  name: string
  type: string
  class?: string
  geometry: GeoJSON.Polygon
  lowerLimit: number
  upperLimit: number
}

export interface MapRoute {
  waypoints: MapWaypoint[]
  color?: string
}

interface FlightMapProps {
  className?: string
  waypoints?: MapWaypoint[]
  route?: MapRoute
  airspaces?: MapAirspace[]
  onMapClick?: (lngLat: { lng: number; lat: number }) => void
  onWaypointClick?: (waypoint: MapWaypoint) => void
  onWaypointAdd?: (waypoint: Partial<MapWaypoint>) => void
  interactive?: boolean
  showAirports?: boolean
  showNavaids?: boolean
  showAirspace?: boolean
  showRoute?: boolean
}

export function FlightMap({
  className,
  waypoints = [],
  route,
  airspaces = [],
  onMapClick,
  onWaypointClick,
  onWaypointAdd,
  interactive = true,
  showAirports = true,
  showNavaids = true,
  showAirspace = true,
  showRoute = true,
}: FlightMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<mapboxgl.Map | null>(null)
  const markersRef = useRef<mapboxgl.Marker[]>([])
  const [mapLoaded, setMapLoaded] = useState(false)
  const [mapError, setMapError] = useState<string | null>(null)

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || map.current) return

    const token = process.env.NEXT_PUBLIC_MAPBOX_TOKEN
    if (!token) {
      setMapError("Mapbox token not configured. Please add NEXT_PUBLIC_MAPBOX_TOKEN to environment variables.")
      return
    }

    mapboxgl.accessToken = token

    try {
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: "mapbox://styles/mapbox/dark-v11",
        center: AUSTRALIA_CENTER,
        zoom: 4,
        maxBounds: AUSTRALIA_BOUNDS,
        attributionControl: false,
      })

      map.current.addControl(new mapboxgl.NavigationControl(), "top-right")
      map.current.addControl(new mapboxgl.ScaleControl({ unit: "nautical" }), "bottom-left")
      map.current.addControl(
        new mapboxgl.AttributionControl({ compact: true }),
        "bottom-right"
      )

      map.current.on("load", () => {
        setMapLoaded(true)
        
        // Add empty sources for dynamic data
        if (map.current) {
          // Route line source
          map.current.addSource("route", {
            type: "geojson",
            data: {
              type: "FeatureCollection",
              features: [],
            },
          })

          // Route line layer
          map.current.addLayer({
            id: "route-line",
            type: "line",
            source: "route",
            layout: {
              "line-join": "round",
              "line-cap": "round",
            },
            paint: {
              "line-color": "#3b82f6",
              "line-width": 3,
              "line-opacity": 0.8,
            },
          })

          // Airspace source
          map.current.addSource("airspace", {
            type: "geojson",
            data: {
              type: "FeatureCollection",
              features: [],
            },
          })

          // Airspace fill layer
          map.current.addLayer({
            id: "airspace-fill",
            type: "fill",
            source: "airspace",
            paint: {
              "fill-color": [
                "match",
                ["get", "type"],
                "CTR", "#ef4444",
                "CTA", "#3b82f6",
                "DANGER", "#f97316",
                "RESTRICTED", "#ef4444",
                "PROHIBITED", "#dc2626",
                "#6b7280",
              ],
              "fill-opacity": 0.15,
            },
          })

          // Airspace outline layer
          map.current.addLayer({
            id: "airspace-outline",
            type: "line",
            source: "airspace",
            paint: {
              "line-color": [
                "match",
                ["get", "type"],
                "CTR", "#ef4444",
                "CTA", "#3b82f6",
                "DANGER", "#f97316",
                "RESTRICTED", "#ef4444",
                "PROHIBITED", "#dc2626",
                "#6b7280",
              ],
              "line-width": 2,
              "line-dasharray": [2, 2],
            },
          })
        }
      })

      // Click handler
      map.current.on("click", (e) => {
        if (onMapClick) {
          onMapClick({ lng: e.lngLat.lng, lat: e.lngLat.lat })
        }
      })

      // Context menu for adding waypoints
      map.current.on("contextmenu", (e) => {
        if (onWaypointAdd && interactive) {
          onWaypointAdd({
            latitude: e.lngLat.lat,
            longitude: e.lngLat.lng,
            type: "GPS",
          })
        }
      })
    } catch (error) {
      console.error("Error initializing map:", error)
      setMapError("Failed to initialize map")
    }

    return () => {
      if (map.current) {
        map.current.remove()
        map.current = null
      }
    }
  }, [onMapClick, onWaypointAdd, interactive])

  // Update route
  useEffect(() => {
    if (!map.current || !mapLoaded || !showRoute) return

    const routeSource = map.current.getSource("route") as mapboxgl.GeoJSONSource
    if (!routeSource) return

    if (route && route.waypoints.length > 1) {
      const coordinates = route.waypoints.map((wp) => [wp.longitude, wp.latitude])
      routeSource.setData({
        type: "FeatureCollection",
        features: [
          {
            type: "Feature",
            properties: {},
            geometry: {
              type: "LineString",
              coordinates,
            },
          },
        ],
      })

      // Update route line color if specified
      if (route.color) {
        map.current.setPaintProperty("route-line", "line-color", route.color)
      }
    } else {
      routeSource.setData({
        type: "FeatureCollection",
        features: [],
      })
    }
  }, [route, mapLoaded, showRoute])

  // Update airspace
  useEffect(() => {
    if (!map.current || !mapLoaded || !showAirspace) return

    const airspaceSource = map.current.getSource("airspace") as mapboxgl.GeoJSONSource
    if (!airspaceSource) return

    const features = airspaces.map((airspace) => ({
      type: "Feature" as const,
      properties: {
        id: airspace.id,
        name: airspace.name,
        type: airspace.type,
        class: airspace.class,
        lowerLimit: airspace.lowerLimit,
        upperLimit: airspace.upperLimit,
      },
      geometry: airspace.geometry,
    }))

    airspaceSource.setData({
      type: "FeatureCollection",
      features,
    })
  }, [airspaces, mapLoaded, showAirspace])

  // Update waypoint markers
  useEffect(() => {
    if (!map.current || !mapLoaded) return

    // Clear existing markers
    markersRef.current.forEach((marker) => marker.remove())
    markersRef.current = []

    // Add waypoint markers
    const allWaypoints = [
      ...waypoints,
      ...(route?.waypoints || []),
    ].filter((wp, index, self) => 
      index === self.findIndex((w) => w.id === wp.id)
    )

    allWaypoints.forEach((waypoint) => {
      // Skip if not showing this type
      if (waypoint.type === "AIRPORT" && !showAirports) return
      if (["VOR", "NDB", "FIX"].includes(waypoint.type) && !showNavaids) return

      const el = document.createElement("div")
      el.className = "waypoint-marker"
      el.style.cssText = `
        width: 24px;
        height: 24px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: bold;
        color: white;
        border: 2px solid white;
        box-shadow: 0 2px 4px rgba(0,0,0,0.3);
      `

      // Color based on type
      switch (waypoint.type) {
        case "AIRPORT":
          el.style.backgroundColor = "#3b82f6"
          el.textContent = "AD"
          break
        case "VOR":
          el.style.backgroundColor = "#22c55e"
          el.textContent = "V"
          break
        case "NDB":
          el.style.backgroundColor = "#f97316"
          el.textContent = "N"
          break
        case "FIX":
          el.style.backgroundColor = "#8b5cf6"
          el.textContent = "F"
          break
        default:
          el.style.backgroundColor = "#6b7280"
          el.textContent = "W"
      }

      const marker = new mapboxgl.Marker(el)
        .setLngLat([waypoint.longitude, waypoint.latitude])
        .setPopup(
          new mapboxgl.Popup({ offset: 25 }).setHTML(`
            <div class="p-2">
              <div class="font-bold text-sm">${waypoint.identifier}</div>
              ${waypoint.name ? `<div class="text-xs text-gray-500">${waypoint.name}</div>` : ""}
              <div class="text-xs mt-1">
                <span class="font-medium">${waypoint.type}</span>
                ${waypoint.frequency ? ` - ${waypoint.frequency.toFixed(2)} MHz` : ""}
              </div>
              <div class="text-xs text-gray-400 mt-1">
                ${waypoint.latitude.toFixed(4)}, ${waypoint.longitude.toFixed(4)}
              </div>
            </div>
          `)
        )
        .addTo(map.current!)

      el.addEventListener("click", () => {
        if (onWaypointClick) {
          onWaypointClick(waypoint)
        }
      })

      markersRef.current.push(marker)
    })
  }, [waypoints, route, mapLoaded, showAirports, showNavaids, onWaypointClick])

  // Fit bounds to route
  const fitToRoute = useCallback(() => {
    if (!map.current || !route || route.waypoints.length < 2) return

    const bounds = new mapboxgl.LngLatBounds()
    route.waypoints.forEach((wp) => {
      bounds.extend([wp.longitude, wp.latitude])
    })

    map.current.fitBounds(bounds, {
      padding: 50,
      maxZoom: 10,
    })
  }, [route])

  if (mapError) {
    return (
      <div
        className={cn(
          "flex items-center justify-center bg-muted text-muted-foreground",
          className
        )}
      >
        <div className="text-center p-4">
          <p className="font-medium">Map Error</p>
          <p className="text-sm mt-1">{mapError}</p>
        </div>
      </div>
    )
  }

  return (
    <div className={cn("relative", className)}>
      <div ref={mapContainer} className="absolute inset-0" />
      
      {/* Map controls overlay */}
      {mapLoaded && route && route.waypoints.length > 1 && (
        <div className="absolute top-4 left-4 z-10">
          <button
            onClick={fitToRoute}
            className="bg-background/90 backdrop-blur-sm border border-border rounded-md px-3 py-1.5 text-sm font-medium hover:bg-muted transition-colors"
          >
            Fit Route
          </button>
        </div>
      )}

      {/* Loading indicator */}
      {!mapLoaded && !mapError && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted">
          <div className="text-muted-foreground">Loading map...</div>
        </div>
      )}
    </div>
  )
}
