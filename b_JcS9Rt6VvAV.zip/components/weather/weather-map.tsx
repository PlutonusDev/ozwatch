"use client";

import { useEffect, useRef, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Layers, RefreshCw } from "lucide-react";

interface Props {
  stations: string[];
}

const RADAR_LAYERS = {
  rain: "Rain Radar",
  satellite: "Satellite IR",
  lightning: "Lightning",
  wind: "Surface Wind",
};

// BOM radar locations for Australia
const BOM_RADARS: Record<string, { name: string; lat: number; lon: number; id: string }> = {
  sydney: { name: "Sydney (Terrey Hills)", lat: -33.701, lon: 151.21, id: "IDR714" },
  melbourne: { name: "Melbourne", lat: -37.855, lon: 144.756, id: "IDR024" },
  brisbane: { name: "Brisbane (Mt Stapylton)", lat: -27.718, lon: 153.24, id: "IDR664" },
  perth: { name: "Perth", lat: -32.392, lon: 115.867, id: "IDR703" },
  adelaide: { name: "Adelaide (Buckland Park)", lat: -34.617, lon: 138.469, id: "IDR644" },
  darwin: { name: "Darwin (Berrimah)", lat: -12.457, lon: 130.927, id: "IDR633" },
  hobart: { name: "Hobart (Mt Koonya)", lat: -43.112, lon: 147.806, id: "IDR373" },
  cairns: { name: "Cairns", lat: -16.817, lon: 145.683, id: "IDR193" },
};

export function WeatherMap({ stations }: Props) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<mapboxgl.Map | null>(null);
  const [selectedLayer, setSelectedLayer] = useState<string>("rain");
  const [selectedRadar, setSelectedRadar] = useState<string>("sydney");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!mapRef.current || mapInstance.current) return;

    // Check for Mapbox token
    const mapboxToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;
    if (!mapboxToken) {
      console.warn("Mapbox token not configured");
      return;
    }

    import("mapbox-gl").then((mapboxgl) => {
      mapboxgl.default.accessToken = mapboxToken;

      const map = new mapboxgl.default.Map({
        container: mapRef.current!,
        style: "mapbox://styles/mapbox/dark-v11",
        center: [134, -28], // Center of Australia
        zoom: 4,
      });

      map.on("load", () => {
        // Add weather radar overlay (placeholder - actual BOM radar requires authentication)
        map.addSource("radar-overlay", {
          type: "raster",
          tiles: [
            // This would be the actual BOM radar tile URL with authentication
            `https://api.weather.bom.gov.au/radar/${BOM_RADARS[selectedRadar].id}/{z}/{x}/{y}.png`,
          ],
          tileSize: 256,
        });

        // Note: BOM radar requires authentication, this is a placeholder
        // In production, you would proxy through your backend with proper auth
      });

      map.addControl(new mapboxgl.default.NavigationControl(), "top-right");
      mapInstance.current = map;
    });

    return () => {
      mapInstance.current?.remove();
      mapInstance.current = null;
    };
  }, []);

  // Update radar source when selection changes
  useEffect(() => {
    if (!mapInstance.current) return;
    const map = mapInstance.current;

    // Center on selected radar
    const radar = BOM_RADARS[selectedRadar];
    if (radar) {
      map.flyTo({
        center: [radar.lon, radar.lat],
        zoom: 7,
        duration: 1000,
      });
    }
  }, [selectedRadar]);

  return (
    <div className="h-full flex flex-col gap-4">
      {/* Controls */}
      <Card>
        <CardContent className="py-3">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Layers className="h-4 w-4 text-muted-foreground" />
              <Label className="text-sm">Layer</Label>
              <Select value={selectedLayer} onValueChange={setSelectedLayer}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(RADAR_LAYERS).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              <Label className="text-sm">Radar</Label>
              <Select value={selectedRadar} onValueChange={setSelectedRadar}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(BOM_RADARS).map(([key, radar]) => (
                    <SelectItem key={key} value={key}>
                      {radar.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button variant="outline" size="sm" disabled={isLoading}>
              {isLoading ? (
                <RefreshCw className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              <span className="ml-2">Refresh</span>
            </Button>

            <div className="ml-auto text-xs text-muted-foreground">
              Weather radar data from Bureau of Meteorology
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Map */}
      <div className="flex-1 relative rounded-lg overflow-hidden border">
        {!process.env.NEXT_PUBLIC_MAPBOX_TOKEN ? (
          <div className="absolute inset-0 flex items-center justify-center bg-muted">
            <div className="text-center p-8">
              <Layers className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
              <p className="text-muted-foreground">Weather map requires Mapbox configuration</p>
              <p className="text-sm text-muted-foreground mt-2">
                Add NEXT_PUBLIC_MAPBOX_TOKEN to your environment variables
              </p>
            </div>
          </div>
        ) : (
          <div ref={mapRef} className="absolute inset-0" />
        )}

        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-background/90 backdrop-blur-sm rounded-lg p-3 border">
          <div className="text-xs font-medium mb-2">Radar Intensity</div>
          <div className="flex items-center gap-1">
            <div className="w-4 h-3 bg-blue-300 rounded-sm" />
            <div className="w-4 h-3 bg-green-400 rounded-sm" />
            <div className="w-4 h-3 bg-yellow-400 rounded-sm" />
            <div className="w-4 h-3 bg-orange-500 rounded-sm" />
            <div className="w-4 h-3 bg-red-500 rounded-sm" />
            <div className="w-4 h-3 bg-purple-600 rounded-sm" />
          </div>
          <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
            <span>Light</span>
            <span>Heavy</span>
          </div>
        </div>

        {/* Station markers info */}
        {stations.length > 0 && (
          <div className="absolute top-4 left-4 bg-background/90 backdrop-blur-sm rounded-lg p-3 border">
            <div className="text-xs font-medium mb-1">Stations</div>
            <div className="flex flex-wrap gap-1">
              {stations.map((station) => (
                <span
                  key={station}
                  className="px-2 py-0.5 bg-primary/20 text-primary rounded text-xs font-mono"
                >
                  {station}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
