"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Wind, 
  Thermometer, 
  Eye, 
  Droplets, 
  Cloud, 
  ArrowUp, 
  Gauge,
  MapPin,
  Clock
} from "lucide-react";

interface DecodedWeather {
  raw: string;
  type: "METAR" | "SPECI" | "TAF";
  station: string;
  time: string;
  wind?: {
    direction: number | "VRB";
    speed: number;
    gust?: number;
    unit: string;
    variable?: { from: number; to: number };
  };
  visibility?: {
    value: number;
    unit: string;
    cavok?: boolean;
  };
  weather?: Array<{
    intensity?: string;
    descriptor?: string;
    phenomena: string[];
    raw: string;
  }>;
  clouds?: Array<{
    type: string;
    height: number;
    cloudType?: string;
  }>;
  temperature?: {
    temp: number;
    dewpoint: number;
  };
  pressure?: {
    value: number;
    unit: string;
  };
  trend?: string;
  remarks?: string;
  flightCategory?: "VFR" | "MVFR" | "IFR" | "LIFR";
  decoded?: string;
}

interface Props {
  weather: DecodedWeather;
  showForecast?: boolean;
}

const FLIGHT_CATEGORY_COLORS: Record<string, string> = {
  VFR: "bg-green-500/20 text-green-500 border-green-500/50",
  MVFR: "bg-blue-500/20 text-blue-500 border-blue-500/50",
  IFR: "bg-red-500/20 text-red-500 border-red-500/50",
  LIFR: "bg-purple-500/20 text-purple-500 border-purple-500/50",
};

const WEATHER_PHENOMENA: Record<string, string> = {
  RA: "Rain",
  SN: "Snow",
  DZ: "Drizzle",
  FG: "Fog",
  BR: "Mist",
  HZ: "Haze",
  TS: "Thunderstorm",
  SH: "Showers",
  GR: "Hail",
  FZ: "Freezing",
  VC: "Vicinity",
  MI: "Shallow",
  BC: "Patches",
  PR: "Partial",
  BL: "Blowing",
  DR: "Drifting",
  SQ: "Squall",
  FC: "Funnel Cloud",
  SS: "Sandstorm",
  DS: "Duststorm",
  PO: "Dust/Sand Whirls",
  SA: "Sand",
  DU: "Dust",
  VA: "Volcanic Ash",
  IC: "Ice Crystals",
  PL: "Ice Pellets",
  GS: "Small Hail",
  UP: "Unknown Precipitation",
};

const CLOUD_TYPES: Record<string, string> = {
  SKC: "Sky Clear",
  CLR: "Clear",
  FEW: "Few (1-2 oktas)",
  SCT: "Scattered (3-4 oktas)",
  BKN: "Broken (5-7 oktas)",
  OVC: "Overcast (8 oktas)",
  VV: "Vertical Visibility",
  NSC: "No Significant Cloud",
  NCD: "No Cloud Detected",
};

function formatWindDirection(direction: number | "VRB"): string {
  if (direction === "VRB") return "Variable";
  const directions = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];
  const index = Math.round(direction / 22.5) % 16;
  return `${direction.toString().padStart(3, "0")}° (${directions[index]})`;
}

function getWindStrength(speed: number): string {
  if (speed < 5) return "Calm";
  if (speed < 15) return "Light";
  if (speed < 25) return "Moderate";
  if (speed < 35) return "Strong";
  return "Severe";
}

export function WeatherDisplay({ weather, showForecast }: Props) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary" />
              <CardTitle className="text-lg font-mono">{weather.station}</CardTitle>
            </div>
            {weather.type === "SPECI" && (
              <Badge variant="secondary">SPECI</Badge>
            )}
            {weather.flightCategory && (
              <Badge className={FLIGHT_CATEGORY_COLORS[weather.flightCategory]}>
                {weather.flightCategory}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            {weather.time}Z
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Raw METAR/TAF */}
        <div className="p-3 bg-muted rounded-lg">
          <code className="text-sm font-mono break-all">{weather.raw}</code>
        </div>

        {/* Decoded Information */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Wind */}
          {weather.wind && (
            <div className="flex items-start gap-3 p-3 bg-card border rounded-lg">
              <div className="p-2 bg-blue-500/10 rounded-lg">
                <Wind className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Wind</div>
                <div className="font-medium">
                  {formatWindDirection(weather.wind.direction)}
                </div>
                <div className="text-sm">
                  {weather.wind.speed} {weather.wind.unit}
                  {weather.wind.gust && (
                    <span className="text-orange-500"> G{weather.wind.gust}</span>
                  )}
                </div>
                <div className="text-xs text-muted-foreground">
                  {getWindStrength(weather.wind.speed)}
                </div>
                {weather.wind.variable && (
                  <div className="text-xs text-muted-foreground">
                    Variable {weather.wind.variable.from}° - {weather.wind.variable.to}°
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Visibility */}
          {weather.visibility && (
            <div className="flex items-start gap-3 p-3 bg-card border rounded-lg">
              <div className="p-2 bg-green-500/10 rounded-lg">
                <Eye className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Visibility</div>
                <div className="font-medium">
                  {weather.visibility.cavok ? (
                    "CAVOK"
                  ) : (
                    <>
                      {weather.visibility.value >= 9999 
                        ? "10+ km" 
                        : `${(weather.visibility.value / 1000).toFixed(1)} km`}
                    </>
                  )}
                </div>
                {weather.visibility.cavok && (
                  <div className="text-xs text-muted-foreground">
                    Ceiling & Visibility OK
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Temperature */}
          {weather.temperature && (
            <div className="flex items-start gap-3 p-3 bg-card border rounded-lg">
              <div className="p-2 bg-orange-500/10 rounded-lg">
                <Thermometer className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Temperature</div>
                <div className="font-medium">{weather.temperature.temp}°C</div>
                <div className="text-sm text-muted-foreground flex items-center gap-1">
                  <Droplets className="h-3 w-3" />
                  Dewpoint: {weather.temperature.dewpoint}°C
                </div>
                <div className="text-xs text-muted-foreground">
                  Spread: {weather.temperature.temp - weather.temperature.dewpoint}°C
                </div>
              </div>
            </div>
          )}

          {/* Pressure */}
          {weather.pressure && (
            <div className="flex items-start gap-3 p-3 bg-card border rounded-lg">
              <div className="p-2 bg-purple-500/10 rounded-lg">
                <Gauge className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Pressure</div>
                <div className="font-medium">
                  {weather.pressure.value} {weather.pressure.unit}
                </div>
                {weather.pressure.unit === "hPa" && (
                  <div className="text-xs text-muted-foreground">
                    {(weather.pressure.value * 0.02953).toFixed(2)} inHg
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Weather Phenomena */}
        {weather.weather && weather.weather.length > 0 && (
          <div className="p-3 border rounded-lg">
            <div className="text-xs text-muted-foreground mb-2">Weather</div>
            <div className="flex flex-wrap gap-2">
              {weather.weather.map((wx, idx) => (
                <Badge key={idx} variant="secondary" className="font-mono">
                  {wx.raw}
                  <span className="ml-2 font-normal text-muted-foreground">
                    {[
                      wx.intensity === "-" ? "Light" : wx.intensity === "+" ? "Heavy" : "",
                      wx.descriptor && WEATHER_PHENOMENA[wx.descriptor],
                      ...wx.phenomena.map((p) => WEATHER_PHENOMENA[p] || p),
                    ]
                      .filter(Boolean)
                      .join(" ")}
                  </span>
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Clouds */}
        {weather.clouds && weather.clouds.length > 0 && (
          <div className="p-3 border rounded-lg">
            <div className="text-xs text-muted-foreground mb-2">Cloud Layers</div>
            <div className="space-y-2">
              {weather.clouds.map((cloud, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <Cloud className="h-4 w-4 text-muted-foreground" />
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="font-mono">
                      {cloud.type}
                    </Badge>
                    <span className="text-sm">
                      {CLOUD_TYPES[cloud.type] || cloud.type} at{" "}
                      <span className="font-medium">{cloud.height.toLocaleString()} ft</span>
                    </span>
                    {cloud.cloudType && (
                      <Badge variant="destructive" className="text-xs">
                        {cloud.cloudType === "CB" ? "Cumulonimbus" : "Towering Cumulus"}
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Trend */}
        {weather.trend && (
          <div className="p-3 border rounded-lg">
            <div className="text-xs text-muted-foreground mb-1">Trend</div>
            <code className="text-sm font-mono">{weather.trend}</code>
          </div>
        )}

        {/* Remarks */}
        {weather.remarks && (
          <div className="p-3 border rounded-lg">
            <div className="text-xs text-muted-foreground mb-1">Remarks</div>
            <code className="text-sm font-mono">{weather.remarks}</code>
          </div>
        )}

        {/* Human-readable decode */}
        {weather.decoded && (
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="text-xs text-muted-foreground mb-1">Plain Language Summary</div>
            <p className="text-sm">{weather.decoded}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
