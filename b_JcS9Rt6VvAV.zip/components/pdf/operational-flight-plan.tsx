"use client";

import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
} from "@react-pdf/renderer";

// Register fonts
Font.register({
  family: "Helvetica",
  fonts: [
    { src: "https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxP.ttf" },
    {
      src: "https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfBBc9.ttf",
      fontWeight: "bold",
    },
  ],
});

const styles = StyleSheet.create({
  page: {
    padding: 30,
    fontSize: 9,
    fontFamily: "Helvetica",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 15,
    paddingBottom: 10,
    borderBottom: "2px solid #1a365d",
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#1a365d",
  },
  subtitle: {
    fontSize: 10,
    color: "#4a5568",
  },
  section: {
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: "bold",
    backgroundColor: "#1a365d",
    color: "white",
    padding: 5,
    marginBottom: 5,
  },
  row: {
    flexDirection: "row",
    borderBottom: "1px solid #e2e8f0",
    minHeight: 18,
    alignItems: "center",
  },
  headerRow: {
    flexDirection: "row",
    backgroundColor: "#edf2f7",
    borderBottom: "1px solid #cbd5e0",
    minHeight: 20,
    alignItems: "center",
    fontWeight: "bold",
  },
  cell: {
    padding: 3,
    borderRight: "1px solid #e2e8f0",
  },
  label: {
    fontWeight: "bold",
    color: "#4a5568",
    marginRight: 5,
  },
  value: {
    color: "#1a202c",
  },
  infoGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  infoItem: {
    width: "25%",
    padding: 5,
    borderBottom: "1px solid #e2e8f0",
    borderRight: "1px solid #e2e8f0",
  },
  infoItemWide: {
    width: "50%",
    padding: 5,
    borderBottom: "1px solid #e2e8f0",
    borderRight: "1px solid #e2e8f0",
  },
  warning: {
    backgroundColor: "#fed7d7",
    padding: 8,
    marginTop: 5,
    borderRadius: 3,
  },
  warningText: {
    color: "#c53030",
    fontWeight: "bold",
  },
  footer: {
    position: "absolute",
    bottom: 30,
    left: 30,
    right: 30,
    flexDirection: "row",
    justifyContent: "space-between",
    borderTop: "1px solid #e2e8f0",
    paddingTop: 10,
    fontSize: 8,
    color: "#718096",
  },
  checkbox: {
    width: 10,
    height: 10,
    border: "1px solid #4a5568",
    marginRight: 5,
  },
  checkItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 3,
  },
  navLogTable: {
    border: "1px solid #cbd5e0",
  },
  fuelBox: {
    border: "1px solid #cbd5e0",
    padding: 8,
    marginTop: 5,
  },
  cgChart: {
    height: 150,
    border: "1px solid #cbd5e0",
    marginTop: 5,
    backgroundColor: "#f7fafc",
    justifyContent: "center",
    alignItems: "center",
  },
  weatherBox: {
    border: "1px solid #cbd5e0",
    padding: 8,
    marginBottom: 5,
    backgroundColor: "#f7fafc",
  },
  metarText: {
    fontFamily: "Courier",
    fontSize: 8,
    marginBottom: 3,
  },
});

interface FlightPlanData {
  // Flight Info
  flightNumber?: string;
  date: string;
  departure: {
    icao: string;
    name: string;
    time: string;
  };
  destination: {
    icao: string;
    name: string;
    time: string;
  };
  alternate?: {
    icao: string;
    name: string;
  };
  flightRules: "VFR" | "IFR";
  flightType: string;
  
  // Aircraft
  aircraft: {
    registration: string;
    type: string;
    model: string;
    equipment: string;
    surveillance: string;
  };
  
  // Crew
  pic: string;
  crew?: string[];
  passengers: number;
  
  // Route
  route: string;
  cruiseAltitude: number;
  cruiseSpeed: number;
  totalDistance: number;
  totalTime: number;
  
  // Nav Log
  waypoints: Array<{
    name: string;
    type: string;
    coordinates?: string;
    altitude: number;
    lsalt: number;
    track: number;
    distance: number;
    groundSpeed: number;
    ete: number;
    eta: string;
    ata?: string;
    fuel: number;
    remarks?: string;
  }>;
  
  // Fuel
  fuel: {
    taxi: number;
    trip: number;
    alternate: number;
    reserve: number;
    contingency: number;
    total: number;
    endurance: string;
    fuelType: string;
  };
  
  // Weight & Balance
  weightBalance: {
    basicEmpty: { weight: number; arm: number; moment: number };
    payload: Array<{ name: string; weight: number; arm: number; moment: number }>;
    fuel: { weight: number; arm: number; moment: number };
    takeoff: { weight: number; cg: number; moment: number };
    landing: { weight: number; cg: number; moment: number };
    maxTakeoffWeight: number;
    maxLandingWeight: number;
    isWithinLimits: boolean;
    cgLimits: { forward: number; aft: number };
  };
  
  // Weather
  weather: {
    departure?: {
      metar: string;
      taf?: string;
    };
    destination?: {
      metar: string;
      taf?: string;
    };
    alternate?: {
      metar: string;
    };
    enroute?: string;
  };
  
  // NOTAMs
  notams?: string[];
  
  // Remarks
  remarks?: string;
  
  // Generated
  generatedAt: string;
  generatedBy: string;
}

interface Props {
  data: FlightPlanData;
}

export function OperationalFlightPlan({ data }: Props) {
  return (
    <Document>
      {/* Page 1: Flight Summary & Nav Log */}
      <Page size="A4" style={styles.page}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>OPERATIONAL FLIGHT PLAN</Text>
            <Text style={styles.subtitle}>
              {data.departure.icao} - {data.destination.icao}
            </Text>
          </View>
          <View style={{ alignItems: "flex-end" }}>
            <Text style={{ fontWeight: "bold" }}>{data.flightNumber || "PRIVATE"}</Text>
            <Text>{data.date}</Text>
            <Text style={{ color: data.flightRules === "IFR" ? "#2b6cb0" : "#38a169" }}>
              {data.flightRules} FLIGHT
            </Text>
          </View>
        </View>

        {/* Flight Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>FLIGHT INFORMATION</Text>
          <View style={styles.infoGrid}>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Aircraft</Text>
              <Text style={styles.value}>{data.aircraft.registration}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Type</Text>
              <Text style={styles.value}>{data.aircraft.type}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>PIC</Text>
              <Text style={styles.value}>{data.pic}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>POB</Text>
              <Text style={styles.value}>{data.passengers + 1}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Departure</Text>
              <Text style={styles.value}>{data.departure.icao} @ {data.departure.time}Z</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Destination</Text>
              <Text style={styles.value}>{data.destination.icao} @ {data.destination.time}Z</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Alternate</Text>
              <Text style={styles.value}>{data.alternate?.icao || "NIL"}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Cruise</Text>
              <Text style={styles.value}>FL{Math.round(data.cruiseAltitude / 100).toString().padStart(3, "0")} @ {data.cruiseSpeed}KT</Text>
            </View>
            <View style={styles.infoItemWide}>
              <Text style={styles.label}>Route</Text>
              <Text style={styles.value}>{data.route}</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Total Distance</Text>
              <Text style={styles.value}>{data.totalDistance} NM</Text>
            </View>
            <View style={styles.infoItem}>
              <Text style={styles.label}>Total Time</Text>
              <Text style={styles.value}>{Math.floor(data.totalTime / 60)}:{(data.totalTime % 60).toString().padStart(2, "0")}</Text>
            </View>
          </View>
        </View>

        {/* Navigation Log */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>NAVIGATION LOG</Text>
          <View style={styles.navLogTable}>
            <View style={styles.headerRow}>
              <Text style={[styles.cell, { width: "15%" }]}>WAYPOINT</Text>
              <Text style={[styles.cell, { width: "8%" }]}>ALT</Text>
              <Text style={[styles.cell, { width: "8%" }]}>LSALT</Text>
              <Text style={[styles.cell, { width: "8%" }]}>TRK</Text>
              <Text style={[styles.cell, { width: "8%" }]}>DIST</Text>
              <Text style={[styles.cell, { width: "8%" }]}>GS</Text>
              <Text style={[styles.cell, { width: "8%" }]}>ETE</Text>
              <Text style={[styles.cell, { width: "10%" }]}>ETA</Text>
              <Text style={[styles.cell, { width: "10%" }]}>ATA</Text>
              <Text style={[styles.cell, { width: "8%" }]}>FUEL</Text>
              <Text style={[styles.cell, { width: "9%", borderRight: "none" }]}>RMK</Text>
            </View>
            {data.waypoints.map((wp, idx) => (
              <View key={idx} style={styles.row}>
                <Text style={[styles.cell, { width: "15%", fontWeight: "bold" }]}>{wp.name}</Text>
                <Text style={[styles.cell, { width: "8%" }]}>{wp.altitude}</Text>
                <Text style={[styles.cell, { width: "8%", color: wp.altitude < wp.lsalt ? "#c53030" : "#1a202c" }]}>
                  {wp.lsalt}
                </Text>
                <Text style={[styles.cell, { width: "8%" }]}>{wp.track.toString().padStart(3, "0")}°</Text>
                <Text style={[styles.cell, { width: "8%" }]}>{wp.distance}</Text>
                <Text style={[styles.cell, { width: "8%" }]}>{wp.groundSpeed}</Text>
                <Text style={[styles.cell, { width: "8%" }]}>{wp.ete}</Text>
                <Text style={[styles.cell, { width: "10%" }]}>{wp.eta}</Text>
                <Text style={[styles.cell, { width: "10%" }]}>{wp.ata || ""}</Text>
                <Text style={[styles.cell, { width: "8%" }]}>{wp.fuel}</Text>
                <Text style={[styles.cell, { width: "9%", borderRight: "none", fontSize: 7 }]}>{wp.remarks || ""}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Fuel Summary */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>FUEL SUMMARY</Text>
          <View style={{ flexDirection: "row", gap: 10 }}>
            <View style={[styles.fuelBox, { flex: 1 }]}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 3 }}>
                <Text>Taxi Fuel</Text>
                <Text>{data.fuel.taxi} gal</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 3 }}>
                <Text>Trip Fuel</Text>
                <Text>{data.fuel.trip} gal</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 3 }}>
                <Text>Contingency (5%)</Text>
                <Text>{data.fuel.contingency} gal</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 3 }}>
                <Text>Alternate</Text>
                <Text>{data.fuel.alternate} gal</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 3 }}>
                <Text>Reserve ({data.flightRules === "IFR" ? "45" : "30"} min)</Text>
                <Text>{data.fuel.reserve} gal</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", borderTop: "1px solid #cbd5e0", paddingTop: 3, fontWeight: "bold" }}>
                <Text>TOTAL REQUIRED</Text>
                <Text>{data.fuel.total} gal</Text>
              </View>
            </View>
            <View style={[styles.fuelBox, { flex: 1 }]}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 3 }}>
                <Text>Fuel Type</Text>
                <Text>{data.fuel.fuelType}</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 3 }}>
                <Text>Endurance</Text>
                <Text>{data.fuel.endurance}</Text>
              </View>
              <View style={{ borderTop: "1px solid #cbd5e0", paddingTop: 5, marginTop: 10 }}>
                <Text style={{ fontWeight: "bold", marginBottom: 3 }}>FUEL ON BOARD</Text>
                <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                  <Text>Departure:</Text>
                  <Text>_______ gal</Text>
                </View>
                <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                  <Text>Arrival:</Text>
                  <Text>_______ gal</Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text>Generated: {data.generatedAt}</Text>
          <Text>By: {data.generatedBy}</Text>
          <Text>Page 1 of 3</Text>
        </View>
      </Page>

      {/* Page 2: Weight & Balance */}
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>WEIGHT & BALANCE</Text>
            <Text style={styles.subtitle}>{data.aircraft.registration} - {data.aircraft.model}</Text>
          </View>
          <View style={{ alignItems: "flex-end" }}>
            <Text>{data.date}</Text>
            <Text>{data.departure.icao} - {data.destination.icao}</Text>
          </View>
        </View>

        {/* W&B Table */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>LOADING MANIFEST</Text>
          <View style={styles.navLogTable}>
            <View style={styles.headerRow}>
              <Text style={[styles.cell, { width: "40%" }]}>ITEM</Text>
              <Text style={[styles.cell, { width: "20%" }]}>WEIGHT (lbs)</Text>
              <Text style={[styles.cell, { width: "20%" }]}>ARM (in)</Text>
              <Text style={[styles.cell, { width: "20%", borderRight: "none" }]}>MOMENT (lb-in)</Text>
            </View>
            <View style={styles.row}>
              <Text style={[styles.cell, { width: "40%" }]}>Basic Empty Weight</Text>
              <Text style={[styles.cell, { width: "20%" }]}>{data.weightBalance.basicEmpty.weight}</Text>
              <Text style={[styles.cell, { width: "20%" }]}>{data.weightBalance.basicEmpty.arm.toFixed(2)}</Text>
              <Text style={[styles.cell, { width: "20%", borderRight: "none" }]}>{data.weightBalance.basicEmpty.moment}</Text>
            </View>
            {data.weightBalance.payload.map((item, idx) => (
              <View key={idx} style={styles.row}>
                <Text style={[styles.cell, { width: "40%" }]}>{item.name}</Text>
                <Text style={[styles.cell, { width: "20%" }]}>{item.weight}</Text>
                <Text style={[styles.cell, { width: "20%" }]}>{item.arm.toFixed(2)}</Text>
                <Text style={[styles.cell, { width: "20%", borderRight: "none" }]}>{item.moment}</Text>
              </View>
            ))}
            <View style={styles.row}>
              <Text style={[styles.cell, { width: "40%" }]}>Fuel</Text>
              <Text style={[styles.cell, { width: "20%" }]}>{data.weightBalance.fuel.weight}</Text>
              <Text style={[styles.cell, { width: "20%" }]}>{data.weightBalance.fuel.arm.toFixed(2)}</Text>
              <Text style={[styles.cell, { width: "20%", borderRight: "none" }]}>{data.weightBalance.fuel.moment}</Text>
            </View>
            <View style={[styles.row, { backgroundColor: "#edf2f7", fontWeight: "bold" }]}>
              <Text style={[styles.cell, { width: "40%" }]}>TAKEOFF</Text>
              <Text style={[styles.cell, { width: "20%" }]}>{data.weightBalance.takeoff.weight}</Text>
              <Text style={[styles.cell, { width: "20%" }]}>{data.weightBalance.takeoff.cg.toFixed(2)}</Text>
              <Text style={[styles.cell, { width: "20%", borderRight: "none" }]}>{data.weightBalance.takeoff.moment}</Text>
            </View>
            <View style={[styles.row, { backgroundColor: "#edf2f7", fontWeight: "bold" }]}>
              <Text style={[styles.cell, { width: "40%" }]}>LANDING (est)</Text>
              <Text style={[styles.cell, { width: "20%" }]}>{data.weightBalance.landing.weight}</Text>
              <Text style={[styles.cell, { width: "20%" }]}>{data.weightBalance.landing.cg.toFixed(2)}</Text>
              <Text style={[styles.cell, { width: "20%", borderRight: "none" }]}>{data.weightBalance.landing.moment}</Text>
            </View>
          </View>
        </View>

        {/* Limits */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>WEIGHT LIMITS</Text>
          <View style={{ flexDirection: "row", gap: 10 }}>
            <View style={[styles.fuelBox, { flex: 1 }]}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 3 }}>
                <Text>Max Takeoff Weight</Text>
                <Text>{data.weightBalance.maxTakeoffWeight} lbs</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 3 }}>
                <Text>Actual Takeoff Weight</Text>
                <Text>{data.weightBalance.takeoff.weight} lbs</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", borderTop: "1px solid #cbd5e0", paddingTop: 3 }}>
                <Text style={{ fontWeight: "bold" }}>Margin</Text>
                <Text style={{ color: data.weightBalance.takeoff.weight <= data.weightBalance.maxTakeoffWeight ? "#38a169" : "#c53030", fontWeight: "bold" }}>
                  {data.weightBalance.maxTakeoffWeight - data.weightBalance.takeoff.weight} lbs
                </Text>
              </View>
            </View>
            <View style={[styles.fuelBox, { flex: 1 }]}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 3 }}>
                <Text>Max Landing Weight</Text>
                <Text>{data.weightBalance.maxLandingWeight} lbs</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 3 }}>
                <Text>Actual Landing Weight</Text>
                <Text>{data.weightBalance.landing.weight} lbs</Text>
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", borderTop: "1px solid #cbd5e0", paddingTop: 3 }}>
                <Text style={{ fontWeight: "bold" }}>Margin</Text>
                <Text style={{ color: data.weightBalance.landing.weight <= data.weightBalance.maxLandingWeight ? "#38a169" : "#c53030", fontWeight: "bold" }}>
                  {data.weightBalance.maxLandingWeight - data.weightBalance.landing.weight} lbs
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* CG Limits */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>CENTER OF GRAVITY</Text>
          <View style={[styles.fuelBox]}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 5 }}>
              <Text>Forward Limit: {data.weightBalance.cgLimits.forward} in</Text>
              <Text>Aft Limit: {data.weightBalance.cgLimits.aft} in</Text>
            </View>
            <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 5 }}>
              <Text>Takeoff CG: {data.weightBalance.takeoff.cg.toFixed(2)} in</Text>
              <Text>Landing CG: {data.weightBalance.landing.cg.toFixed(2)} in</Text>
            </View>
            <View style={styles.cgChart}>
              <Text style={{ color: "#718096" }}>[CG Envelope Chart - See attached]</Text>
            </View>
          </View>
        </View>

        {/* Status */}
        {!data.weightBalance.isWithinLimits && (
          <View style={styles.warning}>
            <Text style={styles.warningText}>WARNING: Weight and/or CG outside limits</Text>
          </View>
        )}

        <View style={styles.footer}>
          <Text>Generated: {data.generatedAt}</Text>
          <Text>By: {data.generatedBy}</Text>
          <Text>Page 2 of 3</Text>
        </View>
      </Page>

      {/* Page 3: Weather & NOTAMs */}
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>WEATHER BRIEFING</Text>
            <Text style={styles.subtitle}>{data.departure.icao} - {data.destination.icao}</Text>
          </View>
          <View style={{ alignItems: "flex-end" }}>
            <Text>{data.date}</Text>
          </View>
        </View>

        {/* Departure Weather */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>DEPARTURE - {data.departure.icao}</Text>
          <View style={styles.weatherBox}>
            <Text style={{ fontWeight: "bold", marginBottom: 3 }}>METAR</Text>
            <Text style={styles.metarText}>{data.weather.departure?.metar || "Not available"}</Text>
            {data.weather.departure?.taf && (
              <>
                <Text style={{ fontWeight: "bold", marginTop: 8, marginBottom: 3 }}>TAF</Text>
                <Text style={styles.metarText}>{data.weather.departure.taf}</Text>
              </>
            )}
          </View>
        </View>

        {/* Destination Weather */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>DESTINATION - {data.destination.icao}</Text>
          <View style={styles.weatherBox}>
            <Text style={{ fontWeight: "bold", marginBottom: 3 }}>METAR</Text>
            <Text style={styles.metarText}>{data.weather.destination?.metar || "Not available"}</Text>
            {data.weather.destination?.taf && (
              <>
                <Text style={{ fontWeight: "bold", marginTop: 8, marginBottom: 3 }}>TAF</Text>
                <Text style={styles.metarText}>{data.weather.destination.taf}</Text>
              </>
            )}
          </View>
        </View>

        {/* Alternate Weather */}
        {data.alternate && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>ALTERNATE - {data.alternate.icao}</Text>
            <View style={styles.weatherBox}>
              <Text style={{ fontWeight: "bold", marginBottom: 3 }}>METAR</Text>
              <Text style={styles.metarText}>{data.weather.alternate?.metar || "Not available"}</Text>
            </View>
          </View>
        )}

        {/* En-route Weather */}
        {data.weather.enroute && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>EN-ROUTE</Text>
            <View style={styles.weatherBox}>
              <Text style={styles.metarText}>{data.weather.enroute}</Text>
            </View>
          </View>
        )}

        {/* NOTAMs */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>NOTAMS</Text>
          {data.notams && data.notams.length > 0 ? (
            data.notams.map((notam, idx) => (
              <View key={idx} style={[styles.weatherBox, { marginBottom: 3 }]}>
                <Text style={styles.metarText}>{notam}</Text>
              </View>
            ))
          ) : (
            <View style={styles.weatherBox}>
              <Text>No significant NOTAMs</Text>
            </View>
          )}
        </View>

        {/* Pilot Notes */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>REMARKS / PILOT NOTES</Text>
          <View style={[styles.fuelBox, { minHeight: 60 }]}>
            <Text>{data.remarks || ""}</Text>
          </View>
        </View>

        {/* Pre-flight Checklist */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>PRE-FLIGHT VERIFICATION</Text>
          <View style={{ flexDirection: "row", gap: 20 }}>
            <View style={{ flex: 1 }}>
              <View style={styles.checkItem}>
                <View style={styles.checkbox} />
                <Text>Weather briefing obtained</Text>
              </View>
              <View style={styles.checkItem}>
                <View style={styles.checkbox} />
                <Text>NOTAMs reviewed</Text>
              </View>
              <View style={styles.checkItem}>
                <View style={styles.checkbox} />
                <Text>Weight & Balance within limits</Text>
              </View>
              <View style={styles.checkItem}>
                <View style={styles.checkbox} />
                <Text>Fuel requirements met</Text>
              </View>
            </View>
            <View style={{ flex: 1 }}>
              <View style={styles.checkItem}>
                <View style={styles.checkbox} />
                <Text>Flight plan filed (if required)</Text>
              </View>
              <View style={styles.checkItem}>
                <View style={styles.checkbox} />
                <Text>SARTIME advised</Text>
              </View>
              <View style={styles.checkItem}>
                <View style={styles.checkbox} />
                <Text>Aircraft documents checked</Text>
              </View>
              <View style={styles.checkItem}>
                <View style={styles.checkbox} />
                <Text>Pre-flight inspection complete</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Signature */}
        <View style={{ flexDirection: "row", gap: 40, marginTop: 20 }}>
          <View style={{ flex: 1 }}>
            <Text style={{ marginBottom: 20 }}>PIC Signature: _____________________</Text>
            <Text>Date/Time: _____________________</Text>
          </View>
        </View>

        <View style={styles.footer}>
          <Text>Generated: {data.generatedAt}</Text>
          <Text>By: {data.generatedBy}</Text>
          <Text>Page 3 of 3</Text>
        </View>
      </Page>
    </Document>
  );
}
