"use client"

import { useMemo } from "react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

export interface NavLogWaypoint {
  identifier: string
  type: string
  latitude: number
  longitude: number
  altitude?: number
  magneticTrack?: number
  trueTrack?: number
  distance?: number
  cumulativeDistance?: number
  groundSpeed?: number
  windDirection?: number
  windSpeed?: number
  heading?: number
  eet?: number
  eta?: string
  fuelBurn?: number
  fuelRemaining?: number
  lsalt?: number
  remarks?: string
}

export interface NavLogProps {
  waypoints: NavLogWaypoint[]
  cruiseAltitude?: number
  departureTime?: Date
  className?: string
}

export function NavLog({ waypoints, cruiseAltitude, departureTime, className }: NavLogProps) {
  // Calculate cumulative values
  const processedWaypoints = useMemo(() => {
    let cumulativeTime = 0
    let cumulativeFuel = 0
    let cumulativeDistance = 0

    return waypoints.map((wp, index) => {
      if (index > 0) {
        cumulativeTime += wp.eet || 0
        cumulativeFuel += wp.fuelBurn || 0
        cumulativeDistance += wp.distance || 0
      }

      const eta = departureTime
        ? new Date(departureTime.getTime() + cumulativeTime * 60000)
        : null

      return {
        ...wp,
        cumulativeTime,
        cumulativeFuel,
        cumulativeDistance,
        etaFormatted: eta
          ? `${eta.getUTCHours().toString().padStart(2, "0")}${eta.getUTCMinutes().toString().padStart(2, "0")}`
          : "--",
      }
    })
  }, [waypoints, departureTime])

  const totalDistance = processedWaypoints.length > 0
    ? processedWaypoints[processedWaypoints.length - 1].cumulativeDistance
    : 0

  const totalTime = processedWaypoints.length > 0
    ? processedWaypoints[processedWaypoints.length - 1].cumulativeTime
    : 0

  const totalFuel = processedWaypoints.length > 0
    ? processedWaypoints[processedWaypoints.length - 1].cumulativeFuel
    : 0

  return (
    <div className={cn("space-y-4", className)}>
      {/* Summary */}
      <div className="grid grid-cols-4 gap-4 p-4 bg-muted/50 rounded-lg">
        <div className="text-center">
          <p className="text-2xl font-bold font-mono">{totalDistance.toFixed(1)}</p>
          <p className="text-xs text-muted-foreground">Total NM</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold font-mono">
            {Math.floor(totalTime / 60)}:{(totalTime % 60).toString().padStart(2, "0")}
          </p>
          <p className="text-xs text-muted-foreground">EET (h:mm)</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold font-mono">{totalFuel.toFixed(1)}</p>
          <p className="text-xs text-muted-foreground">Trip Fuel (gal)</p>
        </div>
        <div className="text-center">
          <p className="text-2xl font-bold font-mono">{cruiseAltitude || "--"}</p>
          <p className="text-xs text-muted-foreground">Cruise Alt (ft)</p>
        </div>
      </div>

      {/* Navigation Log Table */}
      <div className="border rounded-lg overflow-hidden">
        <Table className="flight-table">
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="w-12">#</TableHead>
              <TableHead className="w-20">IDENT</TableHead>
              <TableHead className="w-16 text-center">TRK (M)</TableHead>
              <TableHead className="w-16 text-center">DIST</TableHead>
              <TableHead className="w-16 text-center">CUM</TableHead>
              <TableHead className="w-16 text-center">GS</TableHead>
              <TableHead className="w-16 text-center">EET</TableHead>
              <TableHead className="w-16 text-center">ETA</TableHead>
              <TableHead className="w-20 text-center">LSALT</TableHead>
              <TableHead className="w-16 text-center">FUEL</TableHead>
              <TableHead>REMARKS</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {processedWaypoints.map((wp, index) => (
              <TableRow key={`${wp.identifier}-${index}`}>
                <TableCell className="font-mono text-muted-foreground">
                  {index + 1}
                </TableCell>
                <TableCell className="font-mono font-medium">
                  <div className="flex items-center gap-1">
                    {wp.identifier}
                    <Badge variant="outline" className="text-[10px] px-1">
                      {wp.type.slice(0, 3)}
                    </Badge>
                  </div>
                </TableCell>
                <TableCell className="text-center font-mono">
                  {index === 0 ? "--" : wp.magneticTrack?.toString().padStart(3, "0") || "--"}
                </TableCell>
                <TableCell className="text-center font-mono">
                  {index === 0 ? "--" : wp.distance?.toFixed(1) || "--"}
                </TableCell>
                <TableCell className="text-center font-mono">
                  {wp.cumulativeDistance.toFixed(1)}
                </TableCell>
                <TableCell className="text-center font-mono">
                  {wp.groundSpeed || "--"}
                </TableCell>
                <TableCell className="text-center font-mono">
                  {index === 0 ? "--" : wp.eet || "--"}
                </TableCell>
                <TableCell className="text-center font-mono">
                  {wp.etaFormatted}
                </TableCell>
                <TableCell className="text-center">
                  {wp.lsalt ? (
                    <Badge
                      variant={
                        (cruiseAltitude || 0) >= wp.lsalt ? "secondary" : "destructive"
                      }
                      className="font-mono"
                    >
                      {wp.lsalt}
                    </Badge>
                  ) : (
                    "--"
                  )}
                </TableCell>
                <TableCell className="text-center font-mono">
                  {wp.fuelBurn?.toFixed(1) || "--"}
                </TableCell>
                <TableCell className="text-xs text-muted-foreground">
                  {wp.remarks || ""}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* ATC Route String */}
      {waypoints.length > 0 && (
        <div className="p-4 bg-muted/50 rounded-lg">
          <p className="text-xs font-medium text-muted-foreground mb-2">
            ATC ROUTE STRING
          </p>
          <p className="font-mono text-sm break-all">
            {waypoints.map((wp) => wp.identifier).join(" ")}
          </p>
        </div>
      )}
    </div>
  )
}
