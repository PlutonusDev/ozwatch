"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { Fuel, AlertTriangle, CheckCircle2, Info } from "lucide-react"
import { calculateFuelReserves } from "@/lib/utils/aviation"

interface FuelPlanningProps {
  flightRules: "VFR" | "IFR" | "NVFR"
  tripDistance: number // NM
  cruiseSpeed: number // kts
  fuelBurnRate: number // gph
  fuelCapacity: number // gallons
  usableFuel: number // gallons
  alternateDistance?: number // NM
  className?: string
}

export function FuelPlanning({
  flightRules,
  tripDistance,
  cruiseSpeed,
  fuelBurnRate,
  fuelCapacity,
  usableFuel,
  alternateDistance = 0,
  className,
}: FuelPlanningProps) {
  const [taxiFuel, setTaxiFuel] = useState(2) // gallons
  const [additionalFuel, setAdditionalFuel] = useState(0)
  const [holdingMinutes, setHoldingMinutes] = useState(0)

  const calculations = useMemo(() => {
    // Trip time in hours
    const tripTimeHours = tripDistance / cruiseSpeed
    const tripTimeMinutes = tripTimeHours * 60

    // Trip fuel
    const tripFuel = tripTimeHours * fuelBurnRate

    // Alternate fuel
    const alternateTimeHours = alternateDistance / cruiseSpeed
    const alternateFuel = alternateTimeHours * fuelBurnRate

    // Get reserves based on flight rules
    const reserves = calculateFuelReserves(flightRules, fuelBurnRate, tripFuel)

    // Holding fuel
    const holdingFuel = (holdingMinutes / 60) * fuelBurnRate

    // Total required (excluding taxi)
    const flightFuelRequired = tripFuel + reserves.contingency + alternateFuel + reserves.fixedReserve + holdingFuel + additionalFuel

    // Block fuel (including taxi)
    const blockFuel = flightFuelRequired + taxiFuel

    // Check if we have enough fuel
    const fuelAvailable = usableFuel
    const extraFuel = fuelAvailable - blockFuel
    const canComplete = extraFuel >= 0

    // Endurance calculation (with all fuel on board)
    const enduranceHours = fuelAvailable / fuelBurnRate
    const enduranceMinutes = enduranceHours * 60

    return {
      tripTimeMinutes: Math.round(tripTimeMinutes),
      tripFuel: Math.round(tripFuel * 10) / 10,
      contingency: Math.round(reserves.contingency * 10) / 10,
      alternateFuel: Math.round(alternateFuel * 10) / 10,
      fixedReserve: Math.round(reserves.fixedReserve * 10) / 10,
      holdingFuel: Math.round(holdingFuel * 10) / 10,
      additionalFuel,
      flightFuelRequired: Math.round(flightFuelRequired * 10) / 10,
      taxiFuel,
      blockFuel: Math.round(blockFuel * 10) / 10,
      extraFuel: Math.round(extraFuel * 10) / 10,
      canComplete,
      enduranceMinutes: Math.round(enduranceMinutes),
      fuelCapacity,
      usableFuel,
    }
  }, [
    tripDistance,
    cruiseSpeed,
    fuelBurnRate,
    fuelCapacity,
    usableFuel,
    alternateDistance,
    flightRules,
    taxiFuel,
    additionalFuel,
    holdingMinutes,
  ])

  const fuelPercentage = (calculations.blockFuel / calculations.fuelCapacity) * 100

  // Reserve requirement label
  const reserveLabel = flightRules === "VFR" ? "30 min fixed reserve" : "45 min fixed reserve"

  return (
    <div className={className}>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Fuel className="h-5 w-5" />
            Fuel Planning
          </CardTitle>
          <CardDescription>
            Australian {flightRules} fuel requirements
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Adjustable inputs */}
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="taxi-fuel">Taxi Fuel (gal)</Label>
              <Input
                id="taxi-fuel"
                type="number"
                step="0.5"
                min="0"
                value={taxiFuel}
                onChange={(e) => setTaxiFuel(parseFloat(e.target.value) || 0)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="holding">Holding (min)</Label>
              <Input
                id="holding"
                type="number"
                min="0"
                value={holdingMinutes}
                onChange={(e) => setHoldingMinutes(parseInt(e.target.value) || 0)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="additional">Additional (gal)</Label>
              <Input
                id="additional"
                type="number"
                step="0.5"
                min="0"
                value={additionalFuel}
                onChange={(e) => setAdditionalFuel(parseFloat(e.target.value) || 0)}
              />
            </div>
          </div>

          <Separator />

          {/* Fuel breakdown */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Taxi Fuel</span>
              <span className="font-mono">{calculations.taxiFuel.toFixed(1)} gal</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Trip Fuel ({calculations.tripTimeMinutes} min)</span>
              <span className="font-mono">{calculations.tripFuel.toFixed(1)} gal</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Contingency (10%)</span>
              <span className="font-mono">{calculations.contingency.toFixed(1)} gal</span>
            </div>
            {calculations.alternateFuel > 0 && (
              <div className="flex justify-between text-sm">
                <span>Alternate</span>
                <span className="font-mono">{calculations.alternateFuel.toFixed(1)} gal</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span>{reserveLabel}</span>
              <span className="font-mono">{calculations.fixedReserve.toFixed(1)} gal</span>
            </div>
            {calculations.holdingFuel > 0 && (
              <div className="flex justify-between text-sm">
                <span>Holding ({holdingMinutes} min)</span>
                <span className="font-mono">{calculations.holdingFuel.toFixed(1)} gal</span>
              </div>
            )}
            {calculations.additionalFuel > 0 && (
              <div className="flex justify-between text-sm">
                <span>Additional</span>
                <span className="font-mono">{calculations.additionalFuel.toFixed(1)} gal</span>
              </div>
            )}

            <Separator />

            <div className="flex justify-between font-medium">
              <span>Total Block Fuel Required</span>
              <span className="font-mono">{calculations.blockFuel.toFixed(1)} gal</span>
            </div>
          </div>

          {/* Fuel gauge visualization */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Tank Capacity: {calculations.fuelCapacity} gal</span>
              <span>Usable: {calculations.usableFuel} gal</span>
            </div>
            <Progress
              value={Math.min(fuelPercentage, 100)}
              className={
                calculations.canComplete
                  ? "[&>div]:bg-vfr"
                  : "[&>div]:bg-destructive"
              }
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>0</span>
              <span>{calculations.fuelCapacity} gal</span>
            </div>
          </div>

          {/* Status */}
          {calculations.canComplete ? (
            <Alert className="border-vfr bg-vfr/10">
              <CheckCircle2 className="h-4 w-4 text-vfr" />
              <AlertDescription className="text-vfr">
                <span className="font-medium">Fuel OK.</span> Extra fuel:{" "}
                {calculations.extraFuel.toFixed(1)} gal ({Math.round((calculations.extraFuel / fuelBurnRate) * 60)} min)
              </AlertDescription>
            </Alert>
          ) : (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <span className="font-medium">Insufficient fuel!</span> Need{" "}
                {Math.abs(calculations.extraFuel).toFixed(1)} gal more
              </AlertDescription>
            </Alert>
          )}

          {/* Endurance info */}
          <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2">
              <Info className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                Endurance (full tanks)
              </span>
            </div>
            <Badge variant="secondary" className="font-mono">
              {Math.floor(calculations.enduranceMinutes / 60)}h {calculations.enduranceMinutes % 60}min
            </Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
