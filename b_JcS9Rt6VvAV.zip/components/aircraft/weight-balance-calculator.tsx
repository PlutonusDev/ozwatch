"use client";

import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, CheckCircle2 } from "lucide-react";

interface AircraftProfile {
  id: string;
  registration: string;
  weights: {
    maxTakeoffWeight: number;
    maxLandingWeight: number;
    maxFuelCapacity: number;
    fuelType: string;
  };
  weightBalance: {
    basicEmptyWeight: number;
    basicEmptyArm: number;
    basicEmptyMoment: number;
    stations: Array<{
      name: string;
      arm: number;
      minWeight: number;
      maxWeight: number;
    }>;
    fuelStations: Array<{
      name: string;
      arm: number;
      capacity: number;
      unusable: number;
    }>;
    envelope: Array<{
      weight: number;
      fwdCG: number;
      aftCG: number;
    }>;
  };
}

interface Props {
  aircraft: AircraftProfile;
  onChange?: (data: WeightBalanceData) => void;
}

interface WeightBalanceData {
  stationWeights: number[];
  fuelGallons: number[];
  takeoffWeight: number;
  takeoffCG: number;
  landingWeight: number;
  landingCG: number;
  isWithinEnvelope: boolean;
  isWithinWeightLimits: boolean;
}

const FUEL_WEIGHTS: Record<string, number> = {
  AVGAS: 6.0,
  JETA1: 6.7,
  MOGAS: 6.0,
};

export function WeightBalanceCalculator({ aircraft, onChange }: Props) {
  const [stationWeights, setStationWeights] = useState<number[]>(
    aircraft.weightBalance?.stations?.map(() => 0) || []
  );
  const [fuelGallons, setFuelGallons] = useState<number[]>(
    aircraft.weightBalance?.fuelStations?.map((tank) => tank.capacity * 0.75) || []
  );
  const [tripFuelBurn, setTripFuelBurn] = useState<number>(10);

  const fuelWeight = FUEL_WEIGHTS[aircraft.weights?.fuelType] || 6.0;

  const calculations = useMemo(() => {
    const wb = aircraft.weightBalance;
    if (!wb) return null;

    // Calculate station moments
    const stationMoments = wb.stations.map((station, idx) => ({
      weight: stationWeights[idx] || 0,
      arm: station.arm,
      moment: (stationWeights[idx] || 0) * station.arm,
    }));

    // Calculate fuel weights and moments (takeoff)
    const fuelMomentsTakeoff = wb.fuelStations.map((tank, idx) => {
      const gallons = fuelGallons[idx] || 0;
      const weight = gallons * fuelWeight;
      return {
        weight,
        arm: tank.arm,
        moment: weight * tank.arm,
      };
    });

    // Calculate total fuel after trip
    const totalFuelTakeoff = fuelGallons.reduce((sum, g) => sum + g, 0);
    const fuelAfterTrip = Math.max(0, totalFuelTakeoff - tripFuelBurn);
    const fuelRatio = totalFuelTakeoff > 0 ? fuelAfterTrip / totalFuelTakeoff : 0;

    // Calculate fuel weights and moments (landing)
    const fuelMomentsLanding = wb.fuelStations.map((tank, idx) => {
      const gallons = (fuelGallons[idx] || 0) * fuelRatio;
      const weight = gallons * fuelWeight;
      return {
        weight,
        arm: tank.arm,
        moment: weight * tank.arm,
      };
    });

    // Takeoff calculations
    const totalStationWeight = stationMoments.reduce((sum, s) => sum + s.weight, 0);
    const totalStationMoment = stationMoments.reduce((sum, s) => sum + s.moment, 0);
    const totalFuelWeightTakeoff = fuelMomentsTakeoff.reduce((sum, f) => sum + f.weight, 0);
    const totalFuelMomentTakeoff = fuelMomentsTakeoff.reduce((sum, f) => sum + f.moment, 0);

    const takeoffWeight = wb.basicEmptyWeight + totalStationWeight + totalFuelWeightTakeoff;
    const takeoffMoment = wb.basicEmptyMoment + totalStationMoment + totalFuelMomentTakeoff;
    const takeoffCG = takeoffWeight > 0 ? takeoffMoment / takeoffWeight : 0;

    // Landing calculations
    const totalFuelWeightLanding = fuelMomentsLanding.reduce((sum, f) => sum + f.weight, 0);
    const totalFuelMomentLanding = fuelMomentsLanding.reduce((sum, f) => sum + f.moment, 0);

    const landingWeight = wb.basicEmptyWeight + totalStationWeight + totalFuelWeightLanding;
    const landingMoment = wb.basicEmptyMoment + totalStationMoment + totalFuelMomentLanding;
    const landingCG = landingWeight > 0 ? landingMoment / landingWeight : 0;

    // Check envelope
    const isWithinEnvelopeTakeoff = checkEnvelope(wb.envelope, takeoffWeight, takeoffCG);
    const isWithinEnvelopeLanding = checkEnvelope(wb.envelope, landingWeight, landingCG);

    // Check weight limits
    const isWithinTakeoffWeight = takeoffWeight <= aircraft.weights.maxTakeoffWeight;
    const isWithinLandingWeight = landingWeight <= aircraft.weights.maxLandingWeight;

    return {
      stationMoments,
      fuelMomentsTakeoff,
      fuelMomentsLanding,
      takeoffWeight,
      takeoffMoment,
      takeoffCG,
      landingWeight,
      landingMoment,
      landingCG,
      isWithinEnvelopeTakeoff,
      isWithinEnvelopeLanding,
      isWithinTakeoffWeight,
      isWithinLandingWeight,
      isValid: isWithinEnvelopeTakeoff && isWithinEnvelopeLanding && isWithinTakeoffWeight && isWithinLandingWeight,
    };
  }, [aircraft, stationWeights, fuelGallons, tripFuelBurn, fuelWeight]);

  function checkEnvelope(envelope: AircraftProfile["weightBalance"]["envelope"], weight: number, cg: number): boolean {
    if (!envelope || envelope.length < 2) return true;

    // Sort envelope by weight
    const sorted = [...envelope].sort((a, b) => a.weight - b.weight);

    // Find the two envelope points that bracket the weight
    let lower = sorted[0];
    let upper = sorted[sorted.length - 1];

    for (let i = 0; i < sorted.length - 1; i++) {
      if (weight >= sorted[i].weight && weight <= sorted[i + 1].weight) {
        lower = sorted[i];
        upper = sorted[i + 1];
        break;
      }
    }

    // Interpolate CG limits
    const weightRatio = upper.weight !== lower.weight
      ? (weight - lower.weight) / (upper.weight - lower.weight)
      : 0;

    const fwdLimit = lower.fwdCG + weightRatio * (upper.fwdCG - lower.fwdCG);
    const aftLimit = lower.aftCG + weightRatio * (upper.aftCG - lower.aftCG);

    return cg >= fwdLimit && cg <= aftLimit && weight <= sorted[sorted.length - 1].weight;
  }

  // Generate envelope polygon points for SVG
  const envelopePoints = useMemo(() => {
    const envelope = aircraft.weightBalance?.envelope;
    if (!envelope || envelope.length < 2) return "";

    const sorted = [...envelope].sort((a, b) => a.weight - b.weight);
    
    // Create polygon: forward limits (bottom to top), then aft limits (top to bottom)
    const fwdPoints = sorted.map((p) => ({ x: p.fwdCG, y: p.weight }));
    const aftPoints = [...sorted].reverse().map((p) => ({ x: p.aftCG, y: p.weight }));
    
    return [...fwdPoints, ...aftPoints];
  }, [aircraft.weightBalance?.envelope]);

  // SVG dimensions and scaling
  const svgWidth = 400;
  const svgHeight = 300;
  const padding = 40;

  const cgRange = useMemo(() => {
    const envelope = aircraft.weightBalance?.envelope || [];
    if (envelope.length === 0) return { min: 30, max: 50 };
    const allCGs = envelope.flatMap((p) => [p.fwdCG, p.aftCG]);
    return {
      min: Math.min(...allCGs) - 2,
      max: Math.max(...allCGs) + 2,
    };
  }, [aircraft.weightBalance?.envelope]);

  const weightRange = useMemo(() => {
    const envelope = aircraft.weightBalance?.envelope || [];
    if (envelope.length === 0) return { min: 1500, max: 2600 };
    const weights = envelope.map((p) => p.weight);
    return {
      min: Math.min(...weights) - 100,
      max: Math.max(...weights) + 100,
    };
  }, [aircraft.weightBalance?.envelope]);

  function scaleX(cg: number): number {
    return padding + ((cg - cgRange.min) / (cgRange.max - cgRange.min)) * (svgWidth - 2 * padding);
  }

  function scaleY(weight: number): number {
    return svgHeight - padding - ((weight - weightRange.min) / (weightRange.max - weightRange.min)) * (svgHeight - 2 * padding);
  }

  if (!aircraft.weightBalance) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          Weight & Balance data not configured for this aircraft
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-6">
        {/* Loading Inputs */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Loading</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Stations */}
            {aircraft.weightBalance.stations.map((station, idx) => (
              <div key={idx} className="grid grid-cols-3 gap-2 items-center">
                <Label className="text-sm">{station.name}</Label>
                <div className="col-span-2 flex items-center gap-2">
                  <Input
                    type="number"
                    value={stationWeights[idx] || ""}
                    onChange={(e) => {
                      const newWeights = [...stationWeights];
                      newWeights[idx] = Number(e.target.value);
                      setStationWeights(newWeights);
                    }}
                    placeholder="0"
                    className="h-8"
                  />
                  <span className="text-xs text-muted-foreground w-20">
                    max {station.maxWeight} lbs
                  </span>
                </div>
              </div>
            ))}

            <div className="border-t pt-4 mt-4">
              <Label className="text-sm font-medium">Fuel</Label>
            </div>

            {/* Fuel Stations */}
            {aircraft.weightBalance.fuelStations.map((tank, idx) => (
              <div key={idx} className="grid grid-cols-3 gap-2 items-center">
                <Label className="text-sm">{tank.name}</Label>
                <div className="col-span-2 flex items-center gap-2">
                  <Input
                    type="number"
                    step="0.1"
                    value={fuelGallons[idx] || ""}
                    onChange={(e) => {
                      const newFuel = [...fuelGallons];
                      newFuel[idx] = Number(e.target.value);
                      setFuelGallons(newFuel);
                    }}
                    placeholder="0"
                    className="h-8"
                  />
                  <span className="text-xs text-muted-foreground w-20">
                    of {tank.capacity} gal
                  </span>
                </div>
              </div>
            ))}

            <div className="grid grid-cols-3 gap-2 items-center">
              <Label className="text-sm">Trip Fuel Burn</Label>
              <div className="col-span-2 flex items-center gap-2">
                <Input
                  type="number"
                  step="0.1"
                  value={tripFuelBurn}
                  onChange={(e) => setTripFuelBurn(Number(e.target.value))}
                  className="h-8"
                />
                <span className="text-xs text-muted-foreground w-20">gallons</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CG Envelope Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">CG Envelope</CardTitle>
          </CardHeader>
          <CardContent>
            <svg width={svgWidth} height={svgHeight} className="bg-muted/30 rounded-lg">
              {/* Grid lines */}
              {Array.from({ length: 5 }).map((_, i) => {
                const y = padding + (i * (svgHeight - 2 * padding)) / 4;
                const weight = weightRange.max - (i * (weightRange.max - weightRange.min)) / 4;
                return (
                  <g key={`h-${i}`}>
                    <line
                      x1={padding}
                      y1={y}
                      x2={svgWidth - padding}
                      y2={y}
                      stroke="currentColor"
                      strokeOpacity={0.1}
                    />
                    <text
                      x={padding - 5}
                      y={y + 4}
                      textAnchor="end"
                      className="fill-muted-foreground text-[10px]"
                    >
                      {Math.round(weight)}
                    </text>
                  </g>
                );
              })}

              {Array.from({ length: 5 }).map((_, i) => {
                const x = padding + (i * (svgWidth - 2 * padding)) / 4;
                const cg = cgRange.min + (i * (cgRange.max - cgRange.min)) / 4;
                return (
                  <g key={`v-${i}`}>
                    <line
                      x1={x}
                      y1={padding}
                      x2={x}
                      y2={svgHeight - padding}
                      stroke="currentColor"
                      strokeOpacity={0.1}
                    />
                    <text
                      x={x}
                      y={svgHeight - padding + 15}
                      textAnchor="middle"
                      className="fill-muted-foreground text-[10px]"
                    >
                      {cg.toFixed(1)}
                    </text>
                  </g>
                );
              })}

              {/* Envelope polygon */}
              {envelopePoints.length > 0 && (
                <polygon
                  points={envelopePoints
                    .map((p) => `${scaleX(p.x)},${scaleY(p.y)}`)
                    .join(" ")}
                  fill="hsl(var(--primary))"
                  fillOpacity={0.1}
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                />
              )}

              {/* Takeoff point */}
              {calculations && (
                <g>
                  <circle
                    cx={scaleX(calculations.takeoffCG)}
                    cy={scaleY(calculations.takeoffWeight)}
                    r={6}
                    fill={calculations.isWithinEnvelopeTakeoff && calculations.isWithinTakeoffWeight
                      ? "hsl(var(--chart-2))"
                      : "hsl(var(--destructive))"}
                  />
                  <text
                    x={scaleX(calculations.takeoffCG) + 10}
                    y={scaleY(calculations.takeoffWeight) + 4}
                    className="fill-foreground text-[10px] font-medium"
                  >
                    T/O
                  </text>
                </g>
              )}

              {/* Landing point */}
              {calculations && (
                <g>
                  <circle
                    cx={scaleX(calculations.landingCG)}
                    cy={scaleY(calculations.landingWeight)}
                    r={6}
                    fill={calculations.isWithinEnvelopeLanding && calculations.isWithinLandingWeight
                      ? "hsl(var(--chart-3))"
                      : "hsl(var(--destructive))"}
                  />
                  <text
                    x={scaleX(calculations.landingCG) + 10}
                    y={scaleY(calculations.landingWeight) + 4}
                    className="fill-foreground text-[10px] font-medium"
                  >
                    LDG
                  </text>
                </g>
              )}

              {/* Axis labels */}
              <text
                x={svgWidth / 2}
                y={svgHeight - 5}
                textAnchor="middle"
                className="fill-foreground text-xs"
              >
                CG (inches aft of datum)
              </text>
              <text
                x={10}
                y={svgHeight / 2}
                textAnchor="middle"
                transform={`rotate(-90, 10, ${svgHeight / 2})`}
                className="fill-foreground text-xs"
              >
                Weight (lbs)
              </text>
            </svg>
          </CardContent>
        </Card>
      </div>

      {/* Results */}
      <div className="grid grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              Takeoff
              {calculations?.isWithinEnvelopeTakeoff && calculations?.isWithinTakeoffWeight ? (
                <CheckCircle2 className="h-4 w-4 text-green-500" />
              ) : (
                <AlertCircle className="h-4 w-4 text-destructive" />
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-1">Item</th>
                  <th className="text-right py-1">Weight</th>
                  <th className="text-right py-1">Arm</th>
                  <th className="text-right py-1">Moment</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-dashed">
                  <td className="py-1">Basic Empty</td>
                  <td className="text-right">{aircraft.weightBalance.basicEmptyWeight.toLocaleString()}</td>
                  <td className="text-right">{aircraft.weightBalance.basicEmptyArm.toFixed(1)}</td>
                  <td className="text-right">{aircraft.weightBalance.basicEmptyMoment.toLocaleString()}</td>
                </tr>
                {calculations?.stationMoments.map((s, idx) => (
                  <tr key={idx} className="border-b border-dashed">
                    <td className="py-1">{aircraft.weightBalance.stations[idx].name}</td>
                    <td className="text-right">{s.weight}</td>
                    <td className="text-right">{s.arm.toFixed(1)}</td>
                    <td className="text-right">{s.moment.toLocaleString()}</td>
                  </tr>
                ))}
                {calculations?.fuelMomentsTakeoff.map((f, idx) => (
                  <tr key={idx} className="border-b border-dashed">
                    <td className="py-1">{aircraft.weightBalance.fuelStations[idx].name}</td>
                    <td className="text-right">{f.weight.toFixed(1)}</td>
                    <td className="text-right">{f.arm.toFixed(1)}</td>
                    <td className="text-right">{f.moment.toFixed(0)}</td>
                  </tr>
                ))}
                <tr className="font-medium">
                  <td className="py-2">Takeoff Total</td>
                  <td className="text-right">{calculations?.takeoffWeight.toFixed(0)}</td>
                  <td className="text-right">{calculations?.takeoffCG.toFixed(2)}</td>
                  <td className="text-right">{calculations?.takeoffMoment.toFixed(0)}</td>
                </tr>
              </tbody>
            </table>

            {calculations && !calculations.isWithinTakeoffWeight && (
              <Alert variant="destructive" className="mt-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Exceeds max takeoff weight by {(calculations.takeoffWeight - aircraft.weights.maxTakeoffWeight).toFixed(0)} lbs
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              Landing (estimated)
              {calculations?.isWithinEnvelopeLanding && calculations?.isWithinLandingWeight ? (
                <CheckCircle2 className="h-4 w-4 text-green-500" />
              ) : (
                <AlertCircle className="h-4 w-4 text-destructive" />
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-1">Item</th>
                  <th className="text-right py-1">Weight</th>
                  <th className="text-right py-1">Arm</th>
                  <th className="text-right py-1">Moment</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-dashed">
                  <td className="py-1">Basic Empty</td>
                  <td className="text-right">{aircraft.weightBalance.basicEmptyWeight.toLocaleString()}</td>
                  <td className="text-right">{aircraft.weightBalance.basicEmptyArm.toFixed(1)}</td>
                  <td className="text-right">{aircraft.weightBalance.basicEmptyMoment.toLocaleString()}</td>
                </tr>
                {calculations?.stationMoments.map((s, idx) => (
                  <tr key={idx} className="border-b border-dashed">
                    <td className="py-1">{aircraft.weightBalance.stations[idx].name}</td>
                    <td className="text-right">{s.weight}</td>
                    <td className="text-right">{s.arm.toFixed(1)}</td>
                    <td className="text-right">{s.moment.toLocaleString()}</td>
                  </tr>
                ))}
                {calculations?.fuelMomentsLanding.map((f, idx) => (
                  <tr key={idx} className="border-b border-dashed">
                    <td className="py-1">{aircraft.weightBalance.fuelStations[idx].name} (rem)</td>
                    <td className="text-right">{f.weight.toFixed(1)}</td>
                    <td className="text-right">{f.arm.toFixed(1)}</td>
                    <td className="text-right">{f.moment.toFixed(0)}</td>
                  </tr>
                ))}
                <tr className="font-medium">
                  <td className="py-2">Landing Total</td>
                  <td className="text-right">{calculations?.landingWeight.toFixed(0)}</td>
                  <td className="text-right">{calculations?.landingCG.toFixed(2)}</td>
                  <td className="text-right">{calculations?.landingMoment.toFixed(0)}</td>
                </tr>
              </tbody>
            </table>

            {calculations && !calculations.isWithinLandingWeight && (
              <Alert variant="destructive" className="mt-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Exceeds max landing weight by {(calculations.landingWeight - aircraft.weights.maxLandingWeight).toFixed(0)} lbs
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Overall Status */}
      {calculations && (
        <Alert variant={calculations.isValid ? "default" : "destructive"}>
          {calculations.isValid ? (
            <CheckCircle2 className="h-4 w-4" />
          ) : (
            <AlertCircle className="h-4 w-4" />
          )}
          <AlertDescription>
            {calculations.isValid
              ? "Weight and balance is within limits for takeoff and landing"
              : "Weight and/or CG is outside acceptable limits - adjust loading before flight"}
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
