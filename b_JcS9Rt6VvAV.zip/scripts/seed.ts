import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('Seeding database...')

  // Create admin user
  const adminPassword = await bcrypt.hash('admin123', 12)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@flightplan.com.au' },
    update: {},
    create: {
      email: 'admin@flightplan.com.au',
      name: 'System Administrator',
      password: adminPassword,
      role: 'ADMIN',
      pilotLicense: 'ATPL',
      medicalExpiry: new Date('2027-01-01'),
    },
  })
  console.log('Created admin user:', admin.email)

  // Create base aircraft profiles
  const cessna172 = await prisma.aircraftProfile.upsert({
    where: { id: 'base-cessna-172' },
    update: {},
    create: {
      id: 'base-cessna-172',
      name: 'Cessna 172S Skyhawk',
      registration: 'BASE-172',
      type: 'C172',
      isBaseProfile: true,
      category: 'SINGLE_ENGINE',
      emptyWeight: 767,
      maxTakeoffWeight: 1157,
      maxLandingWeight: 1157,
      maxZeroFuelWeight: 1043,
      fuelCapacity: 212,
      usableFuel: 200,
      fuelBurnRate: 36,
      cruiseSpeed: 122,
      climbSpeed: 79,
      descentSpeed: 100,
      climbRate: 730,
      descentRate: 500,
      serviceCeiling: 14000,
      range: 640,
      endurance: 5.5,
      weightBalanceStations: [
        { name: 'Pilot & Front Passenger', arm: 0.94, minWeight: 0, maxWeight: 181 },
        { name: 'Rear Passengers', arm: 1.17, minWeight: 0, maxWeight: 181 },
        { name: 'Baggage Area 1', arm: 1.42, minWeight: 0, maxWeight: 54 },
        { name: 'Baggage Area 2', arm: 1.88, minWeight: 0, maxWeight: 23 },
        { name: 'Fuel (Main Tanks)', arm: 1.19, minWeight: 0, maxWeight: 144 },
      ],
      cgEnvelope: [
        { weight: 680, fwdCG: 0.89, aftCG: 1.20 },
        { weight: 885, fwdCG: 0.89, aftCG: 1.20 },
        { weight: 1043, fwdCG: 0.94, aftCG: 1.20 },
        { weight: 1157, fwdCG: 0.94, aftCG: 1.20 },
      ],
      equipmentCodes: 'SDF/C',
      surveillanceCodes: 'S',
      wakeTurbulenceCategory: 'L',
    },
  })
  console.log('Created base aircraft:', cessna172.name)

  const pa28 = await prisma.aircraftProfile.upsert({
    where: { id: 'base-pa28-161' },
    update: {},
    create: {
      id: 'base-pa28-161',
      name: 'Piper PA-28-161 Warrior',
      registration: 'BASE-PA28',
      type: 'P28A',
      isBaseProfile: true,
      category: 'SINGLE_ENGINE',
      emptyWeight: 680,
      maxTakeoffWeight: 1107,
      maxLandingWeight: 1107,
      maxZeroFuelWeight: 998,
      fuelCapacity: 189,
      usableFuel: 182,
      fuelBurnRate: 38,
      cruiseSpeed: 117,
      climbSpeed: 76,
      descentSpeed: 95,
      climbRate: 649,
      descentRate: 500,
      serviceCeiling: 11000,
      range: 520,
      endurance: 4.5,
      weightBalanceStations: [
        { name: 'Pilot & Front Passenger', arm: 2.05, minWeight: 0, maxWeight: 181 },
        { name: 'Rear Passengers', arm: 2.92, minWeight: 0, maxWeight: 163 },
        { name: 'Baggage', arm: 3.61, minWeight: 0, maxWeight: 91 },
        { name: 'Fuel', arm: 2.41, minWeight: 0, maxWeight: 132 },
      ],
      cgEnvelope: [
        { weight: 680, fwdCG: 2.11, aftCG: 2.39 },
        { weight: 998, fwdCG: 2.11, aftCG: 2.39 },
        { weight: 1107, fwdCG: 2.16, aftCG: 2.39 },
      ],
      equipmentCodes: 'SDF/C',
      surveillanceCodes: 'S',
      wakeTurbulenceCategory: 'L',
    },
  })
  console.log('Created base aircraft:', pa28.name)

  const be76 = await prisma.aircraftProfile.upsert({
    where: { id: 'base-be76' },
    update: {},
    create: {
      id: 'base-be76',
      name: 'Beechcraft Duchess BE76',
      registration: 'BASE-BE76',
      type: 'BE76',
      isBaseProfile: true,
      category: 'MULTI_ENGINE',
      emptyWeight: 1134,
      maxTakeoffWeight: 1769,
      maxLandingWeight: 1678,
      maxZeroFuelWeight: 1588,
      fuelCapacity: 370,
      usableFuel: 356,
      fuelBurnRate: 68,
      cruiseSpeed: 161,
      climbSpeed: 91,
      descentSpeed: 120,
      climbRate: 1248,
      descentRate: 700,
      serviceCeiling: 19650,
      range: 750,
      endurance: 5.0,
      weightBalanceStations: [
        { name: 'Pilot & Front Passenger', arm: 2.21, minWeight: 0, maxWeight: 181 },
        { name: 'Rear Passengers', arm: 3.02, minWeight: 0, maxWeight: 181 },
        { name: 'Baggage - Nose', arm: 0.66, minWeight: 0, maxWeight: 45 },
        { name: 'Baggage - Aft', arm: 3.76, minWeight: 0, maxWeight: 91 },
        { name: 'Fuel (Main)', arm: 2.54, minWeight: 0, maxWeight: 193 },
        { name: 'Fuel (Aux)', arm: 2.54, minWeight: 0, maxWeight: 64 },
      ],
      cgEnvelope: [
        { weight: 1134, fwdCG: 2.21, aftCG: 2.49 },
        { weight: 1588, fwdCG: 2.21, aftCG: 2.49 },
        { weight: 1769, fwdCG: 2.26, aftCG: 2.49 },
      ],
      equipmentCodes: 'SDFG/C',
      surveillanceCodes: 'S',
      wakeTurbulenceCategory: 'L',
    },
  })
  console.log('Created base aircraft:', be76.name)

  // Create sample Australian aerodromes
  const aerodromes = [
    { icao: 'YSSY', name: 'Sydney Kingsford Smith', lat: -33.9461, lng: 151.1772, elevation: 21, type: 'AIRPORT' as const, 
      runways: [{ designator: '16R/34L', length: 3962, width: 45, surface: 'ASPHALT', magneticBearing: 165 },
                { designator: '16L/34R', length: 2530, width: 45, surface: 'ASPHALT', magneticBearing: 165 },
                { designator: '07/25', length: 2438, width: 45, surface: 'ASPHALT', magneticBearing: 75 }],
      frequencies: [{ type: 'TWR', frequency: 120.5, name: 'Sydney Tower' },
                   { type: 'APP', frequency: 124.4, name: 'Sydney Approach' },
                   { type: 'ATIS', frequency: 126.25, name: 'Sydney ATIS' }] },
    { icao: 'YMML', name: 'Melbourne Tullamarine', lat: -37.6733, lng: 144.8433, elevation: 434, type: 'AIRPORT' as const,
      runways: [{ designator: '16/34', length: 3657, width: 45, surface: 'ASPHALT', magneticBearing: 165 },
                { designator: '09/27', length: 2286, width: 45, surface: 'ASPHALT', magneticBearing: 92 }],
      frequencies: [{ type: 'TWR', frequency: 120.5, name: 'Melbourne Tower' },
                   { type: 'APP', frequency: 132.0, name: 'Melbourne Approach' }] },
    { icao: 'YBBN', name: 'Brisbane', lat: -27.3842, lng: 153.1175, elevation: 13, type: 'AIRPORT' as const,
      runways: [{ designator: '01/19', length: 3560, width: 45, surface: 'ASPHALT', magneticBearing: 15 },
                { designator: '14/32', length: 1762, width: 30, surface: 'ASPHALT', magneticBearing: 142 }],
      frequencies: [{ type: 'TWR', frequency: 120.5, name: 'Brisbane Tower' },
                   { type: 'APP', frequency: 125.6, name: 'Brisbane Approach' }] },
    { icao: 'YSBK', name: 'Bankstown', lat: -33.9244, lng: 150.9886, elevation: 29, type: 'AIRPORT' as const,
      runways: [{ designator: '11L/29R', length: 1411, width: 30, surface: 'ASPHALT', magneticBearing: 115 },
                { designator: '11C/29C', length: 1198, width: 30, surface: 'ASPHALT', magneticBearing: 115 },
                { designator: '11R/29L', length: 914, width: 18, surface: 'ASPHALT', magneticBearing: 115 }],
      frequencies: [{ type: 'TWR', frequency: 123.6, name: 'Bankstown Tower' },
                   { type: 'ATIS', frequency: 120.9, name: 'Bankstown ATIS' }] },
    { icao: 'YMMB', name: 'Moorabbin', lat: -37.9758, lng: 145.1022, elevation: 50, type: 'AIRPORT' as const,
      runways: [{ designator: '13L/31R', length: 1335, width: 30, surface: 'ASPHALT', magneticBearing: 135 },
                { designator: '13R/31L', length: 1061, width: 18, surface: 'ASPHALT', magneticBearing: 135 },
                { designator: '17L/35R', length: 1198, width: 30, surface: 'ASPHALT', magneticBearing: 175 },
                { designator: '17R/35L', length: 808, width: 18, surface: 'ASPHALT', magneticBearing: 175 }],
      frequencies: [{ type: 'TWR', frequency: 118.1, name: 'Moorabbin Tower' },
                   { type: 'ATIS', frequency: 120.9, name: 'Moorabbin ATIS' }] },
    { icao: 'YSCN', name: 'Camden', lat: -34.0403, lng: 150.6872, elevation: 230, type: 'AIRPORT' as const,
      runways: [{ designator: '06/24', length: 1220, width: 30, surface: 'ASPHALT', magneticBearing: 62 },
                { designator: '10/28', length: 1067, width: 18, surface: 'ASPHALT', magneticBearing: 102 }],
      frequencies: [{ type: 'CTAF', frequency: 120.1, name: 'Camden CTAF' }] },
    { icao: 'YCEM', name: 'Cessnock', lat: -32.7875, lng: 151.3417, elevation: 210, type: 'AIRPORT' as const,
      runways: [{ designator: '17/35', length: 1097, width: 18, surface: 'ASPHALT', magneticBearing: 175 }],
      frequencies: [{ type: 'CTAF', frequency: 119.65, name: 'Cessnock CTAF' }] },
    { icao: 'YWLM', name: 'Newcastle Williamtown', lat: -32.7950, lng: 151.8428, elevation: 9, type: 'AIRPORT' as const,
      runways: [{ designator: '12/30', length: 2438, width: 45, surface: 'ASPHALT', magneticBearing: 122 }],
      frequencies: [{ type: 'TWR', frequency: 118.3, name: 'Williamtown Tower' },
                   { type: 'APP', frequency: 133.3, name: 'Williamtown Approach' }] },
    { icao: 'YCFS', name: 'Coffs Harbour', lat: -30.3206, lng: 153.1156, elevation: 18, type: 'AIRPORT' as const,
      runways: [{ designator: '03/21', length: 2063, width: 45, surface: 'ASPHALT', magneticBearing: 32 }],
      frequencies: [{ type: 'TWR', frequency: 118.2, name: 'Coffs Tower' }] },
    { icao: 'YBTH', name: 'Bathurst', lat: -33.4094, lng: 149.6522, elevation: 2435, type: 'AIRPORT' as const,
      runways: [{ designator: '17/35', length: 1676, width: 30, surface: 'ASPHALT', magneticBearing: 175 },
                { designator: '08/26', length: 1220, width: 30, surface: 'ASPHALT', magneticBearing: 82 }],
      frequencies: [{ type: 'CTAF', frequency: 119.0, name: 'Bathurst CTAF' }] },
    { icao: 'YMAV', name: 'Avalon', lat: -38.0394, lng: 144.4694, elevation: 35, type: 'AIRPORT' as const,
      runways: [{ designator: '18/36', length: 3048, width: 45, surface: 'ASPHALT', magneticBearing: 184 }],
      frequencies: [{ type: 'TWR', frequency: 120.1, name: 'Avalon Tower' }] },
    { icao: 'YPAD', name: 'Adelaide', lat: -34.9450, lng: 138.5306, elevation: 20, type: 'AIRPORT' as const,
      runways: [{ designator: '05/23', length: 3100, width: 45, surface: 'ASPHALT', magneticBearing: 53 },
                { designator: '12/30', length: 1652, width: 30, surface: 'ASPHALT', magneticBearing: 122 }],
      frequencies: [{ type: 'TWR', frequency: 120.5, name: 'Adelaide Tower' },
                   { type: 'APP', frequency: 124.2, name: 'Adelaide Approach' }] },
    { icao: 'YPPH', name: 'Perth', lat: -31.9403, lng: 115.9669, elevation: 67, type: 'AIRPORT' as const,
      runways: [{ designator: '03/21', length: 3444, width: 45, surface: 'ASPHALT', magneticBearing: 32 },
                { designator: '06/24', length: 2163, width: 45, surface: 'ASPHALT', magneticBearing: 62 }],
      frequencies: [{ type: 'TWR', frequency: 127.4, name: 'Perth Tower' },
                   { type: 'APP', frequency: 123.6, name: 'Perth Approach' }] },
  ]

  for (const aerodrome of aerodromes) {
    await prisma.aerodrome.upsert({
      where: { icao: aerodrome.icao },
      update: {},
      create: aerodrome,
    })
    console.log('Created aerodrome:', aerodrome.icao, '-', aerodrome.name)
  }

  // Create sample waypoints (VORs, NDBs, and reporting points)
  const waypoints = [
    { identifier: 'SY', name: 'Sydney VOR', lat: -33.9461, lng: 151.1772, type: 'VOR' as const, frequency: 115.4 },
    { identifier: 'RIC', name: 'Richmond VOR', lat: -33.6006, lng: 150.7811, type: 'VOR' as const, frequency: 117.7 },
    { identifier: 'WOL', name: 'Wollongong VOR', lat: -34.5611, lng: 150.7889, type: 'VOR' as const, frequency: 116.0 },
    { identifier: 'ML', name: 'Melbourne VOR', lat: -37.6733, lng: 144.8433, type: 'VOR' as const, frequency: 114.1 },
    { identifier: 'BN', name: 'Brisbane VOR', lat: -27.3842, lng: 153.1175, type: 'VOR' as const, frequency: 114.7 },
    { identifier: 'CN', name: 'Canberra VOR', lat: -35.3069, lng: 149.1950, type: 'VOR' as const, frequency: 116.7 },
    { identifier: 'TAM', name: 'Tamworth VOR', lat: -31.0839, lng: 150.8469, type: 'VOR' as const, frequency: 116.1 },
    { identifier: 'DBO', name: 'Dubbo VOR', lat: -32.2167, lng: 148.5747, type: 'VOR' as const, frequency: 113.3 },
    { identifier: 'AY', name: 'Albury NDB', lat: -36.0678, lng: 146.9581, type: 'NDB' as const, frequency: 269 },
    { identifier: 'WG', name: 'Wagga NDB', lat: -35.1653, lng: 147.4664, type: 'NDB' as const, frequency: 395 },
    { identifier: 'TESAT', name: 'TESAT', lat: -33.7500, lng: 151.0000, type: 'WAYPOINT' as const },
    { identifier: 'BOREE', name: 'BOREE', lat: -33.5000, lng: 150.5000, type: 'WAYPOINT' as const },
    { identifier: 'KADOM', name: 'KADOM', lat: -34.0000, lng: 151.5000, type: 'WAYPOINT' as const },
    { identifier: 'OVLET', name: 'OVLET', lat: -33.3000, lng: 151.2000, type: 'WAYPOINT' as const },
    { identifier: 'ANKUB', name: 'ANKUB', lat: -34.5000, lng: 150.5000, type: 'WAYPOINT' as const },
  ]

  for (const waypoint of waypoints) {
    await prisma.waypoint.upsert({
      where: { identifier: waypoint.identifier },
      update: {},
      create: waypoint,
    })
    console.log('Created waypoint:', waypoint.identifier, '-', waypoint.name)
  }

  // Create sample airways
  const airways = [
    { 
      identifier: 'W113', 
      type: 'LOW' as const,
      minimumAltitude: 4500,
      waypoints: ['SY', 'TESAT', 'RIC'],
      segments: [
        { from: 'SY', to: 'TESAT', track: 315, distance: 22, minAlt: 4500, maxAlt: 24500 },
        { from: 'TESAT', to: 'RIC', track: 330, distance: 25, minAlt: 4500, maxAlt: 24500 },
      ]
    },
    { 
      identifier: 'W116', 
      type: 'LOW' as const,
      minimumAltitude: 4500,
      waypoints: ['SY', 'ANKUB', 'WOL'],
      segments: [
        { from: 'SY', to: 'ANKUB', track: 210, distance: 35, minAlt: 4500, maxAlt: 24500 },
        { from: 'ANKUB', to: 'WOL', track: 195, distance: 28, minAlt: 4500, maxAlt: 24500 },
      ]
    },
    {
      identifier: 'V169',
      type: 'LOW' as const,
      minimumAltitude: 5500,
      waypoints: ['SY', 'CN'],
      segments: [
        { from: 'SY', to: 'CN', track: 230, distance: 148, minAlt: 5500, maxAlt: 24500 },
      ]
    },
  ]

  for (const airway of airways) {
    await prisma.airway.upsert({
      where: { identifier: airway.identifier },
      update: {},
      create: airway,
    })
    console.log('Created airway:', airway.identifier)
  }

  // Create sample airspace
  const airspaces = [
    {
      identifier: 'YSSY-CTR',
      name: 'Sydney CTR',
      type: 'CTR' as const,
      class: 'C' as const,
      lowerLimit: 0,
      upperLimit: 4500,
      lowerLimitUnit: 'FT',
      upperLimitUnit: 'FT',
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [150.85, -34.15], [151.45, -34.15], [151.45, -33.70],
          [150.85, -33.70], [150.85, -34.15]
        ]]
      },
    },
    {
      identifier: 'YMML-CTR',
      name: 'Melbourne CTR',
      type: 'CTR' as const,
      class: 'C' as const,
      lowerLimit: 0,
      upperLimit: 4500,
      lowerLimitUnit: 'FT',
      upperLimitUnit: 'FT',
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [144.55, -37.95], [145.15, -37.95], [145.15, -37.40],
          [144.55, -37.40], [144.55, -37.95]
        ]]
      },
    },
    {
      identifier: 'YSBK-CTR',
      name: 'Bankstown CTR',
      type: 'CTR' as const,
      class: 'D' as const,
      lowerLimit: 0,
      upperLimit: 2500,
      lowerLimitUnit: 'FT',
      upperLimitUnit: 'FT',
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [150.90, -34.00], [151.10, -34.00], [151.10, -33.85],
          [150.90, -33.85], [150.90, -34.00]
        ]]
      },
    },
  ]

  for (const airspace of airspaces) {
    await prisma.airspace.upsert({
      where: { identifier: airspace.identifier },
      update: {},
      create: airspace,
    })
    console.log('Created airspace:', airspace.identifier, '-', airspace.name)
  }

  // Create initial AIRAC cycle
  const now = new Date()
  const airacEffective = new Date('2026-03-26') // Example current AIRAC
  const airacExpiry = new Date('2026-04-23')
  
  await prisma.aIRACCycle.create({
    data: {
      cycleNumber: '2603',
      effectiveDate: airacEffective,
      expiryDate: airacExpiry,
      source: 'MANUAL_SEED',
    },
  })
  console.log('Created AIRAC cycle: 2603')

  console.log('\n=== Seed completed successfully ===')
  console.log('\nDefault admin credentials:')
  console.log('Email: admin@flightplan.com.au')
  console.log('Password: admin123')
  console.log('\nPLEASE CHANGE THIS PASSWORD AFTER FIRST LOGIN!')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })
