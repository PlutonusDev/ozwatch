const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('Starting database seed...');

  // Create admin user
  const hashedPassword = await bcrypt.hash('admin123', 12);
  
  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@flightplan.com.au' },
    update: {},
    create: {
      email: 'admin@flightplan.com.au',
      name: 'System Administrator',
      password: hashedPassword,
      role: 'ADMIN',
      pilotLicense: 'ATPL',
      medicalExpiry: new Date('2026-12-31'),
    },
  });
  console.log('Created admin user:', adminUser.email);

  // Create base aircraft profiles
  const aircraftProfiles = [
    {
      registration: 'BASE-C172S',
      type: 'C172',
      name: 'Cessna 172S Skyhawk',
      isBaseProfile: true,
      category: 'AEROPLANE',
      performanceCategory: 'A',
      emptyWeight: 767,
      maxTakeoffWeight: 1157,
      maxLandingWeight: 1157,
      fuelCapacity: 212,
      usableFuel: 200,
      fuelBurnRate: 36,
      cruiseSpeed: 122,
      cruiseAltitude: 8000,
      climbRate: 730,
      descentRate: 500,
      takeoffDistance: 494,
      landingDistance: 395,
      vSpeeds: {
        vS0: 40, vS1: 48, vR: 55, vX: 62, vY: 74,
        vA: 105, vNO: 129, vNE: 163, vFE: 85
      },
      cgLimits: {
        forwardLimit: 35.0, aftLimit: 47.2,
        envelopePoints: [
          { weight: 680, cgMin: 35.0, cgMax: 47.2 },
          { weight: 900, cgMin: 35.0, cgMax: 47.2 },
          { weight: 1157, cgMin: 37.0, cgMax: 47.2 }
        ]
      },
      armData: {
        pilotArm: 37.0, frontPassengerArm: 37.0,
        rearPassengerArm: 73.0, baggageArm: 95.0,
        fuelArm: 48.0, maxBaggage: 54
      },
      equipmentCodes: 'SDFGRY/S',
      surveillanceCodes: 'C',
      wakeTurbulence: 'L'
    },
    {
      registration: 'BASE-PA28',
      type: 'P28A',
      name: 'Piper PA-28-161 Warrior',
      isBaseProfile: true,
      category: 'AEROPLANE',
      performanceCategory: 'A',
      emptyWeight: 635,
      maxTakeoffWeight: 1107,
      maxLandingWeight: 1107,
      fuelCapacity: 189,
      usableFuel: 182,
      fuelBurnRate: 34,
      cruiseSpeed: 117,
      cruiseAltitude: 7500,
      climbRate: 644,
      descentRate: 500,
      takeoffDistance: 488,
      landingDistance: 320,
      vSpeeds: {
        vS0: 44, vS1: 50, vR: 55, vX: 63, vY: 76,
        vA: 89, vNO: 126, vNE: 154, vFE: 103
      },
      cgLimits: {
        forwardLimit: 83.0, aftLimit: 93.0,
        envelopePoints: [
          { weight: 635, cgMin: 83.0, cgMax: 93.0 },
          { weight: 900, cgMin: 83.0, cgMax: 93.0 },
          { weight: 1107, cgMin: 85.0, cgMax: 93.0 }
        ]
      },
      armData: {
        pilotArm: 80.5, frontPassengerArm: 80.5,
        rearPassengerArm: 118.1, baggageArm: 142.8,
        fuelArm: 95.0, maxBaggage: 91
      },
      equipmentCodes: 'SDFGRY/S',
      surveillanceCodes: 'C',
      wakeTurbulence: 'L'
    },
    {
      registration: 'BASE-BE76',
      type: 'BE76',
      name: 'Beechcraft BE76 Duchess',
      isBaseProfile: true,
      category: 'AEROPLANE',
      performanceCategory: 'A',
      emptyWeight: 1193,
      maxTakeoffWeight: 1769,
      maxLandingWeight: 1701,
      fuelCapacity: 409,
      usableFuel: 394,
      fuelBurnRate: 72,
      cruiseSpeed: 155,
      cruiseAltitude: 10000,
      climbRate: 1248,
      descentRate: 600,
      takeoffDistance: 686,
      landingDistance: 594,
      vSpeeds: {
        vS0: 60, vS1: 69, vR: 71, vX: 85, vY: 89,
        vA: 129, vNO: 172, vNE: 194, vFE: 113,
        vMC: 66, vSSE: 82, vYSE: 89
      },
      cgLimits: {
        forwardLimit: 107.5, aftLimit: 117.0,
        envelopePoints: [
          { weight: 1193, cgMin: 107.5, cgMax: 117.0 },
          { weight: 1500, cgMin: 108.0, cgMax: 117.0 },
          { weight: 1769, cgMin: 109.0, cgMax: 117.0 }
        ]
      },
      armData: {
        pilotArm: 113.0, frontPassengerArm: 113.0,
        rearPassengerArm: 153.0, baggageArm: 175.0,
        fuelArm: 113.5, maxBaggage: 91
      },
      equipmentCodes: 'SDFGRY/S',
      surveillanceCodes: 'C',
      wakeTurbulence: 'L'
    }
  ];

  for (const aircraft of aircraftProfiles) {
    await prisma.aircraftProfile.upsert({
      where: { registration: aircraft.registration },
      update: aircraft,
      create: aircraft,
    });
    console.log('Created aircraft profile:', aircraft.name);
  }

  // Create Australian aerodromes
  const aerodromes = [
    { icao: 'YSSY', name: 'Sydney Kingsford Smith', latitude: -33.9399, longitude: 151.1753, elevation: 21, type: 'INTERNATIONAL', ctafFrequency: '120.5' },
    { icao: 'YMML', name: 'Melbourne', latitude: -37.6733, longitude: 144.8433, elevation: 434, type: 'INTERNATIONAL', ctafFrequency: '120.9' },
    { icao: 'YBBN', name: 'Brisbane', latitude: -27.3842, longitude: 153.1175, elevation: 13, type: 'INTERNATIONAL', ctafFrequency: '120.1' },
    { icao: 'YPPH', name: 'Perth', latitude: -31.9403, longitude: 115.9672, elevation: 67, type: 'INTERNATIONAL', ctafFrequency: '121.7' },
    { icao: 'YPAD', name: 'Adelaide', latitude: -34.9447, longitude: 138.5311, elevation: 20, type: 'INTERNATIONAL', ctafFrequency: '120.1' },
    { icao: 'YSCB', name: 'Canberra', latitude: -35.3069, longitude: 149.1950, elevation: 1886, type: 'DOMESTIC', ctafFrequency: '124.9' },
    { icao: 'YBCG', name: 'Gold Coast', latitude: -28.1644, longitude: 153.5047, elevation: 21, type: 'INTERNATIONAL', ctafFrequency: '119.7' },
    { icao: 'YBCS', name: 'Cairns', latitude: -16.8858, longitude: 145.7553, elevation: 10, type: 'INTERNATIONAL', ctafFrequency: '118.1' },
    { icao: 'YPDN', name: 'Darwin', latitude: -12.4147, longitude: 130.8769, elevation: 103, type: 'INTERNATIONAL', ctafFrequency: '133.1' },
    { icao: 'YMHB', name: 'Hobart', latitude: -42.8361, longitude: 147.5103, elevation: 13, type: 'DOMESTIC', ctafFrequency: '118.1' },
    { icao: 'YMEN', name: 'Essendon', latitude: -37.7281, longitude: 144.9019, elevation: 282, type: 'GA', ctafFrequency: '125.1', isCTAF: true },
    { icao: 'YSBK', name: 'Bankstown', latitude: -33.9244, longitude: 150.9886, elevation: 29, type: 'GA', ctafFrequency: '123.6', isCTAF: true },
    { icao: 'YMMB', name: 'Moorabbin', latitude: -37.9758, longitude: 145.1022, elevation: 50, type: 'GA', ctafFrequency: '123.0', isCTAF: true },
    { icao: 'YBAF', name: 'Archerfield', latitude: -27.5703, longitude: 153.0078, elevation: 63, type: 'GA', ctafFrequency: '124.1', isCTAF: true },
    { icao: 'YPJT', name: 'Jandakot', latitude: -32.0975, longitude: 115.8811, elevation: 99, type: 'GA', ctafFrequency: '118.1', isCTAF: true },
    { icao: 'YPPF', name: 'Parafield', latitude: -34.7933, longitude: 138.6331, elevation: 57, type: 'GA', ctafFrequency: '120.9', isCTAF: true },
    { icao: 'YTWB', name: 'Toowoomba Wellcamp', latitude: -27.5583, longitude: 151.7931, elevation: 1509, type: 'DOMESTIC', ctafFrequency: '127.45' },
    { icao: 'YAMB', name: 'Amberley', latitude: -27.6406, longitude: 152.7117, elevation: 95, type: 'MILITARY', ctafFrequency: '132.2' },
    { icao: 'YBNA', name: 'Ballina', latitude: -28.8339, longitude: 153.5622, elevation: 7, type: 'DOMESTIC', ctafFrequency: '126.2' },
    { icao: 'YBWW', name: 'Bowenville', latitude: -27.3167, longitude: 151.4667, elevation: 1240, type: 'PRIVATE', ctafFrequency: '126.7', isCTAF: true }
  ];

  for (const ad of aerodromes) {
    await prisma.aerodrome.upsert({
      where: { icao: ad.icao },
      update: ad,
      create: ad,
    });
  }
  console.log(`Created ${aerodromes.length} aerodromes`);

  // Create waypoints/navaids
  const waypoints = [
    { identifier: 'TESAT', name: 'TESAT', type: 'FIX', latitude: -33.5500, longitude: 150.8833 },
    { identifier: 'RIVET', name: 'RIVET', type: 'FIX', latitude: -33.7667, longitude: 150.5167 },
    { identifier: 'BOREE', name: 'BOREE', type: 'FIX', latitude: -34.1000, longitude: 150.9500 },
    { identifier: 'ANKUB', name: 'ANKUB', type: 'FIX', latitude: -27.9667, longitude: 153.3333 },
    { identifier: 'BLAKA', name: 'BLAKA', type: 'FIX', latitude: -27.1167, longitude: 153.1667 },
    { identifier: 'SY', name: 'Sydney VOR/DME', type: 'VOR_DME', latitude: -33.9464, longitude: 151.1731, frequency: '115.4' },
    { identifier: 'ML', name: 'Melbourne VOR/DME', type: 'VOR_DME', latitude: -37.6656, longitude: 144.8419, frequency: '114.1' },
    { identifier: 'BN', name: 'Brisbane VOR/DME', type: 'VOR_DME', latitude: -27.3917, longitude: 153.1214, frequency: '114.7' },
    { identifier: 'PH', name: 'Perth VOR/DME', type: 'VOR_DME', latitude: -31.9339, longitude: 115.9611, frequency: '113.8' },
    { identifier: 'AD', name: 'Adelaide VOR/DME', type: 'VOR_DME', latitude: -34.9372, longitude: 138.5294, frequency: '116.3' },
    { identifier: 'CB', name: 'Canberra VOR/DME', type: 'VOR_DME', latitude: -35.3044, longitude: 149.1919, frequency: '116.5' },
    { identifier: 'CS', name: 'Cairns VOR/DME', type: 'VOR_DME', latitude: -16.8833, longitude: 145.7500, frequency: '113.5' },
    { identifier: 'DN', name: 'Darwin VOR/DME', type: 'VOR_DME', latitude: -12.4167, longitude: 130.8833, frequency: '114.9' },
    { identifier: 'YAKKA', name: 'YAKKA', type: 'FIX', latitude: -26.5833, longitude: 153.1667 },
    { identifier: 'WACKO', name: 'WACKO', type: 'FIX', latitude: -27.8500, longitude: 153.0667 }
  ];

  for (const wp of waypoints) {
    await prisma.waypoint.upsert({
      where: { identifier: wp.identifier },
      update: wp,
      create: wp,
    });
  }
  console.log(`Created ${waypoints.length} waypoints`);

  // Create airways
  const airways = [
    {
      identifier: 'W113',
      type: 'LOW',
      startWaypoint: 'YSSY',
      endWaypoint: 'TESAT',
      lowerLimit: 1500,
      upperLimit: 24500,
      direction: 'BOTH',
      magneticTrack: 320,
      distance: 25
    },
    {
      identifier: 'W411',
      type: 'LOW',
      startWaypoint: 'YBBN',
      endWaypoint: 'ANKUB',
      lowerLimit: 1500,
      upperLimit: 24500,
      direction: 'BOTH',
      magneticTrack: 115,
      distance: 30
    },
    {
      identifier: 'Q29',
      type: 'HIGH',
      startWaypoint: 'SY',
      endWaypoint: 'ML',
      lowerLimit: 18000,
      upperLimit: 60000,
      direction: 'BOTH',
      magneticTrack: 223,
      distance: 390
    },
    {
      identifier: 'Q158',
      type: 'HIGH',
      startWaypoint: 'SY',
      endWaypoint: 'BN',
      lowerLimit: 18000,
      upperLimit: 60000,
      direction: 'BOTH',
      magneticTrack: 15,
      distance: 410
    }
  ];

  for (const airway of airways) {
    await prisma.airway.upsert({
      where: { identifier: airway.identifier },
      update: airway,
      create: airway,
    });
  }
  console.log(`Created ${airways.length} airways`);

  // Create airspace
  const airspaces = [
    {
      name: 'Sydney CTR',
      type: 'CTR',
      classification: 'C',
      lowerLimit: 0,
      upperLimit: 4500,
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [150.85, -34.15], [151.45, -34.15], [151.45, -33.70],
          [150.85, -33.70], [150.85, -34.15]
        ]]
      },
      controllingAuthority: 'Sydney Approach'
    },
    {
      name: 'Melbourne CTR',
      type: 'CTR',
      classification: 'C',
      lowerLimit: 0,
      upperLimit: 4500,
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [144.55, -37.95], [145.15, -37.95], [145.15, -37.45],
          [144.55, -37.45], [144.55, -37.95]
        ]]
      },
      controllingAuthority: 'Melbourne Approach'
    },
    {
      name: 'Brisbane CTR',
      type: 'CTR',
      classification: 'C',
      lowerLimit: 0,
      upperLimit: 4500,
      geometry: {
        type: 'Polygon',
        coordinates: [[
          [152.90, -27.65], [153.35, -27.65], [153.35, -27.15],
          [152.90, -27.15], [152.90, -27.65]
        ]]
      },
      controllingAuthority: 'Brisbane Approach'
    }
  ];

  for (const airspace of airspaces) {
    await prisma.airspace.upsert({
      where: { name: airspace.name },
      update: airspace,
      create: airspace,
    });
  }
  console.log(`Created ${airspaces.length} airspace zones`);

  // Create current AIRAC cycle
  const airacCycle = await prisma.aIRACCycle.upsert({
    where: { cycleNumber: '2504' },
    update: {},
    create: {
      cycleNumber: '2504',
      effectiveDate: new Date('2025-04-03'),
      expiryDate: new Date('2025-05-01'),
      isActive: true,
    },
  });
  console.log('Created AIRAC cycle:', airacCycle.cycleNumber);

  console.log('Database seeding completed successfully!');
}

main()
  .catch((e) => {
    console.error('Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
