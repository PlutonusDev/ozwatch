"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Users, 
  Plane, 
  Database, 
  Settings, 
  Plus, 
  Edit2, 
  Trash2,
  Shield,
  Mail,
  Calendar,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Key,
  AlertTriangle,
  Upload
} from "lucide-react";
import { useAuth } from "@/components/providers/auth-provider";

interface User {
  id: string;
  email: string;
  name: string;
  role: "admin" | "user";
  isActive: boolean;
  createdAt: string;
  lastLogin?: string;
}

interface AiracData {
  cycle: string;
  effectiveDate: string;
  expiryDate: string;
  status: "current" | "expired" | "upcoming";
  lastUpdated: string;
}

export default function AdminPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [users, setUsers] = useState<User[]>([]);
  const [airacData, setAiracData] = useState<AiracData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUserDialogOpen, setIsUserDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [newUserData, setNewUserData] = useState({
    email: "",
    name: "",
    password: "",
    role: "user" as "admin" | "user",
  });
  const [naipsConfig, setNaipsConfig] = useState({
    username: "",
    password: "",
    isConfigured: false,
  });

  useEffect(() => {
    if (user?.role !== "admin") {
      router.push("/dashboard");
      return;
    }
    fetchData();
  }, [user, router]);

  async function fetchData() {
    setIsLoading(true);
    try {
      // Fetch users
      const usersRes = await fetch("/api/admin/users");
      const usersData = await usersRes.json();
      setUsers(usersData.users || []);

      // Fetch AIRAC status
      const airacRes = await fetch("/api/admin/airac");
      const airacDataRes = await airacRes.json();
      setAiracData(airacDataRes.airac);

      // Check NAIPS config
      const naipsRes = await fetch("/api/admin/naips/status");
      const naipsData = await naipsRes.json();
      setNaipsConfig(prev => ({ ...prev, isConfigured: naipsData.isConfigured }));
    } catch (error) {
      console.error("Failed to fetch admin data:", error);
    } finally {
      setIsLoading(false);
    }
  }

  async function handleCreateUser() {
    try {
      const res = await fetch("/api/admin/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newUserData),
      });
      
      if (res.ok) {
        fetchData();
        setIsUserDialogOpen(false);
        setNewUserData({ email: "", name: "", password: "", role: "user" });
      }
    } catch (error) {
      console.error("Failed to create user:", error);
    }
  }

  async function handleUpdateUser(userId: string, updates: Partial<User>) {
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      
      if (res.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Failed to update user:", error);
    }
  }

  async function handleDeleteUser(userId: string) {
    if (!confirm("Are you sure you want to delete this user?")) return;
    
    try {
      const res = await fetch(`/api/admin/users/${userId}`, { method: "DELETE" });
      if (res.ok) {
        fetchData();
      }
    } catch (error) {
      console.error("Failed to delete user:", error);
    }
  }

  async function handleResetPassword(userId: string) {
    const newPassword = prompt("Enter new password:");
    if (!newPassword) return;
    
    try {
      const res = await fetch(`/api/admin/users/${userId}/reset-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: newPassword }),
      });
      
      if (res.ok) {
        alert("Password reset successfully");
      }
    } catch (error) {
      console.error("Failed to reset password:", error);
    }
  }

  async function handleSaveNaipsConfig() {
    try {
      const res = await fetch("/api/admin/naips/configure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: naipsConfig.username,
          password: naipsConfig.password,
        }),
      });
      
      if (res.ok) {
        alert("NAIPS configuration saved");
        setNaipsConfig(prev => ({ ...prev, isConfigured: true }));
      }
    } catch (error) {
      console.error("Failed to save NAIPS config:", error);
    }
  }

  async function handleUpdateAirac() {
    try {
      const res = await fetch("/api/admin/airac/update", { method: "POST" });
      if (res.ok) {
        fetchData();
        alert("AIRAC data update initiated");
      }
    } catch (error) {
      console.error("Failed to update AIRAC:", error);
    }
  }

  if (user?.role !== "admin") {
    return (
      <div className="h-full flex items-center justify-center">
        <Alert variant="destructive" className="max-w-md">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            You do not have permission to access this page.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border bg-card">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Admin Dashboard
            </h1>
            <p className="text-sm text-muted-foreground">
              Manage users, aircraft profiles, and system settings
            </p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="p-4 grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-500/10 rounded-lg">
                <Users className="h-6 w-6 text-blue-500" />
              </div>
              <div>
                <div className="text-2xl font-bold">{users.length}</div>
                <div className="text-sm text-muted-foreground">Total Users</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-500/10 rounded-lg">
                <CheckCircle2 className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <div className="text-2xl font-bold">{users.filter(u => u.isActive).length}</div>
                <div className="text-sm text-muted-foreground">Active Users</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-purple-500/10 rounded-lg">
                <Database className="h-6 w-6 text-purple-500" />
              </div>
              <div>
                <div className="text-2xl font-bold">{airacData?.cycle || "-"}</div>
                <div className="text-sm text-muted-foreground">AIRAC Cycle</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-lg ${naipsConfig.isConfigured ? "bg-green-500/10" : "bg-orange-500/10"}`}>
                <Settings className={`h-6 w-6 ${naipsConfig.isConfigured ? "text-green-500" : "text-orange-500"}`} />
              </div>
              <div>
                <div className="text-2xl font-bold">{naipsConfig.isConfigured ? "Yes" : "No"}</div>
                <div className="text-sm text-muted-foreground">NAIPS Configured</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        <Tabs defaultValue="users">
          <TabsList>
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="aircraft">Base Aircraft</TabsTrigger>
            <TabsTrigger value="airac">AIRAC Data</TabsTrigger>
            <TabsTrigger value="naips">NAIPS Integration</TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Users</h2>
              <Dialog open={isUserDialogOpen} onOpenChange={setIsUserDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Create User
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New User</DialogTitle>
                    <DialogDescription>
                      Create a new user account. Users cannot self-register.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>Email</Label>
                      <Input
                        type="email"
                        value={newUserData.email}
                        onChange={(e) => setNewUserData(prev => ({ ...prev, email: e.target.value }))}
                        placeholder="user@example.com"
                      />
                    </div>
                    <div>
                      <Label>Name</Label>
                      <Input
                        value={newUserData.name}
                        onChange={(e) => setNewUserData(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="John Smith"
                      />
                    </div>
                    <div>
                      <Label>Password</Label>
                      <Input
                        type="password"
                        value={newUserData.password}
                        onChange={(e) => setNewUserData(prev => ({ ...prev, password: e.target.value }))}
                        placeholder="Secure password"
                      />
                    </div>
                    <div>
                      <Label>Role</Label>
                      <Select 
                        value={newUserData.role} 
                        onValueChange={(v: "admin" | "user") => setNewUserData(prev => ({ ...prev, role: v }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="user">User</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button onClick={handleCreateUser} className="w-full">
                      Create User
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <Card>
              <CardContent className="p-0">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="text-left p-3">User</th>
                      <th className="text-left p-3">Role</th>
                      <th className="text-left p-3">Status</th>
                      <th className="text-left p-3">Created</th>
                      <th className="text-left p-3">Last Login</th>
                      <th className="text-right p-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((u) => (
                      <tr key={u.id} className="border-b">
                        <td className="p-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <span className="text-sm font-medium text-primary">
                                {u.name.charAt(0).toUpperCase()}
                              </span>
                            </div>
                            <div>
                              <div className="font-medium">{u.name}</div>
                              <div className="text-sm text-muted-foreground">{u.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-3">
                          <Badge variant={u.role === "admin" ? "default" : "secondary"}>
                            {u.role}
                          </Badge>
                        </td>
                        <td className="p-3">
                          {u.isActive ? (
                            <Badge variant="secondary" className="bg-green-500/20 text-green-500">
                              Active
                            </Badge>
                          ) : (
                            <Badge variant="secondary" className="bg-red-500/20 text-red-500">
                              Inactive
                            </Badge>
                          )}
                        </td>
                        <td className="p-3 text-sm text-muted-foreground">
                          {new Date(u.createdAt).toLocaleDateString()}
                        </td>
                        <td className="p-3 text-sm text-muted-foreground">
                          {u.lastLogin ? new Date(u.lastLogin).toLocaleDateString() : "Never"}
                        </td>
                        <td className="p-3">
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleUpdateUser(u.id, { isActive: !u.isActive })}
                            >
                              {u.isActive ? (
                                <XCircle className="h-4 w-4" />
                              ) : (
                                <CheckCircle2 className="h-4 w-4" />
                              )}
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleResetPassword(u.id)}
                            >
                              <Key className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-destructive"
                              onClick={() => handleDeleteUser(u.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {users.length === 0 && (
                      <tr>
                        <td colSpan={6} className="p-8 text-center text-muted-foreground">
                          No users found. Create your first user above.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="aircraft" className="space-y-4">
            <Alert>
              <Plane className="h-4 w-4" />
              <AlertDescription>
                Base aircraft profiles are available to all users. Go to the Aircraft page to create and manage base profiles.
              </AlertDescription>
            </Alert>
            <Button onClick={() => router.push("/dashboard/aircraft")}>
              Manage Aircraft Profiles
            </Button>
          </TabsContent>

          <TabsContent value="airac" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Database className="h-4 w-4" />
                  AIRAC Cycle Status
                </CardTitle>
                <CardDescription>
                  Aeronautical Information Regulation And Control data
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {airacData ? (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 border rounded-lg">
                      <div className="text-sm text-muted-foreground">Current Cycle</div>
                      <div className="text-2xl font-bold">{airacData.cycle}</div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="text-sm text-muted-foreground">Status</div>
                      <Badge variant={airacData.status === "current" ? "default" : "destructive"}>
                        {airacData.status}
                      </Badge>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="text-sm text-muted-foreground">Effective Date</div>
                      <div className="font-medium">{airacData.effectiveDate}</div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="text-sm text-muted-foreground">Expiry Date</div>
                      <div className="font-medium">{airacData.expiryDate}</div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    No AIRAC data loaded
                  </div>
                )}
                
                <div className="flex gap-2">
                  <Button onClick={handleUpdateAirac}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Update AIRAC Data
                  </Button>
                  <Button variant="outline">
                    <Upload className="h-4 w-4 mr-2" />
                    Import Custom Data
                  </Button>
                </div>

                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    AIRAC data is updated every 28 days. Ensure you have valid data before flight planning.
                    Custom data can be imported from ARINC 424 format files.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="naips" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  NAIPS Integration
                </CardTitle>
                <CardDescription>
                  Configure Airservices Australia NAIPS API credentials
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    NAIPS API access requires a subscription from Airservices Australia.
                    Visit data.airservicesaustralia.com to apply for access.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4 max-w-md">
                  <div>
                    <Label>NAIPS Username</Label>
                    <Input
                      value={naipsConfig.username}
                      onChange={(e) => setNaipsConfig(prev => ({ ...prev, username: e.target.value }))}
                      placeholder="Your NAIPS username"
                    />
                  </div>
                  <div>
                    <Label>NAIPS Password</Label>
                    <Input
                      type="password"
                      value={naipsConfig.password}
                      onChange={(e) => setNaipsConfig(prev => ({ ...prev, password: e.target.value }))}
                      placeholder="Your NAIPS password"
                    />
                  </div>
                  <Button onClick={handleSaveNaipsConfig}>
                    Save Configuration
                  </Button>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-2">Available NAIPS Services</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      {naipsConfig.isConfigured ? (
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-muted-foreground" />
                      )}
                      <span>Weather Briefing (METAR/TAF)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {naipsConfig.isConfigured ? (
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-muted-foreground" />
                      )}
                      <span>NOTAM Retrieval</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {naipsConfig.isConfigured ? (
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-muted-foreground" />
                      )}
                      <span>Flight Plan Submission</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {naipsConfig.isConfigured ? (
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-muted-foreground" />
                      )}
                      <span>SARTIME Management</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
