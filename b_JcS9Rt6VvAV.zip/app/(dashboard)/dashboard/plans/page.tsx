'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { Plane, Plus, Eye, Edit, Trash2, FileText, Send, Clock } from 'lucide-react'
import { format } from 'date-fns'

interface FlightPlan {
  id: string
  flightRules: string
  departure: string
  destination: string
  alternate?: string
  departureTime?: string
  status: string
  createdAt: string
  updatedAt: string
  aircraft?: {
    registration: string
    type: string
  }
}

const statusColors: Record<string, string> = {
  DRAFT: 'bg-muted text-muted-foreground',
  PLANNED: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
  SUBMITTED: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  ACTIVE: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  COMPLETED: 'bg-slate-500/20 text-slate-400 border-slate-500/30',
  CANCELLED: 'bg-red-500/20 text-red-400 border-red-500/30',
}

export default function FlightPlansPage() {
  const [flightPlans, setFlightPlans] = useState<FlightPlan[]>([])
  const [loading, setLoading] = useState(true)
  const [deleteId, setDeleteId] = useState<string | null>(null)

  useEffect(() => {
    fetchFlightPlans()
  }, [])

  const fetchFlightPlans = async () => {
    try {
      const response = await fetch('/api/flightplans')
      if (response.ok) {
        const data = await response.json()
        setFlightPlans(data)
      }
    } catch (error) {
      console.error('Error fetching flight plans:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/flightplans/${id}`, {
        method: 'DELETE',
      })
      if (response.ok) {
        setFlightPlans((prev) => prev.filter((fp) => fp.id !== id))
      }
    } catch (error) {
      console.error('Error deleting flight plan:', error)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">My Flight Plans</h1>
          <p className="text-muted-foreground">
            View and manage your saved flight plans
          </p>
        </div>
        <Button asChild>
          <Link href="/dashboard/plan">
            <Plus className="h-4 w-4 mr-2" />
            New Flight Plan
          </Link>
        </Button>
      </div>

      {flightPlans.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Plane className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No flight plans yet</h3>
            <p className="text-muted-foreground text-center mb-4">
              Create your first flight plan to get started
            </p>
            <Button asChild>
              <Link href="/dashboard/plan">
                <Plus className="h-4 w-4 mr-2" />
                Create Flight Plan
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Flight Plans</CardTitle>
            <CardDescription>
              {flightPlans.length} flight plan{flightPlans.length !== 1 ? 's' : ''}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Route</TableHead>
                  <TableHead>Aircraft</TableHead>
                  <TableHead>Rules</TableHead>
                  <TableHead>Departure</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {flightPlans.map((plan) => (
                  <TableRow key={plan.id}>
                    <TableCell className="font-mono font-semibold">
                      {plan.departure} - {plan.destination}
                      {plan.alternate && (
                        <span className="text-muted-foreground ml-1">
                          / {plan.alternate}
                        </span>
                      )}
                    </TableCell>
                    <TableCell>
                      {plan.aircraft ? (
                        <span className="font-mono">
                          {plan.aircraft.registration}
                          <span className="text-muted-foreground ml-1">
                            ({plan.aircraft.type})
                          </span>
                        </span>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{plan.flightRules}</Badge>
                    </TableCell>
                    <TableCell>
                      {plan.departureTime ? (
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3 text-muted-foreground" />
                          {format(new Date(plan.departureTime), 'dd MMM HH:mm')}Z
                        </div>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={statusColors[plan.status] || ''}
                      >
                        {plan.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {format(new Date(plan.createdAt), 'dd MMM yyyy')}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/dashboard/plan/${plan.id}`}>
                            <Eye className="h-4 w-4" />
                          </Link>
                        </Button>
                        {plan.status !== 'SUBMITTED' && (
                          <>
                            <Button variant="ghost" size="icon" asChild>
                              <Link href={`/dashboard/plan?edit=${plan.id}`}>
                                <Edit className="h-4 w-4" />
                              </Link>
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete Flight Plan</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Are you sure you want to delete this flight plan from{' '}
                                    {plan.departure} to {plan.destination}? This action
                                    cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => handleDelete(plan.id)}
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  >
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </>
                        )}
                        {plan.status === 'PLANNED' && (
                          <Button variant="ghost" size="icon" title="Submit to NAIPS">
                            <Send className="h-4 w-4 text-primary" />
                          </Button>
                        )}
                        <Button variant="ghost" size="icon" asChild title="Generate OFP">
                          <Link href={`/dashboard/plan/${plan.id}?print=true`}>
                            <FileText className="h-4 w-4" />
                          </Link>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
