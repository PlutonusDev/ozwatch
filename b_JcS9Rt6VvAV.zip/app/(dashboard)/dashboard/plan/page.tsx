"use client"

import { useState, useCallback } from "react"
import dynamic from "next/dynamic"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Plane,
  MapPin,
  Navigation,
  Cloud,
  Clock,
  Fuel,
  Weight,
  FileText,
  Plus,
  Trash2,
  ArrowRight,
  Calculator,
  Download,
} from "lucide-react"
import type { MapWaypoint, MapRoute } from "@/components/map/flight-map"

// Dynamic import for the map to avoid SSR issues
const FlightMap = dynamic(
  () => import("@/components/map/flight-map").then((mod) => mod.FlightMap),
  { 
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center h-full bg-muted">
        <span className="text-muted-foreground">Loading map...</span>
      </div>
    ),
  }
)

interface RouteWaypoint extends MapWaypoint {
  legDistance?: number
  cumulativeDistance?: number
  magneticTrack?: number
  lsalt?: number
  eet?: number
}

export default function FlightPlanPage() {
  const [flightRules, setFlightRules] = useState<"VFR" | "IFR">("VFR")
  const [departure, setDeparture] = useState("")
  const [destination, setDestination] = useState("")
  const [alternate, setAlternate] = useState("")
  const [cruiseAltitude, setCruiseAltitude] = useState("")
  const [cruiseSpeed, setCruiseSpeed] = useState("")
  const [routeWaypoints, setRouteWaypoints] = useState<RouteWaypoint[]>([])
  const [selectedAircraft, setSelectedAircraft] = useState("")
  const [departureTime, setDepartureTime] = useState("")

  // Handle waypoint click on map
  const handleWaypointClick = useCallback((waypoint: MapWaypoint) => {
    // Add waypoint to route
    setRouteWaypoints((prev) => {
      // Don't add duplicates
      if (prev.find((wp) => wp.id === waypoint.id)) return prev
      return [...prev, { ...waypoint }]
    })
  }, [])

  // Handle map click - add GPS waypoint
  const handleWaypointAdd = useCallback((partial: Partial<MapWaypoint>) => {
    if (!partial.latitude || !partial.longitude) return
    
    const newWaypoint: RouteWaypoint = {
      id: `gps-${Date.now()}`,
      identifier: `GPS${routeWaypoints.length + 1}`,
      type: "GPS",
      latitude: partial.latitude,
      longitude: partial.longitude,
    }
    
    setRouteWaypoints((prev) => [...prev, newWaypoint])
  }, [routeWaypoints.length])

  // Remove waypoint from route
  const removeWaypoint = useCallback((id: string) => {
    setRouteWaypoints((prev) => prev.filter((wp) => wp.id !== id))
  }, [])

  // Calculate route
  const calculateRoute = useCallback(async () => {
    if (routeWaypoints.length < 2) return

    // Calculate distances and tracks between waypoints
    const updatedWaypoints = routeWaypoints.map((wp, index) => {
      if (index === 0) {
        return { ...wp, legDistance: 0, cumulativeDistance: 0 }
      }

      const prev = routeWaypoints[index - 1]
      // Use haversine formula (simplified)
      const R = 3440.065 // Earth radius in NM
      const lat1 = prev.latitude * Math.PI / 180
      const lat2 = wp.latitude * Math.PI / 180
      const dLat = (wp.latitude - prev.latitude) * Math.PI / 180
      const dLon = (wp.longitude - prev.longitude) * Math.PI / 180

      const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1) * Math.cos(lat2) *
                Math.sin(dLon/2) * Math.sin(dLon/2)
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
      const distance = R * c

      // Calculate true track
      const y = Math.sin(dLon) * Math.cos(lat2)
      const x = Math.cos(lat1) * Math.sin(lat2) -
                Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon)
      let track = Math.atan2(y, x) * 180 / Math.PI
      track = (track + 360) % 360

      const cumulativeDistance = (routeWaypoints[index - 1] as RouteWaypoint).cumulativeDistance || 0

      return {
        ...wp,
        legDistance: Math.round(distance * 10) / 10,
        cumulativeDistance: Math.round((cumulativeDistance + distance) * 10) / 10,
        magneticTrack: Math.round(track), // Would need mag var adjustment
      }
    })

    setRouteWaypoints(updatedWaypoints)

    // Request LSALT calculation for each leg
    for (let i = 1; i < updatedWaypoints.length; i++) {
      const from = updatedWaypoints[i - 1]
      const to = updatedWaypoints[i]
      
      try {
        const response = await fetch("/api/route/lsalt", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            from: { latitude: from.latitude, longitude: from.longitude },
            to: { latitude: to.latitude, longitude: to.longitude },
            flightRules,
          }),
        })
        
        if (response.ok) {
          const data = await response.json()
          setRouteWaypoints((prev) =>
            prev.map((wp) =>
              wp.id === to.id ? { ...wp, lsalt: data.calculatedLSALT } : wp
            )
          )
        }
      } catch (error) {
        console.error("Error calculating LSALT:", error)
      }
    }
  }, [routeWaypoints, flightRules])

  // Build map route object
  const mapRoute: MapRoute | undefined = routeWaypoints.length > 0
    ? { waypoints: routeWaypoints, color: flightRules === "VFR" ? "#22c55e" : "#3b82f6" }
    : undefined

  // Calculate totals
  const totalDistance = routeWaypoints.length > 0
    ? routeWaypoints[routeWaypoints.length - 1].cumulativeDistance || 0
    : 0

  return (
    <div className="flex h-[calc(100vh-4rem)] flex-col lg:flex-row">
      {/* Map Section */}
      <div className="flex-1 relative min-h-[300px] lg:min-h-0">
        <FlightMap
          className="h-full w-full"
          route={mapRoute}
          onWaypointClick={handleWaypointClick}
          onWaypointAdd={handleWaypointAdd}
          showAirports={true}
          showNavaids={true}
          showAirspace={true}
          interactive={true}
        />
        
        {/* Map overlay instructions */}
        <div className="absolute bottom-4 left-4 right-4 lg:right-auto bg-background/90 backdrop-blur-sm border border-border rounded-lg p-3 text-sm max-w-xs">
          <p className="font-medium mb-1">Quick Actions</p>
          <ul className="text-muted-foreground space-y-1 text-xs">
            <li>Click waypoints to add to route</li>
            <li>Right-click to add GPS waypoint</li>
            <li>Drag to pan, scroll to zoom</li>
          </ul>
        </div>
      </div>

      {/* Planning Panel */}
      <div className="w-full lg:w-[480px] border-t lg:border-t-0 lg:border-l border-border flex flex-col bg-background">
        <Tabs defaultValue="route" className="flex-1 flex flex-col">
          <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0">
            <TabsTrigger
              value="route"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
            >
              <Navigation className="mr-2 h-4 w-4" />
              Route
            </TabsTrigger>
            <TabsTrigger
              value="fuel"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
            >
              <Fuel className="mr-2 h-4 w-4" />
              Fuel
            </TabsTrigger>
            <TabsTrigger
              value="weight"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
            >
              <Weight className="mr-2 h-4 w-4" />
              W&B
            </TabsTrigger>
            <TabsTrigger
              value="weather"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent"
            >
              <Cloud className="mr-2 h-4 w-4" />
              Wx
            </TabsTrigger>
          </TabsList>

          <ScrollArea className="flex-1">
            <TabsContent value="route" className="m-0 p-4 space-y-4">
              {/* Flight Rules & Basic Info */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Plane className="h-4 w-4" />
                    Flight Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="flight-rules">Flight Rules</Label>
                      <Select value={flightRules} onValueChange={(v) => setFlightRules(v as "VFR" | "IFR")}>
                        <SelectTrigger id="flight-rules">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="VFR">VFR</SelectItem>
                          <SelectItem value="IFR">IFR</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="aircraft">Aircraft</Label>
                      <Select value={selectedAircraft} onValueChange={setSelectedAircraft}>
                        <SelectTrigger id="aircraft">
                          <SelectValue placeholder="Select..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">No aircraft configured</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="cruise-alt">Cruise Altitude (ft)</Label>
                      <Input
                        id="cruise-alt"
                        type="number"
                        placeholder="5500"
                        value={cruiseAltitude}
                        onChange={(e) => setCruiseAltitude(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cruise-speed">TAS (kts)</Label>
                      <Input
                        id="cruise-speed"
                        type="number"
                        placeholder="110"
                        value={cruiseSpeed}
                        onChange={(e) => setCruiseSpeed(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dep-time">Departure Time (UTC)</Label>
                    <Input
                      id="dep-time"
                      type="datetime-local"
                      value={departureTime}
                      onChange={(e) => setDepartureTime(e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Route Points */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <MapPin className="h-4 w-4" />
                    Route
                  </CardTitle>
                  <CardDescription>
                    Click waypoints on map or enter ICAO codes
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-2">
                      <Label htmlFor="departure">Departure</Label>
                      <Input
                        id="departure"
                        placeholder="YSSY"
                        className="font-mono uppercase"
                        value={departure}
                        onChange={(e) => setDeparture(e.target.value.toUpperCase())}
                        maxLength={4}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="destination">Destination</Label>
                      <Input
                        id="destination"
                        placeholder="YMML"
                        className="font-mono uppercase"
                        value={destination}
                        onChange={(e) => setDestination(e.target.value.toUpperCase())}
                        maxLength={4}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="alternate">Alternate</Label>
                      <Input
                        id="alternate"
                        placeholder="YMEN"
                        className="font-mono uppercase"
                        value={alternate}
                        onChange={(e) => setAlternate(e.target.value.toUpperCase())}
                        maxLength={4}
                      />
                    </div>
                  </div>

                  <Separator />

                  {/* Waypoint List */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Route Waypoints</Label>
                      <Badge variant="secondary">
                        {totalDistance.toFixed(1)} NM
                      </Badge>
                    </div>

                    {routeWaypoints.length === 0 ? (
                      <div className="text-center py-6 text-muted-foreground text-sm">
                        <MapPin className="h-8 w-8 mx-auto mb-2 opacity-50" />
                        <p>No waypoints added</p>
                        <p className="text-xs mt-1">
                          Click waypoints on the map to build your route
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        {routeWaypoints.map((wp, index) => (
                          <div
                            key={wp.id}
                            className="flex items-center gap-2 p-2 rounded-md bg-muted/50 text-sm"
                          >
                            <span className="w-6 text-center text-xs text-muted-foreground">
                              {index + 1}
                            </span>
                            <span className="font-mono font-medium w-16">
                              {wp.identifier}
                            </span>
                            {wp.magneticTrack !== undefined && index > 0 && (
                              <>
                                <ArrowRight className="h-3 w-3 text-muted-foreground" />
                                <span className="text-xs text-muted-foreground">
                                  {wp.magneticTrack}°
                                </span>
                              </>
                            )}
                            {wp.legDistance !== undefined && index > 0 && (
                              <span className="text-xs text-muted-foreground">
                                {wp.legDistance}nm
                              </span>
                            )}
                            {wp.lsalt !== undefined && (
                              <Badge variant="outline" className="text-xs">
                                LSALT {wp.lsalt}
                              </Badge>
                            )}
                            <Button
                              variant="ghost"
                              size="icon"
                              className="ml-auto h-6 w-6"
                              onClick={() => removeWaypoint(wp.id)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={calculateRoute}
                        disabled={routeWaypoints.length < 2}
                      >
                        <Calculator className="mr-2 h-4 w-4" />
                        Calculate Route
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setRouteWaypoints([])}
                        disabled={routeWaypoints.length === 0}
                      >
                        Clear
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Route Summary */}
              {routeWaypoints.length >= 2 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Route Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <p className="text-2xl font-bold">{totalDistance.toFixed(1)}</p>
                        <p className="text-xs text-muted-foreground">Total NM</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold">
                          {cruiseSpeed
                            ? Math.round((totalDistance / parseInt(cruiseSpeed)) * 60)
                            : "--"}
                        </p>
                        <p className="text-xs text-muted-foreground">Est. Time (min)</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold">
                          {Math.max(...routeWaypoints.map((wp) => wp.lsalt || 0)) || "--"}
                        </p>
                        <p className="text-xs text-muted-foreground">Max LSALT</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="fuel" className="m-0 p-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Fuel className="h-4 w-4" />
                    Fuel Planning
                  </CardTitle>
                  <CardDescription>
                    Select an aircraft to calculate fuel requirements
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-muted-foreground">
                    <Fuel className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No aircraft selected</p>
                    <p className="text-sm mt-2">
                      Add an aircraft profile to enable fuel planning
                    </p>
                    <Button variant="outline" className="mt-4">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Aircraft
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="weight" className="m-0 p-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Weight className="h-4 w-4" />
                    Weight & Balance
                  </CardTitle>
                  <CardDescription>
                    Calculate CG and weight limits
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-muted-foreground">
                    <Weight className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No aircraft selected</p>
                    <p className="text-sm mt-2">
                      Add an aircraft profile to calculate weight & balance
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="weather" className="m-0 p-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <Cloud className="h-4 w-4" />
                    Weather Briefing
                  </CardTitle>
                  <CardDescription>
                    METAR, TAF, and area weather
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-muted-foreground">
                    <Cloud className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Enter departure and destination</p>
                    <p className="text-sm mt-2">
                      Weather briefing will be generated for your route
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </ScrollArea>

          {/* Action Buttons */}
          <div className="p-4 border-t border-border space-y-2">
            <Button className="w-full">
              <FileText className="mr-2 h-4 w-4" />
              Generate Flight Plan
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1">
                <Download className="mr-2 h-4 w-4" />
                Export PDF
              </Button>
              <Button variant="outline" className="flex-1">
                Submit to NAIPS
              </Button>
            </div>
          </div>
        </Tabs>
      </div>
    </div>
  )
}
