"use client";

import { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import dynamic from "next/dynamic";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  FileText, 
  Download, 
  Printer, 
  Share2, 
  Plane,
  MapPin,
  Clock,
  Fuel,
  Scale,
  Cloud,
  AlertTriangle,
  CheckCircle2,
  Edit2
} from "lucide-react";
import Link from "next/link";

// Dynamic import for PDF to avoid SSR issues
const PDFDownloadLink = dynamic(
  () => import("@react-pdf/renderer").then((mod) => mod.PDFDownloadLink),
  { ssr: false }
);

const PDFViewer = dynamic(
  () => import("@react-pdf/renderer").then((mod) => mod.PDFViewer),
  { ssr: false }
);

import { OperationalFlightPlan } from "@/components/pdf/operational-flight-plan";

// Mock data for demonstration
const mockFlightPlanData = {
  flightNumber: "PRIVATE",
  date: new Date().toISOString().split("T")[0],
  departure: {
    icao: "YSSY",
    name: "Sydney Kingsford Smith",
    time: "0800",
  },
  destination: {
    icao: "YSCB",
    name: "Canberra",
    time: "0915",
  },
  alternate: {
    icao: "YMML",
    name: "Melbourne Tullamarine",
  },
  flightRules: "VFR" as const,
  flightType: "General Aviation",
  aircraft: {
    registration: "VH-ABC",
    type: "C172",
    model: "Cessna 172S Skyhawk SP",
    equipment: "SDFGORY/S",
    surveillance: "B1",
  },
  pic: "John Smith",
  passengers: 2,
  route: "YSSY DCT RICHMOND DCT KATOOMBA DCT GOULBURN DCT YSCB",
  cruiseAltitude: 7500,
  cruiseSpeed: 110,
  totalDistance: 156,
  totalTime: 75,
  waypoints: [
    { name: "YSSY", type: "AD", altitude: 0, lsalt: 0, track: 0, distance: 0, groundSpeed: 0, ete: 0, eta: "0800", fuel: 0, remarks: "DEP" },
    { name: "RICHMOND", type: "AD", altitude: 4500, lsalt: 3500, track: 285, distance: 28, groundSpeed: 105, ete: 16, eta: "0816", fuel: 3, remarks: "" },
    { name: "KATOOMBA", type: "VRP", altitude: 7500, lsalt: 6500, track: 265, distance: 32, groundSpeed: 108, ete: 18, eta: "0834", fuel: 3, remarks: "TOC" },
    { name: "GOULBURN", type: "AD", altitude: 7500, lsalt: 4500, track: 210, distance: 68, groundSpeed: 112, ete: 36, eta: "0910", fuel: 6, remarks: "" },
    { name: "YSCB", type: "AD", altitude: 1900, lsalt: 0, track: 195, distance: 28, groundSpeed: 110, ete: 15, eta: "0925", fuel: 3, remarks: "ARR" },
  ],
  fuel: {
    taxi: 1,
    trip: 15,
    alternate: 8,
    reserve: 5,
    contingency: 1,
    total: 30,
    endurance: "3:20",
    fuelType: "AVGAS 100LL",
  },
  weightBalance: {
    basicEmpty: { weight: 1670, arm: 39.0, moment: 65130 },
    payload: [
      { name: "Pilot", weight: 180, arm: 37.0, moment: 6660 },
      { name: "Front Passenger", weight: 160, arm: 37.0, moment: 5920 },
      { name: "Rear Passenger", weight: 150, arm: 73.0, moment: 10950 },
      { name: "Baggage", weight: 30, arm: 95.0, moment: 2850 },
    ],
    fuel: { weight: 180, arm: 48.0, moment: 8640 },
    takeoff: { weight: 2370, cg: 42.1, moment: 100150 },
    landing: { weight: 2280, cg: 41.8, moment: 95240 },
    maxTakeoffWeight: 2550,
    maxLandingWeight: 2550,
    isWithinLimits: true,
    cgLimits: { forward: 35.0, aft: 47.3 },
  },
  weather: {
    departure: {
      metar: "YSSY 160700Z 36012KT 9999 FEW040 SCT100 22/12 Q1018",
      taf: "TAF YSSY 160500Z 1606/1712 36010KT 9999 FEW040 SCT100 FM161000 02015G25KT 9999 SCT030",
    },
    destination: {
      metar: "YSCB 160700Z 18008KT 9999 SCT045 BKN100 18/08 Q1020",
      taf: "TAF YSCB 160500Z 1606/1706 18010KT 9999 SCT040 BKN100",
    },
    alternate: {
      metar: "YMML 160700Z 27015G22KT 9999 FEW030 SCT050 19/10 Q1015",
    },
    enroute: "Area QNH 1018, Wind at 7500ft 320/15, Turbulence NIL, Icing NIL",
  },
  notams: [
    "A1234/26 YSSY RWY 16R/34L CLOSED 0600-0800 DAILY",
    "A1235/26 YSCB AD NOISE ABATEMENT PROCEDURES IN EFFECT",
  ],
  remarks: "Student pilot training flight with instructor. Contact Sydney Approach on 124.4",
  generatedAt: new Date().toISOString(),
  generatedBy: "FlightPlan Pro",
};

export default function FlightPlanDetailPage() {
  const params = useParams();
  const [isClient, setIsClient] = useState(false);
  const [flightPlan, setFlightPlan] = useState(mockFlightPlanData);
  const [showPdfViewer, setShowPdfViewer] = useState(false);

  useEffect(() => {
    setIsClient(true);
    // In production, fetch the actual flight plan from the API
    // fetchFlightPlan(params.id);
  }, [params.id]);

  if (!isClient) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <Plane className="h-12 w-12 mx-auto mb-4 animate-pulse text-primary" />
          <p className="text-muted-foreground">Loading flight plan...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border bg-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-lg">
              <FileText className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-semibold flex items-center gap-2">
                {flightPlan.departure.icao} - {flightPlan.destination.icao}
                <Badge variant={flightPlan.flightRules === "IFR" ? "default" : "secondary"}>
                  {flightPlan.flightRules}
                </Badge>
              </h1>
              <p className="text-sm text-muted-foreground">
                {flightPlan.aircraft.registration} | {flightPlan.date} | {flightPlan.departure.time}Z
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link href={`/dashboard/plan?edit=${params.id}`}>
              <Button variant="outline" size="sm">
                <Edit2 className="h-4 w-4 mr-2" />
                Edit
              </Button>
            </Link>
            <Button variant="outline" size="sm" onClick={() => setShowPdfViewer(!showPdfViewer)}>
              <Printer className="h-4 w-4 mr-2" />
              Preview PDF
            </Button>
            {isClient && (
              <PDFDownloadLink
                document={<OperationalFlightPlan data={flightPlan} />}
                fileName={`OFP_${flightPlan.departure.icao}_${flightPlan.destination.icao}_${flightPlan.date}.pdf`}
              >
                {({ loading }) => (
                  <Button disabled={loading}>
                    <Download className="h-4 w-4 mr-2" />
                    {loading ? "Generating..." : "Download PDF"}
                  </Button>
                )}
              </PDFDownloadLink>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {showPdfViewer ? (
          <div className="h-[calc(100vh-200px)] border rounded-lg overflow-hidden">
            <PDFViewer width="100%" height="100%">
              <OperationalFlightPlan data={flightPlan} />
            </PDFViewer>
          </div>
        ) : (
          <Tabs defaultValue="summary" className="space-y-4">
            <TabsList>
              <TabsTrigger value="summary">Summary</TabsTrigger>
              <TabsTrigger value="navlog">Nav Log</TabsTrigger>
              <TabsTrigger value="fuel">Fuel</TabsTrigger>
              <TabsTrigger value="wb">Weight & Balance</TabsTrigger>
              <TabsTrigger value="weather">Weather</TabsTrigger>
            </TabsList>

            <TabsContent value="summary" className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                {/* Flight Info */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Plane className="h-4 w-4" />
                      Flight Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Aircraft</span>
                      <span>{flightPlan.aircraft.registration}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Type</span>
                      <span>{flightPlan.aircraft.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">PIC</span>
                      <span>{flightPlan.pic}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">POB</span>
                      <span>{flightPlan.passengers + 1}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Cruise Alt</span>
                      <span>{flightPlan.cruiseAltitude} ft</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Cruise Speed</span>
                      <span>{flightPlan.cruiseSpeed} kts</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Route */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      Route
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Departure</span>
                      <span>{flightPlan.departure.icao} @ {flightPlan.departure.time}Z</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Destination</span>
                      <span>{flightPlan.destination.icao} @ {flightPlan.destination.time}Z</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Alternate</span>
                      <span>{flightPlan.alternate?.icao || "NIL"}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Distance</span>
                      <span>{flightPlan.totalDistance} NM</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Time</span>
                      <span>{Math.floor(flightPlan.totalTime / 60)}:{(flightPlan.totalTime % 60).toString().padStart(2, "0")}</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Status */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4" />
                      Status
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Weight & Balance</span>
                      {flightPlan.weightBalance.isWithinLimits ? (
                        <Badge variant="secondary" className="bg-green-500/20 text-green-500">OK</Badge>
                      ) : (
                        <Badge variant="destructive">OVER</Badge>
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Fuel</span>
                      <Badge variant="secondary" className="bg-green-500/20 text-green-500">OK</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Weather</span>
                      <Badge variant="secondary" className="bg-green-500/20 text-green-500">VFR</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">NOTAMs</span>
                      <Badge variant="secondary">{flightPlan.notams?.length || 0}</Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Route String */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Route</CardTitle>
                </CardHeader>
                <CardContent>
                  <code className="text-sm font-mono bg-muted p-2 rounded block">
                    {flightPlan.route}
                  </code>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="navlog">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Navigation Log</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-muted/50">
                          <th className="text-left p-2">Waypoint</th>
                          <th className="text-right p-2">Alt</th>
                          <th className="text-right p-2">LSALT</th>
                          <th className="text-right p-2">Track</th>
                          <th className="text-right p-2">Dist</th>
                          <th className="text-right p-2">GS</th>
                          <th className="text-right p-2">ETE</th>
                          <th className="text-right p-2">ETA</th>
                          <th className="text-right p-2">Fuel</th>
                          <th className="text-left p-2">Remarks</th>
                        </tr>
                      </thead>
                      <tbody>
                        {flightPlan.waypoints.map((wp, idx) => (
                          <tr key={idx} className="border-b">
                            <td className="p-2 font-medium">{wp.name}</td>
                            <td className="text-right p-2">{wp.altitude}</td>
                            <td className={`text-right p-2 ${wp.altitude < wp.lsalt ? "text-destructive font-bold" : ""}`}>
                              {wp.lsalt}
                            </td>
                            <td className="text-right p-2">{wp.track.toString().padStart(3, "0")}°</td>
                            <td className="text-right p-2">{wp.distance}</td>
                            <td className="text-right p-2">{wp.groundSpeed}</td>
                            <td className="text-right p-2">{wp.ete}</td>
                            <td className="text-right p-2">{wp.eta}</td>
                            <td className="text-right p-2">{wp.fuel}</td>
                            <td className="p-2 text-muted-foreground">{wp.remarks}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="fuel">
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Fuel className="h-4 w-4" />
                      Fuel Requirements
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between py-1">
                      <span>Taxi Fuel</span>
                      <span>{flightPlan.fuel.taxi} gal</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>Trip Fuel</span>
                      <span>{flightPlan.fuel.trip} gal</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>Contingency (5%)</span>
                      <span>{flightPlan.fuel.contingency} gal</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>Alternate</span>
                      <span>{flightPlan.fuel.alternate} gal</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>Reserve ({flightPlan.flightRules === "IFR" ? "45" : "30"} min)</span>
                      <span>{flightPlan.fuel.reserve} gal</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between py-1 font-bold">
                      <span>TOTAL REQUIRED</span>
                      <span>{flightPlan.fuel.total} gal</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Fuel Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between py-1">
                      <span>Fuel Type</span>
                      <span>{flightPlan.fuel.fuelType}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>Endurance</span>
                      <span>{flightPlan.fuel.endurance}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="wb">
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Scale className="h-4 w-4" />
                      Loading Manifest
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b bg-muted/50">
                          <th className="text-left p-2">Item</th>
                          <th className="text-right p-2">Weight</th>
                          <th className="text-right p-2">Arm</th>
                          <th className="text-right p-2">Moment</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b">
                          <td className="p-2">Basic Empty</td>
                          <td className="text-right p-2">{flightPlan.weightBalance.basicEmpty.weight}</td>
                          <td className="text-right p-2">{flightPlan.weightBalance.basicEmpty.arm}</td>
                          <td className="text-right p-2">{flightPlan.weightBalance.basicEmpty.moment}</td>
                        </tr>
                        {flightPlan.weightBalance.payload.map((item, idx) => (
                          <tr key={idx} className="border-b">
                            <td className="p-2">{item.name}</td>
                            <td className="text-right p-2">{item.weight}</td>
                            <td className="text-right p-2">{item.arm}</td>
                            <td className="text-right p-2">{item.moment}</td>
                          </tr>
                        ))}
                        <tr className="border-b">
                          <td className="p-2">Fuel</td>
                          <td className="text-right p-2">{flightPlan.weightBalance.fuel.weight}</td>
                          <td className="text-right p-2">{flightPlan.weightBalance.fuel.arm}</td>
                          <td className="text-right p-2">{flightPlan.weightBalance.fuel.moment}</td>
                        </tr>
                        <tr className="bg-muted/50 font-bold">
                          <td className="p-2">Takeoff</td>
                          <td className="text-right p-2">{flightPlan.weightBalance.takeoff.weight}</td>
                          <td className="text-right p-2">{flightPlan.weightBalance.takeoff.cg}</td>
                          <td className="text-right p-2">{flightPlan.weightBalance.takeoff.moment}</td>
                        </tr>
                      </tbody>
                    </table>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Limits Check</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Max Takeoff Weight</span>
                      <div className="text-right">
                        <div>{flightPlan.weightBalance.maxTakeoffWeight} lbs</div>
                        <div className={`text-sm ${
                          flightPlan.weightBalance.takeoff.weight <= flightPlan.weightBalance.maxTakeoffWeight
                            ? "text-green-500"
                            : "text-destructive"
                        }`}>
                          Margin: {flightPlan.weightBalance.maxTakeoffWeight - flightPlan.weightBalance.takeoff.weight} lbs
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>CG Limits</span>
                      <div className="text-right">
                        <div>{flightPlan.weightBalance.cgLimits.forward} - {flightPlan.weightBalance.cgLimits.aft} in</div>
                        <div className="text-sm text-green-500">
                          Actual: {flightPlan.weightBalance.takeoff.cg} in
                        </div>
                      </div>
                    </div>
                    <Separator />
                    <div className="flex items-center gap-2">
                      {flightPlan.weightBalance.isWithinLimits ? (
                        <>
                          <CheckCircle2 className="h-5 w-5 text-green-500" />
                          <span className="text-green-500 font-medium">Within Limits</span>
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="h-5 w-5 text-destructive" />
                          <span className="text-destructive font-medium">Outside Limits</span>
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="weather">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Cloud className="h-4 w-4" />
                      Departure - {flightPlan.departure.icao}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">METAR</div>
                      <code className="text-sm font-mono bg-muted p-2 rounded block">
                        {flightPlan.weather.departure?.metar}
                      </code>
                    </div>
                    {flightPlan.weather.departure?.taf && (
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">TAF</div>
                        <code className="text-sm font-mono bg-muted p-2 rounded block">
                          {flightPlan.weather.departure.taf}
                        </code>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Cloud className="h-4 w-4" />
                      Destination - {flightPlan.destination.icao}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">METAR</div>
                      <code className="text-sm font-mono bg-muted p-2 rounded block">
                        {flightPlan.weather.destination?.metar}
                      </code>
                    </div>
                    {flightPlan.weather.destination?.taf && (
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">TAF</div>
                        <code className="text-sm font-mono bg-muted p-2 rounded block">
                          {flightPlan.weather.destination.taf}
                        </code>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {flightPlan.notams && flightPlan.notams.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4" />
                        NOTAMs
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {flightPlan.notams.map((notam, idx) => (
                        <code key={idx} className="text-sm font-mono bg-muted p-2 rounded block">
                          {notam}
                        </code>
                      ))}
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}
