"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plane, Plus, Edit2, Trash2, Copy, Settings, Fuel, Scale, AlertCircle } from "lucide-react";
import { WeightBalanceCalculator } from "@/components/aircraft/weight-balance-calculator";
import { useAuth } from "@/components/providers/auth-provider";

interface AircraftProfile {
  id: string;
  registration: string;
  type: string;
  model: string;
  category: string;
  isBaseProfile: boolean;
  ownerId?: string;
  performance: {
    cruiseSpeedKts: number;
    fuelBurnGph: number;
    climbRateFpm: number;
    descentRateFpm: number;
    serviceCeiling: number;
    takeoffDistance: number;
    landingDistance: number;
    vSpeeds: {
      vne: number;
      vno: number;
      va: number;
      vfe: number;
      vs0: number;
      vs1: number;
      vx: number;
      vy: number;
      vr: number;
      vref: number;
    };
  };
  weights: {
    emptyWeight: number;
    maxTakeoffWeight: number;
    maxLandingWeight: number;
    maxRampWeight: number;
    maxZeroFuelWeight: number;
    usefulLoad: number;
    maxFuelCapacity: number;
    fuelType: string;
  };
  weightBalance: {
    basicEmptyWeight: number;
    basicEmptyArm: number;
    basicEmptyMoment: number;
    stations: Array<{
      name: string;
      arm: number;
      minWeight: number;
      maxWeight: number;
    }>;
    fuelStations: Array<{
      name: string;
      arm: number;
      capacity: number;
      unusable: number;
    }>;
    envelope: Array<{
      weight: number;
      fwdCG: number;
      aftCG: number;
    }>;
  };
  equipment: {
    icaoEquipment: string;
    surveillanceEquipment: string;
    emergencyEquipment: string;
    remarks: string;
  };
}

const defaultAircraftProfile: Partial<AircraftProfile> = {
  registration: "",
  type: "",
  model: "",
  category: "A",
  performance: {
    cruiseSpeedKts: 120,
    fuelBurnGph: 10,
    climbRateFpm: 700,
    descentRateFpm: 500,
    serviceCeiling: 14000,
    takeoffDistance: 1500,
    landingDistance: 1200,
    vSpeeds: {
      vne: 160,
      vno: 128,
      va: 99,
      vfe: 85,
      vs0: 45,
      vs1: 50,
      vx: 63,
      vy: 76,
      vr: 55,
      vref: 65,
    },
  },
  weights: {
    emptyWeight: 1670,
    maxTakeoffWeight: 2550,
    maxLandingWeight: 2550,
    maxRampWeight: 2558,
    maxZeroFuelWeight: 2550,
    usefulLoad: 880,
    maxFuelCapacity: 56,
    fuelType: "AVGAS",
  },
  weightBalance: {
    basicEmptyWeight: 1670,
    basicEmptyArm: 39.0,
    basicEmptyMoment: 65130,
    stations: [
      { name: "Pilot & Front Passenger", arm: 37.0, minWeight: 0, maxWeight: 400 },
      { name: "Rear Passengers", arm: 73.0, minWeight: 0, maxWeight: 400 },
      { name: "Baggage Area 1", arm: 95.0, minWeight: 0, maxWeight: 120 },
      { name: "Baggage Area 2", arm: 123.0, minWeight: 0, maxWeight: 50 },
    ],
    fuelStations: [
      { name: "Main Tanks", arm: 48.0, capacity: 56, unusable: 1.5 },
    ],
    envelope: [
      { weight: 1500, fwdCG: 35.0, aftCG: 47.3 },
      { weight: 1950, fwdCG: 35.0, aftCG: 47.3 },
      { weight: 2550, fwdCG: 35.0, aftCG: 47.3 },
    ],
  },
  equipment: {
    icaoEquipment: "SDFGORY/S",
    surveillanceEquipment: "B1",
    emergencyEquipment: "S/ELT",
    remarks: "",
  },
};

export default function AircraftPage() {
  const { user } = useAuth();
  const [aircraft, setAircraft] = useState<AircraftProfile[]>([]);
  const [selectedAircraft, setSelectedAircraft] = useState<AircraftProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState<Partial<AircraftProfile>>(defaultAircraftProfile);
  const [activeTab, setActiveTab] = useState("general");

  useEffect(() => {
    fetchAircraft();
  }, []);

  async function fetchAircraft() {
    try {
      const res = await fetch("/api/aircraft");
      const data = await res.json();
      setAircraft(data.aircraft || []);
    } catch (error) {
      console.error("Failed to fetch aircraft:", error);
    } finally {
      setIsLoading(false);
    }
  }

  async function handleSave() {
    try {
      const url = editMode ? `/api/aircraft/${selectedAircraft?.id}` : "/api/aircraft";
      const method = editMode ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        fetchAircraft();
        setIsDialogOpen(false);
        resetForm();
      }
    } catch (error) {
      console.error("Failed to save aircraft:", error);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm("Are you sure you want to delete this aircraft?")) return;
    
    try {
      const res = await fetch(`/api/aircraft/${id}`, { method: "DELETE" });
      if (res.ok) {
        fetchAircraft();
        if (selectedAircraft?.id === id) {
          setSelectedAircraft(null);
        }
      }
    } catch (error) {
      console.error("Failed to delete aircraft:", error);
    }
  }

  async function handleDuplicate(profile: AircraftProfile) {
    const newProfile = {
      ...profile,
      id: undefined,
      registration: `${profile.registration}-COPY`,
      isBaseProfile: false,
    };
    setFormData(newProfile);
    setEditMode(false);
    setIsDialogOpen(true);
  }

  function resetForm() {
    setFormData(defaultAircraftProfile);
    setEditMode(false);
  }

  function openEditDialog(profile: AircraftProfile) {
    setFormData(profile);
    setEditMode(true);
    setIsDialogOpen(true);
  }

  function updateFormData(path: string, value: unknown) {
    setFormData((prev) => {
      const newData = { ...prev };
      const keys = path.split(".");
      let current: Record<string, unknown> = newData;
      
      for (let i = 0; i < keys.length - 1; i++) {
        if (!current[keys[i]]) {
          current[keys[i]] = {};
        }
        current = current[keys[i]] as Record<string, unknown>;
      }
      
      current[keys[keys.length - 1]] = value;
      return newData;
    });
  }

  return (
    <div className="flex h-full">
      {/* Aircraft List Sidebar */}
      <div className="w-80 border-r border-border bg-card flex flex-col">
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-lg">Aircraft</h2>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" onClick={resetForm}>
                  <Plus className="h-4 w-4 mr-1" />
                  New
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editMode ? "Edit Aircraft" : "New Aircraft Profile"}</DialogTitle>
                  <DialogDescription>
                    {editMode ? "Update aircraft profile details" : "Create a new aircraft profile"}
                  </DialogDescription>
                </DialogHeader>
                
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-5">
                    <TabsTrigger value="general">General</TabsTrigger>
                    <TabsTrigger value="performance">Performance</TabsTrigger>
                    <TabsTrigger value="weights">Weights</TabsTrigger>
                    <TabsTrigger value="wb">W&B</TabsTrigger>
                    <TabsTrigger value="equipment">Equipment</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="general" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="registration">Registration</Label>
                        <Input
                          id="registration"
                          value={formData.registration || ""}
                          onChange={(e) => updateFormData("registration", e.target.value.toUpperCase())}
                          placeholder="VH-XXX"
                        />
                      </div>
                      <div>
                        <Label htmlFor="type">ICAO Type</Label>
                        <Input
                          id="type"
                          value={formData.type || ""}
                          onChange={(e) => updateFormData("type", e.target.value.toUpperCase())}
                          placeholder="C172"
                        />
                      </div>
                      <div>
                        <Label htmlFor="model">Model</Label>
                        <Input
                          id="model"
                          value={formData.model || ""}
                          onChange={(e) => updateFormData("model", e.target.value)}
                          placeholder="Cessna 172S Skyhawk SP"
                        />
                      </div>
                      <div>
                        <Label htmlFor="category">Category</Label>
                        <Select 
                          value={formData.category || "A"} 
                          onValueChange={(v) => updateFormData("category", v)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="A">Category A (Approach speed &lt; 91 kts)</SelectItem>
                            <SelectItem value="B">Category B (91 - 120 kts)</SelectItem>
                            <SelectItem value="C">Category C (121 - 140 kts)</SelectItem>
                            <SelectItem value="D">Category D (141 - 165 kts)</SelectItem>
                            <SelectItem value="E">Category E (&gt; 166 kts)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    {user?.role === "admin" && (
                      <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                        <input
                          type="checkbox"
                          id="isBaseProfile"
                          checked={formData.isBaseProfile || false}
                          onChange={(e) => updateFormData("isBaseProfile", e.target.checked)}
                          className="rounded"
                        />
                        <Label htmlFor="isBaseProfile" className="text-sm cursor-pointer">
                          Base Profile (available to all users)
                        </Label>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="performance" className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label>Cruise Speed (kts)</Label>
                        <Input
                          type="number"
                          value={formData.performance?.cruiseSpeedKts || ""}
                          onChange={(e) => updateFormData("performance.cruiseSpeedKts", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Fuel Burn (GPH)</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={formData.performance?.fuelBurnGph || ""}
                          onChange={(e) => updateFormData("performance.fuelBurnGph", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Climb Rate (FPM)</Label>
                        <Input
                          type="number"
                          value={formData.performance?.climbRateFpm || ""}
                          onChange={(e) => updateFormData("performance.climbRateFpm", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Descent Rate (FPM)</Label>
                        <Input
                          type="number"
                          value={formData.performance?.descentRateFpm || ""}
                          onChange={(e) => updateFormData("performance.descentRateFpm", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Service Ceiling (ft)</Label>
                        <Input
                          type="number"
                          value={formData.performance?.serviceCeiling || ""}
                          onChange={(e) => updateFormData("performance.serviceCeiling", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Takeoff Distance (ft)</Label>
                        <Input
                          type="number"
                          value={formData.performance?.takeoffDistance || ""}
                          onChange={(e) => updateFormData("performance.takeoffDistance", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Landing Distance (ft)</Label>
                        <Input
                          type="number"
                          value={formData.performance?.landingDistance || ""}
                          onChange={(e) => updateFormData("performance.landingDistance", Number(e.target.value))}
                        />
                      </div>
                    </div>
                    
                    <div className="border-t pt-4">
                      <h4 className="font-medium mb-3">V-Speeds (kts)</h4>
                      <div className="grid grid-cols-5 gap-3">
                        {Object.entries(formData.performance?.vSpeeds || {}).map(([key, value]) => (
                          <div key={key}>
                            <Label className="text-xs uppercase">{key}</Label>
                            <Input
                              type="number"
                              value={value || ""}
                              onChange={(e) => updateFormData(`performance.vSpeeds.${key}`, Number(e.target.value))}
                              className="h-8"
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="weights" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Empty Weight (lbs)</Label>
                        <Input
                          type="number"
                          value={formData.weights?.emptyWeight || ""}
                          onChange={(e) => updateFormData("weights.emptyWeight", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Max Takeoff Weight (lbs)</Label>
                        <Input
                          type="number"
                          value={formData.weights?.maxTakeoffWeight || ""}
                          onChange={(e) => updateFormData("weights.maxTakeoffWeight", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Max Landing Weight (lbs)</Label>
                        <Input
                          type="number"
                          value={formData.weights?.maxLandingWeight || ""}
                          onChange={(e) => updateFormData("weights.maxLandingWeight", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Max Ramp Weight (lbs)</Label>
                        <Input
                          type="number"
                          value={formData.weights?.maxRampWeight || ""}
                          onChange={(e) => updateFormData("weights.maxRampWeight", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Max Zero Fuel Weight (lbs)</Label>
                        <Input
                          type="number"
                          value={formData.weights?.maxZeroFuelWeight || ""}
                          onChange={(e) => updateFormData("weights.maxZeroFuelWeight", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Useful Load (lbs)</Label>
                        <Input
                          type="number"
                          value={formData.weights?.usefulLoad || ""}
                          onChange={(e) => updateFormData("weights.usefulLoad", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Max Fuel Capacity (gal)</Label>
                        <Input
                          type="number"
                          value={formData.weights?.maxFuelCapacity || ""}
                          onChange={(e) => updateFormData("weights.maxFuelCapacity", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Fuel Type</Label>
                        <Select 
                          value={formData.weights?.fuelType || "AVGAS"}
                          onValueChange={(v) => updateFormData("weights.fuelType", v)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="AVGAS">AVGAS (100LL)</SelectItem>
                            <SelectItem value="JETA1">JET A-1</SelectItem>
                            <SelectItem value="MOGAS">MOGAS</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="wb" className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label>Basic Empty Weight (lbs)</Label>
                        <Input
                          type="number"
                          value={formData.weightBalance?.basicEmptyWeight || ""}
                          onChange={(e) => updateFormData("weightBalance.basicEmptyWeight", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Basic Empty Arm (in)</Label>
                        <Input
                          type="number"
                          step="0.01"
                          value={formData.weightBalance?.basicEmptyArm || ""}
                          onChange={(e) => updateFormData("weightBalance.basicEmptyArm", Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Basic Empty Moment (lb-in)</Label>
                        <Input
                          type="number"
                          value={formData.weightBalance?.basicEmptyMoment || ""}
                          onChange={(e) => updateFormData("weightBalance.basicEmptyMoment", Number(e.target.value))}
                        />
                      </div>
                    </div>
                    
                    <div className="border-t pt-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium">Loading Stations</h4>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const stations = [...(formData.weightBalance?.stations || [])];
                            stations.push({ name: "New Station", arm: 0, minWeight: 0, maxWeight: 200 });
                            updateFormData("weightBalance.stations", stations);
                          }}
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          Add Station
                        </Button>
                      </div>
                      <div className="space-y-2">
                        {formData.weightBalance?.stations?.map((station, idx) => (
                          <div key={idx} className="grid grid-cols-5 gap-2 items-end">
                            <div>
                              <Label className="text-xs">Name</Label>
                              <Input
                                value={station.name}
                                onChange={(e) => {
                                  const stations = [...(formData.weightBalance?.stations || [])];
                                  stations[idx].name = e.target.value;
                                  updateFormData("weightBalance.stations", stations);
                                }}
                                className="h-8"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Arm (in)</Label>
                              <Input
                                type="number"
                                step="0.1"
                                value={station.arm}
                                onChange={(e) => {
                                  const stations = [...(formData.weightBalance?.stations || [])];
                                  stations[idx].arm = Number(e.target.value);
                                  updateFormData("weightBalance.stations", stations);
                                }}
                                className="h-8"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Min (lbs)</Label>
                              <Input
                                type="number"
                                value={station.minWeight}
                                onChange={(e) => {
                                  const stations = [...(formData.weightBalance?.stations || [])];
                                  stations[idx].minWeight = Number(e.target.value);
                                  updateFormData("weightBalance.stations", stations);
                                }}
                                className="h-8"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Max (lbs)</Label>
                              <Input
                                type="number"
                                value={station.maxWeight}
                                onChange={(e) => {
                                  const stations = [...(formData.weightBalance?.stations || [])];
                                  stations[idx].maxWeight = Number(e.target.value);
                                  updateFormData("weightBalance.stations", stations);
                                }}
                                className="h-8"
                              />
                            </div>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8"
                              onClick={() => {
                                const stations = formData.weightBalance?.stations?.filter((_, i) => i !== idx);
                                updateFormData("weightBalance.stations", stations);
                              }}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="border-t pt-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium">Fuel Stations</h4>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const fuelStations = [...(formData.weightBalance?.fuelStations || [])];
                            fuelStations.push({ name: "Aux Tank", arm: 0, capacity: 20, unusable: 0.5 });
                            updateFormData("weightBalance.fuelStations", fuelStations);
                          }}
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          Add Tank
                        </Button>
                      </div>
                      <div className="space-y-2">
                        {formData.weightBalance?.fuelStations?.map((tank, idx) => (
                          <div key={idx} className="grid grid-cols-5 gap-2 items-end">
                            <div>
                              <Label className="text-xs">Name</Label>
                              <Input
                                value={tank.name}
                                onChange={(e) => {
                                  const fuelStations = [...(formData.weightBalance?.fuelStations || [])];
                                  fuelStations[idx].name = e.target.value;
                                  updateFormData("weightBalance.fuelStations", fuelStations);
                                }}
                                className="h-8"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Arm (in)</Label>
                              <Input
                                type="number"
                                step="0.1"
                                value={tank.arm}
                                onChange={(e) => {
                                  const fuelStations = [...(formData.weightBalance?.fuelStations || [])];
                                  fuelStations[idx].arm = Number(e.target.value);
                                  updateFormData("weightBalance.fuelStations", fuelStations);
                                }}
                                className="h-8"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Capacity (gal)</Label>
                              <Input
                                type="number"
                                value={tank.capacity}
                                onChange={(e) => {
                                  const fuelStations = [...(formData.weightBalance?.fuelStations || [])];
                                  fuelStations[idx].capacity = Number(e.target.value);
                                  updateFormData("weightBalance.fuelStations", fuelStations);
                                }}
                                className="h-8"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Unusable (gal)</Label>
                              <Input
                                type="number"
                                step="0.1"
                                value={tank.unusable}
                                onChange={(e) => {
                                  const fuelStations = [...(formData.weightBalance?.fuelStations || [])];
                                  fuelStations[idx].unusable = Number(e.target.value);
                                  updateFormData("weightBalance.fuelStations", fuelStations);
                                }}
                                className="h-8"
                              />
                            </div>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8"
                              onClick={() => {
                                const fuelStations = formData.weightBalance?.fuelStations?.filter((_, i) => i !== idx);
                                updateFormData("weightBalance.fuelStations", fuelStations);
                              }}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="border-t pt-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium">CG Envelope</h4>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const envelope = [...(formData.weightBalance?.envelope || [])];
                            envelope.push({ weight: 2000, fwdCG: 35, aftCG: 47 });
                            updateFormData("weightBalance.envelope", envelope);
                          }}
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          Add Point
                        </Button>
                      </div>
                      <div className="space-y-2">
                        {formData.weightBalance?.envelope?.map((point, idx) => (
                          <div key={idx} className="grid grid-cols-4 gap-2 items-end">
                            <div>
                              <Label className="text-xs">Weight (lbs)</Label>
                              <Input
                                type="number"
                                value={point.weight}
                                onChange={(e) => {
                                  const envelope = [...(formData.weightBalance?.envelope || [])];
                                  envelope[idx].weight = Number(e.target.value);
                                  updateFormData("weightBalance.envelope", envelope);
                                }}
                                className="h-8"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Fwd CG (in)</Label>
                              <Input
                                type="number"
                                step="0.1"
                                value={point.fwdCG}
                                onChange={(e) => {
                                  const envelope = [...(formData.weightBalance?.envelope || [])];
                                  envelope[idx].fwdCG = Number(e.target.value);
                                  updateFormData("weightBalance.envelope", envelope);
                                }}
                                className="h-8"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Aft CG (in)</Label>
                              <Input
                                type="number"
                                step="0.1"
                                value={point.aftCG}
                                onChange={(e) => {
                                  const envelope = [...(formData.weightBalance?.envelope || [])];
                                  envelope[idx].aftCG = Number(e.target.value);
                                  updateFormData("weightBalance.envelope", envelope);
                                }}
                                className="h-8"
                              />
                            </div>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-8"
                              onClick={() => {
                                const envelope = formData.weightBalance?.envelope?.filter((_, i) => i !== idx);
                                updateFormData("weightBalance.envelope", envelope);
                              }}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="equipment" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>ICAO Equipment Codes</Label>
                        <Input
                          value={formData.equipment?.icaoEquipment || ""}
                          onChange={(e) => updateFormData("equipment.icaoEquipment", e.target.value.toUpperCase())}
                          placeholder="SDFGORY/S"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          e.g., S=Standard, D=DME, F=ADF, G=GNSS, O=VOR, R=RNP, Y=8.33 kHz
                        </p>
                      </div>
                      <div>
                        <Label>Surveillance Equipment</Label>
                        <Input
                          value={formData.equipment?.surveillanceEquipment || ""}
                          onChange={(e) => updateFormData("equipment.surveillanceEquipment", e.target.value.toUpperCase())}
                          placeholder="B1"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          e.g., N=None, A=Mode A, C=Mode C, S=Mode S, B1=ADS-B Out 1090
                        </p>
                      </div>
                      <div>
                        <Label>Emergency Equipment</Label>
                        <Input
                          value={formData.equipment?.emergencyEquipment || ""}
                          onChange={(e) => updateFormData("equipment.emergencyEquipment", e.target.value.toUpperCase())}
                          placeholder="S/ELT"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Remarks</Label>
                      <textarea
                        className="w-full min-h-[100px] rounded-md border border-input bg-background px-3 py-2 text-sm"
                        value={formData.equipment?.remarks || ""}
                        onChange={(e) => updateFormData("equipment.remarks", e.target.value)}
                        placeholder="Additional equipment, special certifications, etc."
                      />
                    </div>
                  </TabsContent>
                </Tabs>
                
                <div className="flex justify-end gap-2 mt-4">
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleSave}>
                    {editMode ? "Update" : "Create"} Aircraft
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto">
          {isLoading ? (
            <div className="p-4 text-center text-muted-foreground">Loading...</div>
          ) : aircraft.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground">
              <Plane className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No aircraft profiles yet</p>
              <p className="text-sm">Create your first aircraft</p>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {aircraft.map((ac) => (
                <div
                  key={ac.id}
                  className={`p-3 cursor-pointer hover:bg-muted/50 transition-colors ${
                    selectedAircraft?.id === ac.id ? "bg-muted" : ""
                  }`}
                  onClick={() => setSelectedAircraft(ac)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Plane className="h-4 w-4 text-primary" />
                      <span className="font-medium">{ac.registration}</span>
                    </div>
                    {ac.isBaseProfile && (
                      <Badge variant="secondary" className="text-xs">Base</Badge>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    {ac.model || ac.type}
                  </div>
                  <div className="flex gap-4 text-xs text-muted-foreground mt-1">
                    <span>{ac.performance?.cruiseSpeedKts} kts</span>
                    <span>{ac.performance?.fuelBurnGph} GPH</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Aircraft Details */}
      <div className="flex-1 overflow-y-auto">
        {selectedAircraft ? (
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <div className="flex items-center gap-3">
                  <h1 className="text-2xl font-bold">{selectedAircraft.registration}</h1>
                  {selectedAircraft.isBaseProfile && (
                    <Badge>Base Profile</Badge>
                  )}
                </div>
                <p className="text-muted-foreground">{selectedAircraft.model}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => handleDuplicate(selectedAircraft)}>
                  <Copy className="h-4 w-4 mr-1" />
                  Duplicate
                </Button>
                {(!selectedAircraft.isBaseProfile || user?.role === "admin") && (
                  <>
                    <Button variant="outline" size="sm" onClick={() => openEditDialog(selectedAircraft)}>
                      <Edit2 className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleDelete(selectedAircraft.id)}>
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </>
                )}
              </div>
            </div>
            
            <Tabs defaultValue="overview">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="wb">Weight & Balance</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-6">
                <div className="grid grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Settings className="h-4 w-4" />
                        Performance
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Cruise Speed</span>
                        <span>{selectedAircraft.performance?.cruiseSpeedKts} kts</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Climb Rate</span>
                        <span>{selectedAircraft.performance?.climbRateFpm} FPM</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Service Ceiling</span>
                        <span>{selectedAircraft.performance?.serviceCeiling?.toLocaleString()} ft</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Takeoff Distance</span>
                        <span>{selectedAircraft.performance?.takeoffDistance} ft</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Landing Distance</span>
                        <span>{selectedAircraft.performance?.landingDistance} ft</span>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Fuel className="h-4 w-4" />
                        Fuel
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Fuel Burn</span>
                        <span>{selectedAircraft.performance?.fuelBurnGph} GPH</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Max Capacity</span>
                        <span>{selectedAircraft.weights?.maxFuelCapacity} gal</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Fuel Type</span>
                        <span>{selectedAircraft.weights?.fuelType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Endurance (max fuel)</span>
                        <span>
                          {((selectedAircraft.weights?.maxFuelCapacity || 0) / (selectedAircraft.performance?.fuelBurnGph || 1)).toFixed(1)} hrs
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Scale className="h-4 w-4" />
                        Weights
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Empty Weight</span>
                        <span>{selectedAircraft.weights?.emptyWeight?.toLocaleString()} lbs</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Max Takeoff</span>
                        <span>{selectedAircraft.weights?.maxTakeoffWeight?.toLocaleString()} lbs</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Max Landing</span>
                        <span>{selectedAircraft.weights?.maxLandingWeight?.toLocaleString()} lbs</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Useful Load</span>
                        <span>{selectedAircraft.weights?.usefulLoad?.toLocaleString()} lbs</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">V-Speeds</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-5 gap-4">
                      {Object.entries(selectedAircraft.performance?.vSpeeds || {}).map(([key, value]) => (
                        <div key={key} className="text-center p-3 bg-muted rounded-lg">
                          <div className="text-xs text-muted-foreground uppercase">{key}</div>
                          <div className="text-lg font-semibold">{value}</div>
                          <div className="text-xs text-muted-foreground">kts</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Equipment Codes</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">ICAO Equipment</span>
                      <code className="bg-muted px-2 py-1 rounded">{selectedAircraft.equipment?.icaoEquipment}</code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Surveillance</span>
                      <code className="bg-muted px-2 py-1 rounded">{selectedAircraft.equipment?.surveillanceEquipment}</code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Emergency</span>
                      <code className="bg-muted px-2 py-1 rounded">{selectedAircraft.equipment?.emergencyEquipment}</code>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="wb">
                <WeightBalanceCalculator aircraft={selectedAircraft} />
              </TabsContent>
            </Tabs>
          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <Plane className="h-16 w-16 mx-auto mb-4 opacity-30" />
              <p>Select an aircraft to view details</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
