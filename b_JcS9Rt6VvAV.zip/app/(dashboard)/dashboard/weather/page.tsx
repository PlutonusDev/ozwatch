"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Cloud, 
  Wind, 
  Thermometer, 
  Eye, 
  Droplets,
  AlertTriangle,
  RefreshCw,
  Search,
  MapPin,
  Clock,
  ArrowUp,
  Gauge,
  Info
} from "lucide-react";
import { WeatherDisplay } from "@/components/weather/weather-display";
import { WeatherMap } from "@/components/weather/weather-map";

interface DecodedWeather {
  raw: string;
  type: "METAR" | "SPECI" | "TAF";
  station: string;
  time: string;
  wind?: {
    direction: number | "VRB";
    speed: number;
    gust?: number;
    unit: string;
    variable?: { from: number; to: number };
  };
  visibility?: {
    value: number;
    unit: string;
    cavok?: boolean;
  };
  weather?: Array<{
    intensity?: string;
    descriptor?: string;
    phenomena: string[];
    raw: string;
  }>;
  clouds?: Array<{
    type: string;
    height: number;
    cloudType?: string;
  }>;
  temperature?: {
    temp: number;
    dewpoint: number;
  };
  pressure?: {
    value: number;
    unit: string;
  };
  trend?: string;
  remarks?: string;
  flightCategory?: "VFR" | "MVFR" | "IFR" | "LIFR";
  decoded?: string;
}

export default function WeatherPage() {
  const [stations, setStations] = useState<string>("YSSY YMML YBBN");
  const [weatherData, setWeatherData] = useState<DecodedWeather[]>([]);
  const [notams, setNotams] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  async function fetchWeather() {
    setIsLoading(true);
    setError(null);
    
    try {
      const stationList = stations.toUpperCase().split(/[\s,]+/).filter(Boolean);
      const res = await fetch("/api/weather", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ stations: stationList }),
      });
      
      const data = await res.json();
      
      if (data.error) {
        setError(data.error);
      } else {
        setWeatherData(data.weather || []);
        setNotams(data.notams || []);
        setLastUpdated(new Date());
      }
    } catch {
      setError("Failed to fetch weather data");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    fetchWeather();
    // Auto-refresh every 10 minutes
    const interval = setInterval(fetchWeather, 10 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border bg-card">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-semibold">Weather Briefing</h1>
            <p className="text-sm text-muted-foreground">
              Aviation weather for Australian aerodromes
            </p>
          </div>
          {lastUpdated && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              Updated {lastUpdated.toLocaleTimeString()}
            </div>
          )}
        </div>
        
        <div className="flex gap-4">
          <div className="flex-1">
            <Label htmlFor="stations" className="text-xs text-muted-foreground">
              ICAO Codes (space or comma separated)
            </Label>
            <div className="flex gap-2 mt-1">
              <Input
                id="stations"
                value={stations}
                onChange={(e) => setStations(e.target.value.toUpperCase())}
                placeholder="YSSY YMML YBBN"
                className="font-mono"
              />
              <Button onClick={fetchWeather} disabled={isLoading}>
                {isLoading ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <Search className="h-4 w-4" />
                )}
                <span className="ml-2">Fetch</span>
              </Button>
            </div>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Quick Select</Label>
            <div className="flex gap-2 mt-1">
              {["NSW", "VIC", "QLD", "All Major"].map((region) => (
                <Button
                  key={region}
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const presets: Record<string, string> = {
                      NSW: "YSSY YSCB YWLM YSNW",
                      VIC: "YMML YMAV YMEN YMMB",
                      QLD: "YBBN YBCG YBTL YBCS",
                      "All Major": "YSSY YMML YBBN YPAD YPER YSCB YBCG",
                    };
                    setStations(presets[region] || "");
                  }}
                >
                  {region}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        <Tabs defaultValue="metar" className="h-full flex flex-col">
          <div className="px-4 pt-4 border-b border-border">
            <TabsList>
              <TabsTrigger value="metar">METAR/SPECI</TabsTrigger>
              <TabsTrigger value="taf">TAF</TabsTrigger>
              <TabsTrigger value="sigmet">SIGMET/AIRMET</TabsTrigger>
              <TabsTrigger value="notam">NOTAM</TabsTrigger>
              <TabsTrigger value="map">Weather Map</TabsTrigger>
            </TabsList>
          </div>

          {error && (
            <Alert variant="destructive" className="m-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="flex-1 overflow-y-auto p-4">
            <TabsContent value="metar" className="m-0 space-y-4">
              {weatherData.filter((w) => w.type === "METAR" || w.type === "SPECI").length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    <Cloud className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No METAR data available</p>
                    <p className="text-sm">Enter station codes and click Fetch</p>
                  </CardContent>
                </Card>
              ) : (
                weatherData
                  .filter((w) => w.type === "METAR" || w.type === "SPECI")
                  .map((weather, idx) => (
                    <WeatherDisplay key={idx} weather={weather} />
                  ))
              )}
            </TabsContent>

            <TabsContent value="taf" className="m-0 space-y-4">
              {weatherData.filter((w) => w.type === "TAF").length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    <Cloud className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No TAF data available</p>
                  </CardContent>
                </Card>
              ) : (
                weatherData
                  .filter((w) => w.type === "TAF")
                  .map((weather, idx) => (
                    <WeatherDisplay key={idx} weather={weather} showForecast />
                  ))
              )}
            </TabsContent>

            <TabsContent value="sigmet" className="m-0 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-orange-500" />
                    Active SIGMET/AIRMET
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-muted-foreground">
                    <Info className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>SIGMET/AIRMET integration requires NAIPS API credentials</p>
                    <p className="text-sm mt-2">Configure credentials in Settings to enable this feature</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Understanding SIGMET/AIRMET</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="flex gap-3">
                    <Badge variant="destructive" className="shrink-0">SIGMET</Badge>
                    <p className="text-muted-foreground">
                      Significant meteorological information: severe turbulence, severe icing, 
                      thunderstorms, volcanic ash, tropical cyclones
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <Badge variant="secondary" className="shrink-0">AIRMET</Badge>
                    <p className="text-muted-foreground">
                      Airmen meteorological information: moderate turbulence, moderate icing, 
                      mountain waves, low-level wind shear
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notam" className="m-0 space-y-4">
              {notams.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    <Info className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No NOTAMs available</p>
                    <p className="text-sm mt-2">NOTAM integration requires NAIPS API credentials</p>
                  </CardContent>
                </Card>
              ) : (
                notams.map((notam, idx) => (
                  <Card key={idx}>
                    <CardContent className="py-4">
                      <pre className="text-sm font-mono whitespace-pre-wrap">{notam}</pre>
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>

            <TabsContent value="map" className="m-0 h-[calc(100vh-300px)]">
              <WeatherMap stations={stations.split(/[\s,]+/).filter(Boolean)} />
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}
