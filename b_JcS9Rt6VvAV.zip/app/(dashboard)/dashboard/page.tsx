import { getSession } from "@/lib/auth"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import {
  Plane,
  Map,
  FileText,
  Cloud,
  Clock,
  Calendar,
  AlertTriangle,
  TrendingUp,
} from "lucide-react"

export default async function DashboardPage() {
  const session = await getSession()

  // In production, these would come from the database
  const stats = {
    totalFlights: 0,
    thisMonth: 0,
    totalHours: 0,
    aircraft: 0,
  }

  const quickActions = [
    {
      title: "New Flight Plan",
      description: "Create a VFR or IFR flight plan",
      href: "/dashboard/plan",
      icon: Map,
      color: "bg-primary",
    },
    {
      title: "Check Weather",
      description: "View METAR, TAF, and area forecasts",
      href: "/dashboard/weather",
      icon: Cloud,
      color: "bg-mvfr",
    },
    {
      title: "My Aircraft",
      description: "Manage your aircraft profiles",
      href: "/dashboard/aircraft",
      icon: Plane,
      color: "bg-accent",
    },
    {
      title: "Recent Plans",
      description: "View and manage your flight plans",
      href: "/dashboard/plans",
      icon: FileText,
      color: "bg-caution",
    },
  ]

  return (
    <div className="p-6 space-y-6">
      {/* Welcome section */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Welcome back, {session?.name.split(" ")[0]}
          </h1>
          <p className="text-muted-foreground">
            Australian VFR/IFR Flight Planning System
          </p>
        </div>
        <Button asChild>
          <Link href="/dashboard/plan">
            <Map className="mr-2 h-4 w-4" />
            New Flight Plan
          </Link>
        </Button>
      </div>

      {/* Stats grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Flights
            </CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalFlights}</div>
            <p className="text-xs text-muted-foreground">
              Flight plans created
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              This Month
            </CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.thisMonth}</div>
            <p className="text-xs text-muted-foreground">
              Flights planned
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Flight Hours
            </CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalHours.toFixed(1)}</div>
            <p className="text-xs text-muted-foreground">
              Total planned hours
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Aircraft
            </CardTitle>
            <Plane className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.aircraft}</div>
            <p className="text-xs text-muted-foreground">
              Profiles configured
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick actions */}
      <div>
        <h2 className="mb-4 text-lg font-semibold">Quick Actions</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {quickActions.map((action) => (
            <Link key={action.title} href={action.href}>
              <Card className="h-full transition-colors hover:bg-muted/50">
                <CardHeader className="pb-2">
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-md ${action.color}`}
                  >
                    <action.icon className="h-5 w-5 text-primary-foreground" />
                  </div>
                </CardHeader>
                <CardContent>
                  <CardTitle className="text-base">{action.title}</CardTitle>
                  <CardDescription className="text-sm">
                    {action.description}
                  </CardDescription>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Information cards */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* NOTAM Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-caution" />
              Active NOTAMs
            </CardTitle>
            <CardDescription>
              Important notices for your recent routes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center py-8 text-muted-foreground">
              <p>No recent routes. Create a flight plan to see relevant NOTAMs.</p>
            </div>
          </CardContent>
        </Card>

        {/* Weather Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Weather Summary
            </CardTitle>
            <CardDescription>
              Current conditions at your frequent airports
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center py-8 text-muted-foreground">
              <p>Add aircraft and plan flights to see weather for your bases.</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Australian aviation info */}
      <Card>
        <CardHeader>
          <CardTitle>System Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 text-sm md:grid-cols-3">
            <div>
              <p className="font-medium text-muted-foreground">AIRAC Cycle</p>
              <p className="font-mono">2501 (Current)</p>
            </div>
            <div>
              <p className="font-medium text-muted-foreground">NAIPS Status</p>
              <p className="text-caution">Not Configured</p>
              <p className="text-xs text-muted-foreground">
                Add credentials to enable weather briefings
              </p>
            </div>
            <div>
              <p className="font-medium text-muted-foreground">Time (UTC)</p>
              <p className="font-mono">{new Date().toISOString().slice(0, 19).replace("T", " ")}Z</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
