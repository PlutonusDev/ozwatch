import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

// GET /api/aircraft - Get user's aircraft profiles
export async function GET(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const includeBase = searchParams.get("includeBase") === "true"

    // Get user's aircraft and optionally base profiles
    const aircraft = await prisma.aircraftProfile.findMany({
      where: {
        OR: [
          { ownerId: session.id },
          ...(includeBase ? [{ isBaseProfile: true }] : []),
        ],
      },
      orderBy: [
        { isBaseProfile: "desc" },
        { name: "asc" },
      ],
    })

    return NextResponse.json({ aircraft })
  } catch (error) {
    console.error("Error fetching aircraft:", error)
    return NextResponse.json(
      { error: "Failed to fetch aircraft" },
      { status: 500 }
    )
  }
}

// POST /api/aircraft - Create new aircraft profile
export async function POST(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const {
      name,
      type,
      registration,
      category,
      engineType,
      numEngines,
      cruiseSpeedKts,
      climbRateFpm,
      descentRateFpm,
      fuelBurnGph,
      fuelCapacityGal,
      usableFuelGal,
      basicEmptyWeight,
      maxTakeoffWeight,
      maxLandingWeight,
      maxZeroFuelWeight,
      basicEmptyArm,
      cgEnvelope,
      weightStations,
      equipmentCodes,
      surveillanceCodes,
      pbn,
      isBaseProfile,
    } = body

    // Only admins can create base profiles
    if (isBaseProfile && session.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Only administrators can create base profiles" },
        { status: 403 }
      )
    }

    const aircraft = await prisma.aircraftProfile.create({
      data: {
        name,
        type,
        registration,
        category,
        engineType,
        numEngines: numEngines || 1,
        cruiseSpeedKts,
        climbRateFpm,
        descentRateFpm,
        fuelBurnGph,
        fuelCapacityGal,
        usableFuelGal,
        basicEmptyWeight,
        maxTakeoffWeight,
        maxLandingWeight,
        maxZeroFuelWeight,
        basicEmptyArm,
        cgEnvelope: cgEnvelope || [],
        weightStations: weightStations || [],
        equipmentCodes: equipmentCodes || "SDFG",
        surveillanceCodes: surveillanceCodes || "B1",
        pbn,
        isBaseProfile: isBaseProfile || false,
        ownerId: isBaseProfile ? null : session.id,
      },
    })

    return NextResponse.json({ aircraft }, { status: 201 })
  } catch (error) {
    console.error("Error creating aircraft:", error)
    return NextResponse.json(
      { error: "Failed to create aircraft" },
      { status: 500 }
    )
  }
}
