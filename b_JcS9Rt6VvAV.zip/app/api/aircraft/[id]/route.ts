import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

// GET /api/aircraft/[id] - Get specific aircraft
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = await params

    const aircraft = await prisma.aircraftProfile.findFirst({
      where: {
        id,
        OR: [
          { ownerId: session.id },
          { isBaseProfile: true },
        ],
      },
    })

    if (!aircraft) {
      return NextResponse.json({ error: "Aircraft not found" }, { status: 404 })
    }

    return NextResponse.json({ aircraft })
  } catch (error) {
    console.error("Error fetching aircraft:", error)
    return NextResponse.json(
      { error: "Failed to fetch aircraft" },
      { status: 500 }
    )
  }
}

// PUT /api/aircraft/[id] - Update aircraft
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = await params
    const body = await request.json()

    // Check ownership
    const existing = await prisma.aircraftProfile.findFirst({
      where: { id },
    })

    if (!existing) {
      return NextResponse.json({ error: "Aircraft not found" }, { status: 404 })
    }

    // Only owner or admin can update
    if (existing.ownerId !== session.id && session.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Base profiles can only be updated by admins
    if (existing.isBaseProfile && session.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Only administrators can update base profiles" },
        { status: 403 }
      )
    }

    const {
      name,
      type,
      registration,
      category,
      engineType,
      numEngines,
      cruiseSpeedKts,
      climbRateFpm,
      descentRateFpm,
      fuelBurnGph,
      fuelCapacityGal,
      usableFuelGal,
      basicEmptyWeight,
      maxTakeoffWeight,
      maxLandingWeight,
      maxZeroFuelWeight,
      basicEmptyArm,
      cgEnvelope,
      weightStations,
      equipmentCodes,
      surveillanceCodes,
      pbn,
    } = body

    const aircraft = await prisma.aircraftProfile.update({
      where: { id },
      data: {
        name,
        type,
        registration,
        category,
        engineType,
        numEngines,
        cruiseSpeedKts,
        climbRateFpm,
        descentRateFpm,
        fuelBurnGph,
        fuelCapacityGal,
        usableFuelGal,
        basicEmptyWeight,
        maxTakeoffWeight,
        maxLandingWeight,
        maxZeroFuelWeight,
        basicEmptyArm,
        cgEnvelope,
        weightStations,
        equipmentCodes,
        surveillanceCodes,
        pbn,
      },
    })

    return NextResponse.json({ aircraft })
  } catch (error) {
    console.error("Error updating aircraft:", error)
    return NextResponse.json(
      { error: "Failed to update aircraft" },
      { status: 500 }
    )
  }
}

// DELETE /api/aircraft/[id] - Delete aircraft
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { id } = await params

    // Check ownership
    const existing = await prisma.aircraftProfile.findFirst({
      where: { id },
    })

    if (!existing) {
      return NextResponse.json({ error: "Aircraft not found" }, { status: 404 })
    }

    // Only owner or admin can delete
    if (existing.ownerId !== session.id && session.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Base profiles can only be deleted by admins
    if (existing.isBaseProfile && session.role !== "ADMIN") {
      return NextResponse.json(
        { error: "Only administrators can delete base profiles" },
        { status: 403 }
      )
    }

    await prisma.aircraftProfile.delete({
      where: { id },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting aircraft:", error)
    return NextResponse.json(
      { error: "Failed to delete aircraft" },
      { status: 500 }
    )
  }
}
