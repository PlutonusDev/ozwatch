import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { NaipsClient } from "@/lib/naips/client";

export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { flightPlanId } = body;

    // Get the flight plan
    const flightPlan = await prisma.flightPlan.findUnique({
      where: { id: flightPlanId },
      include: {
        aircraft: true,
      },
    });

    if (!flightPlan) {
      return NextResponse.json({ error: "Flight plan not found" }, { status: 404 });
    }

    // Check NAIPS credentials
    const naipsUsername = process.env.NAIPS_USERNAME;
    const naipsPassword = process.env.NAIPS_PASSWORD;

    if (!naipsUsername || !naipsPassword) {
      return NextResponse.json({ 
        error: "NAIPS credentials not configured",
        message: "Please configure NAIPS credentials in the admin panel to submit flight plans"
      }, { status: 400 });
    }

    // Create NAIPS client
    const naips = new NaipsClient({
      username: naipsUsername,
      password: naipsPassword,
    });

    // Build ICAO flight plan message
    const icaoFlightPlan = buildIcaoFlightPlan(flightPlan);

    // Submit to NAIPS (this will use the mock in development)
    const result = await naips.submitFlightPlan(icaoFlightPlan);

    // Update flight plan status
    await prisma.flightPlan.update({
      where: { id: flightPlanId },
      data: {
        status: "submitted",
        naipsReference: result.reference,
        submittedAt: new Date(),
      },
    });

    return NextResponse.json({
      success: true,
      reference: result.reference,
      message: "Flight plan submitted successfully",
    });
  } catch (error) {
    console.error("Failed to submit flight plan:", error);
    return NextResponse.json({ error: "Failed to submit flight plan" }, { status: 500 });
  }
}

function buildIcaoFlightPlan(flightPlan: any): string {
  const route = flightPlan.route || [];
  const departureIcao = route[0]?.name || "ZZZZ";
  const destinationIcao = route[route.length - 1]?.name || "ZZZZ";
  
  // Build route string
  const routeString = route
    .slice(1, -1)
    .map((wp: any) => wp.name)
    .join(" ");

  // Calculate total EET
  const totalMinutes = route.reduce((sum: number, wp: any) => sum + (wp.ete || 0), 0);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const eet = `${hours.toString().padStart(2, "0")}${minutes.toString().padStart(2, "0")}`;

  // Build ICAO format message
  const fields = [
    `(FPL-${flightPlan.aircraft?.registration || "VHXXX"}-${flightPlan.flightRules === "IFR" ? "I" : "V"}G`,
    `-${flightPlan.aircraft?.type || "C172"}/L-${flightPlan.aircraft?.equipment?.icaoEquipment || "SDFGORY/S"}`,
    `-${departureIcao}${flightPlan.departureTime || "0000"}`,
    `-N0${flightPlan.cruiseSpeed || "110"}A0${Math.round((flightPlan.cruiseAltitude || 5500) / 100).toString().padStart(3, "0")} ${routeString}`,
    `-${destinationIcao}${eet} ${flightPlan.alternate?.icao || ""}`,
    `-E/${flightPlan.endurance || "0300"} P/${flightPlan.pob || 1}`,
    `-R/ ${flightPlan.remarks || ""}`,
    `)`,
  ];

  return fields.join("\n");
}
