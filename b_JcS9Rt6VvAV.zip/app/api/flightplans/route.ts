import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

// GET /api/flightplans - Get user's flight plans
export async function GET(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const status = searchParams.get("status")
    const limit = parseInt(searchParams.get("limit") || "50")
    const offset = parseInt(searchParams.get("offset") || "0")

    const where: Record<string, unknown> = { userId: session.id }
    if (status) {
      where.status = status
    }

    const [flightPlans, total] = await Promise.all([
      prisma.flightPlan.findMany({
        where,
        include: {
          aircraft: {
            select: {
              name: true,
              type: true,
              registration: true,
            },
          },
        },
        orderBy: { createdAt: "desc" },
        take: limit,
        skip: offset,
      }),
      prisma.flightPlan.count({ where }),
    ])

    return NextResponse.json({
      flightPlans,
      total,
      limit,
      offset,
    })
  } catch (error) {
    console.error("Error fetching flight plans:", error)
    return NextResponse.json(
      { error: "Failed to fetch flight plans" },
      { status: 500 }
    )
  }
}

// POST /api/flightplans - Create new flight plan
export async function POST(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const {
      callsign,
      flightRules,
      flightType,
      departure,
      destination,
      alternates,
      route,
      cruiseAltitude,
      cruiseSpeed,
      waypoints,
      departureTime,
      eet,
      endurance,
      pic,
      crew,
      passengers,
      sarTime,
      fuelPlan,
      weightBalance,
      weatherBriefing,
      aircraftId,
    } = body

    // Verify aircraft ownership/access
    const aircraft = await prisma.aircraftProfile.findFirst({
      where: {
        id: aircraftId,
        OR: [
          { ownerId: session.id },
          { isBaseProfile: true },
        ],
      },
    })

    if (!aircraft) {
      return NextResponse.json(
        { error: "Aircraft not found or not accessible" },
        { status: 400 }
      )
    }

    const flightPlan = await prisma.flightPlan.create({
      data: {
        callsign,
        flightRules,
        flightType: flightType || "PRIVATE",
        departure,
        destination,
        alternates: alternates || [],
        route,
        cruiseAltitude,
        cruiseSpeed,
        waypoints: waypoints || [],
        departureTime: new Date(departureTime),
        eet,
        endurance,
        pic: pic || session.name,
        crew: crew || 1,
        passengers: passengers || 0,
        sarTime,
        fuelPlan,
        weightBalance,
        weatherBriefing,
        userId: session.id,
        aircraftId,
        status: "DRAFT",
      },
      include: {
        aircraft: true,
      },
    })

    return NextResponse.json({ flightPlan }, { status: 201 })
  } catch (error) {
    console.error("Error creating flight plan:", error)
    return NextResponse.json(
      { error: "Failed to create flight plan" },
      { status: 500 }
    )
  }
}
