import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { verifySession } from '@/lib/auth'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await verifySession(request)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params

    const flightPlan = await prisma.flightPlan.findUnique({
      where: { id },
      include: {
        aircraft: true,
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
    })

    if (!flightPlan) {
      return NextResponse.json({ error: 'Flight plan not found' }, { status: 404 })
    }

    // Check if user owns this flight plan or is admin
    if (flightPlan.userId !== session.userId && session.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    return NextResponse.json(flightPlan)
  } catch (error) {
    console.error('Error fetching flight plan:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await verifySession(request)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params
    const body = await request.json()

    // Check if flight plan exists and user owns it
    const existing = await prisma.flightPlan.findUnique({
      where: { id },
    })

    if (!existing) {
      return NextResponse.json({ error: 'Flight plan not found' }, { status: 404 })
    }

    if (existing.userId !== session.userId && session.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    // Don't allow editing submitted plans
    if (existing.status === 'SUBMITTED') {
      return NextResponse.json(
        { error: 'Cannot edit a submitted flight plan' },
        { status: 400 }
      )
    }

    const flightPlan = await prisma.flightPlan.update({
      where: { id },
      data: {
        flightRules: body.flightRules,
        departure: body.departure,
        destination: body.destination,
        alternate: body.alternate,
        route: body.route,
        routeLegs: body.routeLegs,
        cruiseAltitude: body.cruiseAltitude,
        cruiseSpeed: body.cruiseSpeed,
        estimatedTimeEnroute: body.estimatedTimeEnroute,
        fuelOnBoard: body.fuelOnBoard,
        fuelEndurance: body.fuelEndurance,
        departureTime: body.departureTime ? new Date(body.departureTime) : undefined,
        arrivalTime: body.arrivalTime ? new Date(body.arrivalTime) : undefined,
        personsOnBoard: body.personsOnBoard,
        remarks: body.remarks,
        weatherBriefing: body.weatherBriefing,
        notams: body.notams,
        weightBalance: body.weightBalance,
        fuelPlan: body.fuelPlan,
        status: body.status,
      },
      include: {
        aircraft: true,
      },
    })

    return NextResponse.json(flightPlan)
  } catch (error) {
    console.error('Error updating flight plan:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await verifySession(request)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params

    // Check if flight plan exists and user owns it
    const existing = await prisma.flightPlan.findUnique({
      where: { id },
    })

    if (!existing) {
      return NextResponse.json({ error: 'Flight plan not found' }, { status: 404 })
    }

    if (existing.userId !== session.userId && session.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    // Don't allow deleting submitted plans
    if (existing.status === 'SUBMITTED') {
      return NextResponse.json(
        { error: 'Cannot delete a submitted flight plan' },
        { status: 400 }
      )
    }

    await prisma.flightPlan.delete({
      where: { id },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting flight plan:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
