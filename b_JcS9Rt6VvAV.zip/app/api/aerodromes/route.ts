import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

// GET /api/aerodromes - Search aerodromes
export async function GET(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const query = searchParams.get("q")
    const icao = searchParams.get("icao")
    const state = searchParams.get("state")
    const limit = parseInt(searchParams.get("limit") || "50")
    const bounds = searchParams.get("bounds") // "minLat,minLon,maxLat,maxLon"

    const where: Record<string, unknown> = {}

    if (icao) {
      where.icao = icao.toUpperCase()
    } else if (query) {
      where.OR = [
        { icao: { contains: query.toUpperCase() } },
        { name: { contains: query, mode: "insensitive" } },
        { city: { contains: query, mode: "insensitive" } },
      ]
    }

    if (state) {
      where.state = state.toUpperCase()
    }

    if (bounds) {
      const [minLat, minLon, maxLat, maxLon] = bounds.split(",").map(Number)
      where.latitude = { gte: minLat, lte: maxLat }
      where.longitude = { gte: minLon, lte: maxLon }
    }

    const aerodromes = await prisma.aerodrome.findMany({
      where,
      take: limit,
      orderBy: { icao: "asc" },
    })

    return NextResponse.json({ aerodromes })
  } catch (error) {
    console.error("Error fetching aerodromes:", error)
    return NextResponse.json(
      { error: "Failed to fetch aerodromes" },
      { status: 500 }
    )
  }
}

// GET /api/aerodromes/[icao] - Get specific aerodrome
export async function POST(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session || session.role !== "ADMIN") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()

    const aerodrome = await prisma.aerodrome.create({
      data: body,
    })

    return NextResponse.json({ aerodrome }, { status: 201 })
  } catch (error) {
    console.error("Error creating aerodrome:", error)
    return NextResponse.json(
      { error: "Failed to create aerodrome" },
      { status: 500 }
    )
  }
}
