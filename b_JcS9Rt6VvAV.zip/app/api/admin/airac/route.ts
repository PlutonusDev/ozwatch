import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";

// AIRAC cycle calculations
function calculateAiracCycle(date: Date): { cycle: string; effectiveDate: string; expiryDate: string } {
  // AIRAC cycles are 28 days long, starting from a known reference point
  // Reference: Cycle 2401 started on 25 January 2024
  const referenceDate = new Date("2024-01-25");
  const referenceCycle = { year: 24, number: 1 };
  
  const daysDiff = Math.floor((date.getTime() - referenceDate.getTime()) / (1000 * 60 * 60 * 24));
  const cyclesSinceReference = Math.floor(daysDiff / 28);
  
  let cycleNumber = referenceCycle.number + (cyclesSinceReference % 13);
  let cycleYear = referenceCycle.year + Math.floor((referenceCycle.number - 1 + cyclesSinceReference) / 13);
  
  if (cycleNumber > 13) {
    cycleNumber -= 13;
    cycleYear += 1;
  }
  
  const effectiveDate = new Date(referenceDate);
  effectiveDate.setDate(effectiveDate.getDate() + cyclesSinceReference * 28);
  
  const expiryDate = new Date(effectiveDate);
  expiryDate.setDate(expiryDate.getDate() + 28);
  
  return {
    cycle: `${cycleYear.toString().padStart(2, "0")}${cycleNumber.toString().padStart(2, "0")}`,
    effectiveDate: effectiveDate.toISOString().split("T")[0],
    expiryDate: expiryDate.toISOString().split("T")[0],
  };
}

export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const today = new Date();
    const airacInfo = calculateAiracCycle(today);
    
    const expiryDate = new Date(airacInfo.expiryDate);
    const daysUntilExpiry = Math.floor((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    let status: "current" | "expired" | "upcoming" = "current";
    if (daysUntilExpiry < 0) {
      status = "expired";
    } else if (daysUntilExpiry <= 7) {
      status = "upcoming";
    }

    return NextResponse.json({
      airac: {
        ...airacInfo,
        status,
        daysUntilExpiry,
        lastUpdated: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("Failed to get AIRAC status:", error);
    return NextResponse.json({ error: "Failed to get AIRAC status" }, { status: 500 });
  }
}
