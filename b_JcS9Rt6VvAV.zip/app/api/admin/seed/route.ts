import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import bcrypt from 'bcryptjs'

// POST /api/admin/seed - Seed the database with initial data
export async function POST(request: Request) {
  try {
    // Check for secret key to prevent unauthorized seeding
    const { searchParams } = new URL(request.url)
    const secret = searchParams.get('secret')
    
    if (secret !== process.env.JWT_SECRET) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    console.log('[v0] Starting database seed...')

    // Create admin user
    const hashedPassword = await bcrypt.hash('admin123', 12)
    const adminUser = await prisma.user.upsert({
      where: { email: 'admin@flightplan.com.au' },
      update: {},
      create: {
        email: 'admin@flightplan.com.au',
        name: 'Admin User',
        passwordHash: hashedPassword,
        role: 'ADMIN',
        pilotLicenses: ['CPL', 'IREX', 'NVFR'],
        medicalExpiry: new Date('2026-12-31'),
      },
    })
    console.log('[v0] Created admin user:', adminUser.email)

    // Create base aircraft profiles
    const aircraftProfiles = [
      {
        registration: 'VH-XXX',
        type: 'C172',
        name: 'Cessna 172S Skyhawk',
        isBaseProfile: true,
        category: 'SEP',
        engineType: 'PISTON',
        emptyWeight: 767,
        emptyWeightArm: 1012,
        maxTakeoffWeight: 1157,
        maxLandingWeight: 1157,
        fuelCapacity: 212,
        usableFuel: 200,
        fuelBurnRate: 36,
        cruiseSpeed: 122,
        cruiseAltitude: 5500,
        climbRate: 730,
        climbSpeed: 79,
        descentRate: 500,
        descentSpeed: 100,
        approachSpeed: 65,
        vne: 163,
        vno: 129,
        va: 99,
        vfe: 85,
        serviceCeiling: 14000,
        range: 640,
        endurance: 5.5,
        equipmentCodes: 'SDFG',
        surveillanceCodes: 'S',
        pbnCapabilities: ['RNAV1', 'RNP1'],
        weightBalanceStations: [
          { name: 'Front Seats', arm: 940, minWeight: 0, maxWeight: 180 },
          { name: 'Rear Seats', arm: 1219, minWeight: 0, maxWeight: 166 },
          { name: 'Baggage Area 1', arm: 1727, minWeight: 0, maxWeight: 54 },
          { name: 'Baggage Area 2', arm: 2184, minWeight: 0, maxWeight: 23 },
          { name: 'Fuel', arm: 1219, minWeight: 0, maxWeight: 144 },
        ],
        cgEnvelope: [
          { weight: 680, fwdCG: 889, aftCG: 1143 },
          { weight: 850, fwdCG: 889, aftCG: 1143 },
          { weight: 1000, fwdCG: 940, aftCG: 1143 },
          { weight: 1157, fwdCG: 978, aftCG: 1143 },
        ],
        remarks: 'Standard Cessna 172S - Base Profile',
      },
      {
        registration: 'VH-YYY',
        type: 'PA28',
        name: 'Piper PA-28-161 Warrior',
        isBaseProfile: true,
        category: 'SEP',
        engineType: 'PISTON',
        emptyWeight: 635,
        emptyWeightArm: 2140,
        maxTakeoffWeight: 1107,
        maxLandingWeight: 1107,
        fuelCapacity: 189,
        usableFuel: 182,
        fuelBurnRate: 34,
        cruiseSpeed: 117,
        cruiseAltitude: 5000,
        climbRate: 710,
        climbSpeed: 76,
        descentRate: 500,
        descentSpeed: 100,
        approachSpeed: 63,
        vne: 154,
        vno: 126,
        va: 98,
        vfe: 103,
        serviceCeiling: 13000,
        range: 615,
        endurance: 5.3,
        equipmentCodes: 'SDFG',
        surveillanceCodes: 'S',
        pbnCapabilities: ['RNAV1'],
        weightBalanceStations: [
          { name: 'Front Seats', arm: 2032, minWeight: 0, maxWeight: 180 },
          { name: 'Rear Seats', arm: 2972, minWeight: 0, maxWeight: 163 },
          { name: 'Baggage', arm: 3683, minWeight: 0, maxWeight: 91 },
          { name: 'Fuel', arm: 2413, minWeight: 0, maxWeight: 131 },
        ],
        cgEnvelope: [
          { weight: 635, fwdCG: 2057, aftCG: 2413 },
          { weight: 800, fwdCG: 2057, aftCG: 2413 },
          { weight: 1000, fwdCG: 2108, aftCG: 2413 },
          { weight: 1107, fwdCG: 2159, aftCG: 2413 },
        ],
        remarks: 'Standard PA-28-161 Warrior - Base Profile',
      },
      {
        registration: 'VH-ZZZ',
        type: 'BE76',
        name: 'Beechcraft BE76 Duchess',
        isBaseProfile: true,
        category: 'MEP',
        engineType: 'PISTON',
        emptyWeight: 1179,
        emptyWeightArm: 2336,
        maxTakeoffWeight: 1769,
        maxLandingWeight: 1678,
        fuelCapacity: 378,
        usableFuel: 364,
        fuelBurnRate: 68,
        cruiseSpeed: 160,
        cruiseAltitude: 8000,
        climbRate: 1248,
        climbSpeed: 85,
        descentRate: 500,
        descentSpeed: 120,
        approachSpeed: 80,
        vne: 194,
        vno: 162,
        va: 124,
        vfe: 110,
        vyse: 85,
        vmc: 67,
        serviceCeiling: 19650,
        singleEngineServiceCeiling: 6100,
        range: 815,
        endurance: 5.3,
        equipmentCodes: 'SDFGR',
        surveillanceCodes: 'S',
        pbnCapabilities: ['RNAV1', 'RNP1', 'RNAV5'],
        weightBalanceStations: [
          { name: 'Front Seats', arm: 2184, minWeight: 0, maxWeight: 181 },
          { name: 'Rear Seats', arm: 3099, minWeight: 0, maxWeight: 181 },
          { name: 'Nose Baggage', arm: 762, minWeight: 0, maxWeight: 45 },
          { name: 'Aft Baggage', arm: 3733, minWeight: 0, maxWeight: 91 },
          { name: 'Fuel', arm: 2489, minWeight: 0, maxWeight: 261 },
        ],
        cgEnvelope: [
          { weight: 1179, fwdCG: 2235, aftCG: 2464 },
          { weight: 1450, fwdCG: 2260, aftCG: 2489 },
          { weight: 1678, fwdCG: 2286, aftCG: 2489 },
          { weight: 1769, fwdCG: 2286, aftCG: 2489 },
        ],
        remarks: 'Standard BE76 Duchess - Base Profile for Multi-Engine Training',
      },
    ]

    for (const aircraft of aircraftProfiles) {
      await prisma.aircraftProfile.upsert({
        where: { registration: aircraft.registration },
        update: aircraft,
        create: aircraft,
      })
    }
    console.log('[v0] Created aircraft profiles')

    // Create aerodromes
    const aerodromes = [
      { icaoCode: 'YSSY', iataCode: 'SYD', name: 'Sydney Kingsford Smith', city: 'Sydney', state: 'NSW', latitude: -33.9461, longitude: 151.1772, elevation: 21, magneticVariation: 12.5, type: 'INTERNATIONAL', status: 'ACTIVE', hasCustoms: true, hasFuel: true, fuelTypes: ['AVGAS', 'JET-A1'], runways: [{ designator: '16R/34L', length: 3962, width: 45, surface: 'ASPHALT', lighting: true, ils: true }, { designator: '16L/34R', length: 2530, width: 45, surface: 'ASPHALT', lighting: true, ils: true }, { designator: '07/25', length: 2134, width: 45, surface: 'ASPHALT', lighting: true, ils: false }], frequencies: [{ type: 'ATIS', frequency: 126.25, callsign: 'SYDNEY ATIS' }, { type: 'TWR', frequency: 120.5, callsign: 'SYDNEY TOWER' }, { type: 'GND', frequency: 121.7, callsign: 'SYDNEY GROUND' }, { type: 'APP', frequency: 124.4, callsign: 'SYDNEY APPROACH' }], remarks: 'Class C CTR. Slot coordination required.' },
      { icaoCode: 'YMML', iataCode: 'MEL', name: 'Melbourne Tullamarine', city: 'Melbourne', state: 'VIC', latitude: -37.6733, longitude: 144.8433, elevation: 434, magneticVariation: 11.5, type: 'INTERNATIONAL', status: 'ACTIVE', hasCustoms: true, hasFuel: true, fuelTypes: ['AVGAS', 'JET-A1'], runways: [{ designator: '16/34', length: 3657, width: 45, surface: 'ASPHALT', lighting: true, ils: true }, { designator: '09/27', length: 2286, width: 45, surface: 'ASPHALT', lighting: true, ils: true }], frequencies: [{ type: 'ATIS', frequency: 118.0, callsign: 'MELBOURNE ATIS' }, { type: 'TWR', frequency: 120.5, callsign: 'MELBOURNE TOWER' }, { type: 'GND', frequency: 121.7, callsign: 'MELBOURNE GROUND' }, { type: 'APP', frequency: 132.0, callsign: 'MELBOURNE APPROACH' }], remarks: 'Class C CTR. Noise abatement procedures apply.' },
      { icaoCode: 'YBBN', iataCode: 'BNE', name: 'Brisbane', city: 'Brisbane', state: 'QLD', latitude: -27.3842, longitude: 153.1175, elevation: 13, magneticVariation: 10.8, type: 'INTERNATIONAL', status: 'ACTIVE', hasCustoms: true, hasFuel: true, fuelTypes: ['AVGAS', 'JET-A1'], runways: [{ designator: '01/19', length: 3560, width: 45, surface: 'ASPHALT', lighting: true, ils: true }, { designator: '14/32', length: 1760, width: 30, surface: 'ASPHALT', lighting: true, ils: false }], frequencies: [{ type: 'ATIS', frequency: 126.25, callsign: 'BRISBANE ATIS' }, { type: 'TWR', frequency: 120.5, callsign: 'BRISBANE TOWER' }, { type: 'GND', frequency: 121.7, callsign: 'BRISBANE GROUND' }, { type: 'APP', frequency: 125.6, callsign: 'BRISBANE APPROACH' }], remarks: 'Class C CTR.' },
      { icaoCode: 'YPPH', iataCode: 'PER', name: 'Perth', city: 'Perth', state: 'WA', latitude: -31.9403, longitude: 115.9669, elevation: 67, magneticVariation: -1.2, type: 'INTERNATIONAL', status: 'ACTIVE', hasCustoms: true, hasFuel: true, fuelTypes: ['AVGAS', 'JET-A1'], runways: [{ designator: '03/21', length: 3444, width: 45, surface: 'ASPHALT', lighting: true, ils: true }, { designator: '06/24', length: 2163, width: 45, surface: 'ASPHALT', lighting: true, ils: false }], frequencies: [{ type: 'ATIS', frequency: 123.8, callsign: 'PERTH ATIS' }, { type: 'TWR', frequency: 127.4, callsign: 'PERTH TOWER' }, { type: 'GND', frequency: 121.7, callsign: 'PERTH GROUND' }, { type: 'APP', frequency: 123.6, callsign: 'PERTH APPROACH' }], remarks: 'Class C CTR.' },
      { icaoCode: 'YPAD', iataCode: 'ADL', name: 'Adelaide', city: 'Adelaide', state: 'SA', latitude: -34.945, longitude: 138.5306, elevation: 20, magneticVariation: 7.0, type: 'INTERNATIONAL', status: 'ACTIVE', hasCustoms: true, hasFuel: true, fuelTypes: ['AVGAS', 'JET-A1'], runways: [{ designator: '05/23', length: 3100, width: 45, surface: 'ASPHALT', lighting: true, ils: true }, { designator: '12/30', length: 1650, width: 30, surface: 'ASPHALT', lighting: true, ils: false }], frequencies: [{ type: 'ATIS', frequency: 121.1, callsign: 'ADELAIDE ATIS' }, { type: 'TWR', frequency: 120.5, callsign: 'ADELAIDE TOWER' }, { type: 'GND', frequency: 121.7, callsign: 'ADELAIDE GROUND' }, { type: 'APP', frequency: 124.2, callsign: 'ADELAIDE APPROACH' }], remarks: 'Class C CTR.' },
      { icaoCode: 'YSCB', iataCode: 'CBR', name: 'Canberra', city: 'Canberra', state: 'ACT', latitude: -35.3069, longitude: 149.1950, elevation: 1886, magneticVariation: 12.0, type: 'DOMESTIC', status: 'ACTIVE', hasCustoms: false, hasFuel: true, fuelTypes: ['AVGAS', 'JET-A1'], runways: [{ designator: '17/35', length: 3283, width: 45, surface: 'ASPHALT', lighting: true, ils: true }, { designator: '12/30', length: 1319, width: 30, surface: 'ASPHALT', lighting: true, ils: false }], frequencies: [{ type: 'ATIS', frequency: 127.45, callsign: 'CANBERRA ATIS' }, { type: 'TWR', frequency: 118.7, callsign: 'CANBERRA TOWER' }, { type: 'GND', frequency: 121.7, callsign: 'CANBERRA GROUND' }, { type: 'APP', frequency: 125.9, callsign: 'CANBERRA APPROACH' }], remarks: 'Class C CTR. RAAF operations.' },
      { icaoCode: 'YBCG', iataCode: 'OOL', name: 'Gold Coast (Coolangatta)', city: 'Gold Coast', state: 'QLD', latitude: -28.1644, longitude: 153.5047, elevation: 21, magneticVariation: 11.0, type: 'DOMESTIC', status: 'ACTIVE', hasCustoms: true, hasFuel: true, fuelTypes: ['AVGAS', 'JET-A1'], runways: [{ designator: '14/32', length: 2042, width: 45, surface: 'ASPHALT', lighting: true, ils: true }], frequencies: [{ type: 'ATIS', frequency: 119.7, callsign: 'GOLD COAST ATIS' }, { type: 'TWR', frequency: 118.7, callsign: 'GOLD COAST TOWER' }, { type: 'GND', frequency: 121.8, callsign: 'GOLD COAST GROUND' }], remarks: 'Class D CTR. Noise curfew 2300-0600.' },
      { icaoCode: 'YBCS', iataCode: 'CNS', name: 'Cairns', city: 'Cairns', state: 'QLD', latitude: -16.8858, longitude: 145.7553, elevation: 10, magneticVariation: 8.0, type: 'INTERNATIONAL', status: 'ACTIVE', hasCustoms: true, hasFuel: true, fuelTypes: ['AVGAS', 'JET-A1'], runways: [{ designator: '15/33', length: 3168, width: 45, surface: 'ASPHALT', lighting: true, ils: true }], frequencies: [{ type: 'ATIS', frequency: 126.9, callsign: 'CAIRNS ATIS' }, { type: 'TWR', frequency: 124.9, callsign: 'CAIRNS TOWER' }, { type: 'GND', frequency: 121.7, callsign: 'CAIRNS GROUND' }, { type: 'APP', frequency: 118.4, callsign: 'CAIRNS APPROACH' }], remarks: 'Class C CTR.' },
      { icaoCode: 'YPDN', iataCode: 'DRW', name: 'Darwin International', city: 'Darwin', state: 'NT', latitude: -12.4147, longitude: 130.8767, elevation: 103, magneticVariation: 3.5, type: 'INTERNATIONAL', status: 'ACTIVE', hasCustoms: true, hasFuel: true, fuelTypes: ['AVGAS', 'JET-A1'], runways: [{ designator: '11/29', length: 3354, width: 45, surface: 'ASPHALT', lighting: true, ils: true }, { designator: '18/36', length: 1526, width: 30, surface: 'ASPHALT', lighting: true, ils: false }], frequencies: [{ type: 'ATIS', frequency: 128.25, callsign: 'DARWIN ATIS' }, { type: 'TWR', frequency: 133.1, callsign: 'DARWIN TOWER' }, { type: 'GND', frequency: 121.8, callsign: 'DARWIN GROUND' }, { type: 'APP', frequency: 125.2, callsign: 'DARWIN APPROACH' }], remarks: 'Class C CTR. Joint civil/military.' },
      { icaoCode: 'YMHB', iataCode: 'HBA', name: 'Hobart', city: 'Hobart', state: 'TAS', latitude: -42.8361, longitude: 147.5103, elevation: 13, magneticVariation: 14.5, type: 'DOMESTIC', status: 'ACTIVE', hasCustoms: true, hasFuel: true, fuelTypes: ['AVGAS', 'JET-A1'], runways: [{ designator: '12/30', length: 2250, width: 45, surface: 'ASPHALT', lighting: true, ils: true }], frequencies: [{ type: 'ATIS', frequency: 128.45, callsign: 'HOBART ATIS' }, { type: 'TWR', frequency: 118.1, callsign: 'HOBART TOWER' }, { type: 'GND', frequency: 121.7, callsign: 'HOBART GROUND' }], remarks: 'Class D CTR.' },
      { icaoCode: 'YMEN', iataCode: 'MEB', name: 'Essendon Fields', city: 'Melbourne', state: 'VIC', latitude: -37.7281, longitude: 144.9017, elevation: 282, magneticVariation: 11.5, type: 'GENERAL_AVIATION', status: 'ACTIVE', hasCustoms: false, hasFuel: true, fuelTypes: ['AVGAS', 'JET-A1'], runways: [{ designator: '17/35', length: 1921, width: 30, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '08/26', length: 1554, width: 30, surface: 'ASPHALT', lighting: true, ils: false }], frequencies: [{ type: 'ATIS', frequency: 119.8, callsign: 'ESSENDON ATIS' }, { type: 'TWR', frequency: 125.1, callsign: 'ESSENDON TOWER' }, { type: 'GND', frequency: 121.9, callsign: 'ESSENDON GROUND' }], remarks: 'Class D CTR. Melbourne CTR.' },
      { icaoCode: 'YSBK', iataCode: 'BWU', name: 'Bankstown', city: 'Sydney', state: 'NSW', latitude: -33.9244, longitude: 150.9886, elevation: 29, magneticVariation: 12.5, type: 'GENERAL_AVIATION', status: 'ACTIVE', hasCustoms: false, hasFuel: true, fuelTypes: ['AVGAS'], runways: [{ designator: '11L/29R', length: 1411, width: 30, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '11C/29C', length: 1198, width: 30, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '11R/29L', length: 890, width: 18, surface: 'ASPHALT', lighting: true, ils: false }], frequencies: [{ type: 'ATIS', frequency: 120.9, callsign: 'BANKSTOWN ATIS' }, { type: 'TWR', frequency: 132.8, callsign: 'BANKSTOWN TOWER' }, { type: 'GND', frequency: 121.8, callsign: 'BANKSTOWN GROUND' }], remarks: 'Class D CTR. Busy training aerodrome.' },
      { icaoCode: 'YMMB', iataCode: 'MBW', name: 'Moorabbin', city: 'Melbourne', state: 'VIC', latitude: -37.9758, longitude: 145.1022, elevation: 50, magneticVariation: 11.5, type: 'GENERAL_AVIATION', status: 'ACTIVE', hasCustoms: false, hasFuel: true, fuelTypes: ['AVGAS'], runways: [{ designator: '13L/31R', length: 1335, width: 18, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '13R/31L', length: 1062, width: 18, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '17L/35R', length: 1024, width: 18, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '17R/35L', length: 804, width: 18, surface: 'ASPHALT', lighting: false, ils: false }], frequencies: [{ type: 'ATIS', frequency: 120.9, callsign: 'MOORABBIN ATIS' }, { type: 'TWR', frequency: 118.1, callsign: 'MOORABBIN TOWER' }, { type: 'GND', frequency: 119.9, callsign: 'MOORABBIN GROUND' }], remarks: 'Class D CTR. Busiest GA aerodrome in Australia.' },
      { icaoCode: 'YBAF', iataCode: null, name: 'Archerfield', city: 'Brisbane', state: 'QLD', latitude: -27.5706, longitude: 153.0078, elevation: 63, magneticVariation: 10.8, type: 'GENERAL_AVIATION', status: 'ACTIVE', hasCustoms: false, hasFuel: true, fuelTypes: ['AVGAS'], runways: [{ designator: '10L/28R', length: 1500, width: 30, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '10R/28L', length: 1112, width: 30, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '04/22', length: 970, width: 18, surface: 'ASPHALT', lighting: true, ils: false }], frequencies: [{ type: 'ATIS', frequency: 118.85, callsign: 'ARCHERFIELD ATIS' }, { type: 'TWR', frequency: 118.1, callsign: 'ARCHERFIELD TOWER' }, { type: 'GND', frequency: 121.6, callsign: 'ARCHERFIELD GROUND' }], remarks: 'Class D CTR.' },
      { icaoCode: 'YPJT', iataCode: null, name: 'Jandakot', city: 'Perth', state: 'WA', latitude: -32.0975, longitude: 115.8811, elevation: 99, magneticVariation: -1.2, type: 'GENERAL_AVIATION', status: 'ACTIVE', hasCustoms: false, hasFuel: true, fuelTypes: ['AVGAS'], runways: [{ designator: '06L/24R', length: 1234, width: 23, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '06R/24L', length: 1058, width: 18, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '12/30', length: 1180, width: 18, surface: 'ASPHALT', lighting: true, ils: false }], frequencies: [{ type: 'ATIS', frequency: 116.3, callsign: 'JANDAKOT ATIS' }, { type: 'TWR', frequency: 118.1, callsign: 'JANDAKOT TOWER' }, { type: 'GND', frequency: 124.3, callsign: 'JANDAKOT GROUND' }], remarks: 'Class D CTR.' },
      { icaoCode: 'YPPF', iataCode: null, name: 'Parafield', city: 'Adelaide', state: 'SA', latitude: -34.7933, longitude: 138.6331, elevation: 57, magneticVariation: 7.0, type: 'GENERAL_AVIATION', status: 'ACTIVE', hasCustoms: false, hasFuel: true, fuelTypes: ['AVGAS'], runways: [{ designator: '03L/21R', length: 1525, width: 30, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '03R/21L', length: 1433, width: 30, surface: 'ASPHALT', lighting: true, ils: false }, { designator: '08/26', length: 852, width: 18, surface: 'ASPHALT', lighting: true, ils: false }], frequencies: [{ type: 'ATIS', frequency: 134.5, callsign: 'PARAFIELD ATIS' }, { type: 'TWR', frequency: 118.7, callsign: 'PARAFIELD TOWER' }, { type: 'GND', frequency: 119.9, callsign: 'PARAFIELD GROUND' }], remarks: 'Class D CTR.' },
    ]

    for (const aerodrome of aerodromes) {
      await prisma.aerodrome.upsert({
        where: { icaoCode: aerodrome.icaoCode },
        update: aerodrome,
        create: aerodrome,
      })
    }
    console.log('[v0] Created aerodromes')

    // Create sample waypoints
    const waypoints = [
      { identifier: 'TESAT', name: 'TESAT', type: 'RNAV', latitude: -33.8833, longitude: 150.7333 },
      { identifier: 'MARKY', name: 'MARKY', type: 'RNAV', latitude: -33.7500, longitude: 150.9167 },
      { identifier: 'ENTRA', name: 'ENTRA', type: 'RNAV', latitude: -34.0500, longitude: 151.2833 },
      { identifier: 'SOSIJ', name: 'SOSIJ', type: 'RNAV', latitude: -33.6667, longitude: 151.3333 },
      { identifier: 'SHORE', name: 'SHORE', type: 'RNAV', latitude: -37.5833, longitude: 144.9500 },
      { identifier: 'ARBEY', name: 'ARBEY', type: 'RNAV', latitude: -37.8333, longitude: 144.8833 },
      { identifier: 'LIZZI', name: 'LIZZI', type: 'RNAV', latitude: -27.3500, longitude: 153.2333 },
      { identifier: 'BLAKA', name: 'BLAKA', type: 'RNAV', latitude: -27.5000, longitude: 152.9167 },
      { identifier: 'SY', name: 'Sydney VOR', type: 'VOR', latitude: -33.9461, longitude: 151.1772, frequency: 115.4 },
      { identifier: 'ML', name: 'Melbourne VOR', type: 'VOR', latitude: -37.6733, longitude: 144.8433, frequency: 114.1 },
      { identifier: 'BN', name: 'Brisbane VOR', type: 'VOR', latitude: -27.3842, longitude: 153.1175, frequency: 112.2 },
      { identifier: 'AD', name: 'Adelaide VOR', type: 'VOR', latitude: -34.945, longitude: 138.5306, frequency: 114.5 },
      { identifier: 'PH', name: 'Perth VOR', type: 'VOR', latitude: -31.9403, longitude: 115.9669, frequency: 113.8 },
      { identifier: 'RIC', name: 'Richmond NDB', type: 'NDB', latitude: -33.6004, longitude: 150.7811, frequency: 398 },
      { identifier: 'PKS', name: 'Parkes NDB', type: 'NDB', latitude: -33.1333, longitude: 148.2333, frequency: 356 },
      { identifier: 'DBO', name: 'Dubbo NDB', type: 'NDB', latitude: -32.2167, longitude: 148.5750, frequency: 365 },
    ]

    for (const waypoint of waypoints) {
      await prisma.waypoint.upsert({
        where: { identifier: waypoint.identifier },
        update: waypoint,
        create: waypoint,
      })
    }
    console.log('[v0] Created waypoints')

    // Create AIRAC cycle
    await prisma.aIRACCycle.upsert({
      where: { cycleNumber: '2604' },
      update: {},
      create: {
        cycleNumber: '2604',
        effectiveDate: new Date('2026-03-26'),
        expiryDate: new Date('2026-04-23'),
        isActive: true,
        dataSource: 'Manual',
        importedAt: new Date(),
      },
    })
    console.log('[v0] Created AIRAC cycle')

    // Create sample airspace
    const airspaces = [
      {
        name: 'SYDNEY CTR',
        type: 'CTR',
        class: 'C',
        lowerLimit: 0,
        lowerLimitUnit: 'FT',
        lowerLimitReference: 'AGL',
        upperLimit: 8500,
        upperLimitUnit: 'FT',
        upperLimitReference: 'AMSL',
        boundaries: [
          { latitude: -33.7167, longitude: 150.8833 },
          { latitude: -33.7167, longitude: 151.4500 },
          { latitude: -34.1667, longitude: 151.4500 },
          { latitude: -34.1667, longitude: 150.8833 },
          { latitude: -33.7167, longitude: 150.8833 },
        ],
        controllingAuthority: 'SYDNEY APPROACH',
        frequencies: ['124.4'],
      },
      {
        name: 'MELBOURNE CTR',
        type: 'CTR',
        class: 'C',
        lowerLimit: 0,
        lowerLimitUnit: 'FT',
        lowerLimitReference: 'AGL',
        upperLimit: 4500,
        upperLimitUnit: 'FT',
        upperLimitReference: 'AMSL',
        boundaries: [
          { latitude: -37.4500, longitude: 144.5333 },
          { latitude: -37.4500, longitude: 145.2000 },
          { latitude: -37.9000, longitude: 145.2000 },
          { latitude: -37.9000, longitude: 144.5333 },
          { latitude: -37.4500, longitude: 144.5333 },
        ],
        controllingAuthority: 'MELBOURNE APPROACH',
        frequencies: ['132.0'],
      },
      {
        name: 'BRISBANE CTR',
        type: 'CTR',
        class: 'C',
        lowerLimit: 0,
        lowerLimitUnit: 'FT',
        lowerLimitReference: 'AGL',
        upperLimit: 3500,
        upperLimitUnit: 'FT',
        upperLimitReference: 'AMSL',
        boundaries: [
          { latitude: -27.1667, longitude: 152.9000 },
          { latitude: -27.1667, longitude: 153.4167 },
          { latitude: -27.6000, longitude: 153.4167 },
          { latitude: -27.6000, longitude: 152.9000 },
          { latitude: -27.1667, longitude: 152.9000 },
        ],
        controllingAuthority: 'BRISBANE APPROACH',
        frequencies: ['125.6'],
      },
    ]

    for (const airspace of airspaces) {
      // Use a combination of name and type as unique identifier
      const existing = await prisma.airspace.findFirst({
        where: { name: airspace.name, type: airspace.type },
      })
      if (existing) {
        await prisma.airspace.update({
          where: { id: existing.id },
          data: airspace,
        })
      } else {
        await prisma.airspace.create({ data: airspace })
      }
    }
    console.log('[v0] Created airspace')

    // Create sample airways
    const airways = [
      {
        designator: 'W113',
        type: 'LOW',
        lowerLimit: 4500,
        upperLimit: 24500,
        direction: 'BOTH',
        fixes: ['TESAT', 'SY', 'ENTRA'],
      },
      {
        designator: 'W217',
        type: 'LOW',
        lowerLimit: 5500,
        upperLimit: 24500,
        direction: 'BOTH',
        fixes: ['ML', 'SHORE', 'ARBEY'],
      },
      {
        designator: 'Q29',
        type: 'HIGH',
        lowerLimit: 24500,
        upperLimit: 45000,
        direction: 'BOTH',
        fixes: ['SY', 'ML'],
      },
    ]

    for (const airway of airways) {
      await prisma.airway.upsert({
        where: { designator: airway.designator },
        update: airway,
        create: airway,
      })
    }
    console.log('[v0] Created airways')

    console.log('[v0] Database seed completed successfully!')

    return NextResponse.json({
      success: true,
      message: 'Database seeded successfully',
      data: {
        admin: adminUser.email,
        aircraftCount: aircraftProfiles.length,
        aerodromeCount: aerodromes.length,
        waypointCount: waypoints.length,
        airspaceCount: airspaces.length,
        airwayCount: airways.length,
      },
    })
  } catch (error) {
    console.error('[v0] Seed error:', error)
    return NextResponse.json(
      { error: 'Failed to seed database', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
