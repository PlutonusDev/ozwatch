import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if NAIPS credentials are configured
    const isConfigured = !!(
      process.env.NAIPS_USERNAME && 
      process.env.NAIPS_PASSWORD
    );

    return NextResponse.json({
      isConfigured,
      services: {
        weatherBriefing: isConfigured,
        notams: isConfigured,
        flightPlanSubmission: isConfigured,
        sartime: isConfigured,
      },
    });
  } catch (error) {
    console.error("Failed to get NAIPS status:", error);
    return NextResponse.json({ error: "Failed to get NAIPS status" }, { status: 500 });
  }
}
