import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { calculateLSALT } from "@/lib/utils/aviation"

interface LSALTRequest {
  from: { latitude: number; longitude: number }
  to: { latitude: number; longitude: number }
  flightRules: "VFR" | "IFR"
}

// POST /api/route/lsalt - Calculate LSALT for a route leg
export async function POST(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body: LSALTRequest = await request.json()
    const { from, to, flightRules } = body

    // Calculate buffer distance based on flight rules
    const bufferNm = flightRules === "VFR" ? 5 : 10

    // Get the bounding box for the route leg with buffer
    const minLat = Math.min(from.latitude, to.latitude) - (bufferNm / 60)
    const maxLat = Math.max(from.latitude, to.latitude) + (bufferNm / 60)
    const minLon = Math.min(from.longitude, to.longitude) - (bufferNm / (60 * Math.cos((from.latitude + to.latitude) / 2 * Math.PI / 180)))
    const maxLon = Math.max(from.longitude, to.longitude) + (bufferNm / (60 * Math.cos((from.latitude + to.latitude) / 2 * Math.PI / 180)))

    // Query terrain grid for maximum elevation in the corridor
    const terrainCells = await prisma.terrainGrid.findMany({
      where: {
        AND: [
          { minLat: { lte: maxLat } },
          { maxLat: { gte: minLat } },
          { minLon: { lte: maxLon } },
          { maxLon: { gte: minLon } },
        ],
      },
    })

    // Find maximum elevation from terrain data
    let maxElevation = 0
    for (const cell of terrainCells) {
      if (cell.maxElevation > maxElevation) {
        maxElevation = cell.maxElevation
      }
    }

    // If no terrain data, use a conservative default (3000ft)
    if (terrainCells.length === 0) {
      maxElevation = 3000
    }

    // Calculate LSALT
    const lsaltResult = calculateLSALT(maxElevation, flightRules)

    return NextResponse.json({
      maxTerrainElevation: maxElevation,
      bufferDistanceNm: bufferNm,
      clearanceFt: lsaltResult.clearance,
      calculatedLSALT: lsaltResult.calculatedLSALT,
      roundedTo: lsaltResult.roundUp,
      terrainDataAvailable: terrainCells.length > 0,
      note: terrainCells.length === 0
        ? "No terrain data available - using conservative estimate. Please verify with official sources."
        : undefined,
    })
  } catch (error) {
    console.error("Error calculating LSALT:", error)
    return NextResponse.json(
      { error: "Failed to calculate LSALT" },
      { status: 500 }
    )
  }
}
