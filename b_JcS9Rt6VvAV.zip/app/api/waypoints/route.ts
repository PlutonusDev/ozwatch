import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

// GET /api/waypoints - Search waypoints
export async function GET(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const query = searchParams.get("q")
    const type = searchParams.get("type")
    const limit = parseInt(searchParams.get("limit") || "100")
    const bounds = searchParams.get("bounds")

    const where: Record<string, unknown> = {}

    if (query) {
      where.identifier = { contains: query.toUpperCase() }
    }

    if (type) {
      where.type = type.toUpperCase()
    }

    if (bounds) {
      const [minLat, minLon, maxLat, maxLon] = bounds.split(",").map(Number)
      where.latitude = { gte: minLat, lte: maxLat }
      where.longitude = { gte: minLon, lte: maxLon }
    }

    const waypoints = await prisma.waypoint.findMany({
      where,
      take: limit,
      orderBy: { identifier: "asc" },
    })

    return NextResponse.json({ waypoints })
  } catch (error) {
    console.error("Error fetching waypoints:", error)
    return NextResponse.json(
      { error: "Failed to fetch waypoints" },
      { status: 500 }
    )
  }
}
