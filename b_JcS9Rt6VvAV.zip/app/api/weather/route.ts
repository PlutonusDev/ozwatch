import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getNAIPSClient, getFallbackWeather } from "@/lib/naips/client"
import { parseMetar, parseTaf } from "@/lib/weather/decoder"

// GET /api/weather?stations=YSSY,YMML&type=metar
export async function GET(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const stations = searchParams.get("stations")?.split(",").filter(Boolean) || []
    const type = searchParams.get("type") || "all" // metar, taf, or all

    if (stations.length === 0) {
      return NextResponse.json(
        { error: "At least one station is required" },
        { status: 400 }
      )
    }

    const naipsClient = getNAIPSClient()

    // Try NAIPS first if configured
    if (naipsClient.isAvailable()) {
      const result = await naipsClient.getWeatherBriefing(
        stations[0],
        stations[1] || stations[0],
        stations.slice(2)
      )

      if (result.success && result.data) {
        return NextResponse.json({
          source: "NAIPS",
          metars: type !== "taf" ? result.data.metars : [],
          tafs: type !== "metar" ? result.data.tafs : [],
          sigmets: result.data.sigmets,
          airmets: result.data.airmets,
        })
      }
    }

    // Fallback to public weather sources
    const fallback = await getFallbackWeather(stations)

    return NextResponse.json({
      source: "FALLBACK",
      metars: type !== "taf" ? fallback.metars : [],
      tafs: type !== "metar" ? fallback.tafs : [],
      sigmets: [],
      airmets: [],
      notice: "Using fallback weather source. Configure NAIPS credentials for full briefings.",
    })
  } catch (error) {
    console.error("Error fetching weather:", error)
    return NextResponse.json(
      { error: "Failed to fetch weather data" },
      { status: 500 }
    )
  }
}

// POST /api/weather/decode - Decode raw METAR/TAF
export async function POST(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { raw, type } = body

    if (!raw) {
      return NextResponse.json(
        { error: "Raw weather string is required" },
        { status: 400 }
      )
    }

    try {
      if (type === "taf") {
        const decoded = parseTaf(raw)
        return NextResponse.json({ decoded, type: "taf" })
      } else {
        const decoded = parseMetar(raw)
        return NextResponse.json({ decoded, type: "metar" })
      }
    } catch {
      return NextResponse.json(
        { error: "Failed to parse weather string" },
        { status: 400 }
      )
    }
  } catch (error) {
    console.error("Error decoding weather:", error)
    return NextResponse.json(
      { error: "Failed to decode weather" },
      { status: 500 }
    )
  }
}
