import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { jwtVerify } from "jose"

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "fallback-secret-change-in-production"
)

// Routes that don't require authentication
const publicRoutes = ["/login", "/api/auth/login"]

// Routes that require admin access
const adminRoutes = ["/admin"]

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Allow public routes
  if (publicRoutes.some((route) => pathname.startsWith(route))) {
    return NextResponse.next()
  }

  // Allow API routes except protected ones
  if (pathname.startsWith("/api") && !pathname.startsWith("/api/protected")) {
    return NextResponse.next()
  }

  // Get session token
  const token = request.cookies.get("flightplan_session")?.value

  // No token - redirect to login
  if (!token) {
    const loginUrl = new URL("/login", request.url)
    loginUrl.searchParams.set("redirect", pathname)
    return NextResponse.redirect(loginUrl)
  }

  try {
    // Verify token
    const { payload } = await jwtVerify(token, JWT_SECRET)

    // Check admin routes
    if (adminRoutes.some((route) => pathname.startsWith(route))) {
      if (payload.role !== "ADMIN") {
        return NextResponse.redirect(new URL("/dashboard", request.url))
      }
    }

    // Add user info to headers for server components
    const response = NextResponse.next()
    response.headers.set("x-user-id", payload.id as string)
    response.headers.set("x-user-role", payload.role as string)

    return response
  } catch {
    // Invalid token - clear and redirect to login
    const response = NextResponse.redirect(new URL("/login", request.url))
    response.cookies.delete("flightplan_session")
    return response
  }
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder files
     */
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
}
